<template>
  <div class="container-center-horizontal">
    <div class="x6th screen">
      <div class="overlap-group4-1">
        <status-bar :className="statusBarProps.className" />
        <frame282 />
        <img
          class="texture-2"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-5.svg"
          alt="Texture"
        />
        <div class="overlap-group-7 tajawal-normal-black-16px">
          <div class="rectangle-91-1"></div>
          <div class="frame-21-2">
            <router-link to="/11th" className="align-self-flex-center"
              ><img
                class="vuesaxoutlineframe-2"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-3.svg"
                alt="vuesax/outline/frame"
              />
            </router-link>
            <div class="text-23 tajawal-normal-black-16px">{{ text23 }}</div>
          </div>
          <img
            class="iconsax-linearmenuboard-2"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-3.svg"
            alt="Iconsax/Linear/menuboard"
          />
          <div class="text-24">{{ text24 }}</div>
          <div class="icons-other-sizes-star-2" :style="{ 'background-image': 'url(' + iconsOthersizesStar + ')' }">
            <img class="rectangle-65-3" :src="rectangle65" alt="Rectangle 65" /><img
              class="star-3-3"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-1.svg"
              alt="Star 3"
            />
          </div>
          <div class="text-25">{{ text25 }}</div>
          <router-link to="/5th"
            ><img
              class="iconsax-linearedit2-2"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              alt="Iconsax/Linear/edit2"
            />
          </router-link>
          <div class="text-26">{{ text26 }}</div>
          <img
            class="union-2"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-3.svg"
            alt="Union"
          />
          <div class="text-27">{{ text27 }}</div>
          <img
            class="iconsax-outlinehome3-2"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
            alt="Iconsax/Outline/home3"
          />
        </div>
        <img class="group-48095476" :src="group48095476" alt="Group 48095476" />
        <div class="components-tabs-variants-challenges-1">
          <div class="carb-1">
            <div class="text tajawal-bold-white-24px">{{ text28 }}</div>
          </div>
          <router-link to="/7th">
            <div class="carb-2">
              <div class="text tajawal-bold-black-24px">{{ text_Label1 }}</div>
            </div></router-link
          >
        </div>
        <div class="inside-4th">
          <div class="overlap-group1-7">
            <div class="inside-4th2"></div>
            <gr-from1-to10 v-bind="grFrom1To10Props" />
          </div>
        </div>
        <div class="carb5-4">
          <router-link to="/9th">
            <div class="carb6-6">
              <div class="text_label-9 alef-bold-white-16px">{{ text_Label2 }}</div>
            </div></router-link
          >
        </div>
        <div class="group-container">
          <div class="group_-container-1">
            <img class="group_8026-1" :src="group_8026" alt="Group_8026" /><group8034
              :className="group8034Props.className"
            />
            <img class="group_8035-1" :src="group_8035" alt="Group_8035" />
          </div>
          <img class="group_8028" :src="group_8028" alt="Group_8028" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import StatusBar from "./StatusBar";
import Frame282 from "./Frame282";
import GrFrom1To10 from "./GrFrom1To10";
import Group8034 from "./Group8034";
export default {
  name: "X6th",
  components: {
    StatusBar,
    Frame282,
    GrFrom1To10,
    Group8034,
  },
  props: [
    "text23",
    "text24",
    "iconsOthersizesStar",
    "rectangle65",
    "text25",
    "text26",
    "text27",
    "group48095476",
    "text28",
    "text_Label1",
    "text_Label2",
    "group_8026",
    "group_8035",
    "group_8028",
    "statusBarProps",
    "grFrom1To10Props",
    "group8034Props",
  ],
};
</script>

<style>
.x6th {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  overflow: hidden;
  width: 750px;
}

.overlap-group4-1 {
  height: 1624px;
  margin-left: -27px;
  position: relative;
  width: 777px;
}

.texture-2 {
  height: 1624px;
  left: 27px;
  position: absolute;
  top: 0;
  width: 750px;
}

.overlap-group-7 {
  height: 143px;
  left: 69px;
  position: absolute;
  top: 1427px;
  width: 670px;
}

.rectangle-91-1 {
  background-color: var(--concrete);
  border-radius: 31px;
  box-shadow: 0px 4px 4px #00000087;
  height: 125px;
  left: 0;
  position: absolute;
  top: 18px;
  width: 670px;
}

.frame-21-2 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 17px;
  left: 10px;
  min-height: 122px;
  padding: 24.8px 30.8px;
  position: absolute;
  top: 18px;
  width: 124px;
}

.vuesaxoutlineframe-2 {
  align-self: center;
  cursor: pointer;
  height: 33px;
  margin-right: 0.39px;
  margin-top: 3px;
  width: 33px;
}

.text-23 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 60px;
  text-align: center;
  white-space: nowrap;
}

.iconsax-linearmenuboard-2 {
  height: 27px;
  left: 439px;
  position: absolute;
  top: 54px;
  width: 29px;
}

.text-24 {
  direction: rtl;
  left: 415px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.icons-other-sizes-star-2 {
  align-items: center;
  background-size: 100% 100%;
  display: flex;
  gap: 1473px;
  height: 29px;
  left: 568px;
  min-width: 34px;
  position: absolute;
  top: 52px;
}

.rectangle-65-3 {
  align-self: flex-end;
  height: 24px;
  margin-bottom: -1914.1px;
  margin-left: -1492px;
  width: 28px;
}

.star-3-3 {
  height: 13px;
  margin-bottom: 0.91px;
  width: 14px;
}

.text-25 {
  direction: rtl;
  left: 525px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-linearedit2-2 {
  cursor: pointer;
  height: 30px;
  left: 186px;
  position: absolute;
  top: 49px;
  width: 32px;
}

.text-26 {
  direction: rtl;
  left: 164px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.union-2 {
  height: 64px;
  left: 405px;
  position: absolute;
  top: 0;
  width: 104px;
}

.text-27 {
  direction: rtl;
  left: 300px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-outlinehome3-2 {
  height: 30px;
  left: 309px;
  position: absolute;
  top: 52px;
  width: 31px;
}

.group-48095476 {
  height: 75px;
  left: 307px;
  position: absolute;
  top: 312px;
  width: 418px;
}

.components-tabs-variants-challenges-1 {
  align-items: center;
  background-color: var(--primarywhite);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 10px;
  height: 109px;
  justify-content: center;
  left: 71px;
  overflow: hidden;
  padding: 3px;
  position: absolute;
  top: 161px;
  width: 661px;
}

.carb-1 {
  align-items: center;
  background-color: var(--rainee);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 60px;
  justify-content: center;
  padding: 14px 23px;
  position: relative;
  width: 250px;
}

.text {
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  position: relative;
  text-align: center;
  width: fit-content;
}

.carb-2 {
  align-items: center;
  background-color: var(--almond-3);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 60px;
  justify-content: center;
  padding: 14px 23px;
  position: relative;
  width: 250px;
}

.inside-4th {
  align-items: flex-start;
  background-color: var(--rainee);
  border-radius: 45px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  height: 986px;
  left: 75px;
  overflow: hidden;
  padding: 20px 0;
  position: absolute;
  top: 402px;
  width: 646px;
}

.overlap-group1-7 {
  height: 944px;
  position: relative;
  width: 674px;
}

.inside-4th2 {
  background-color: var(--primarywhite);
  border-radius: 50px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 944px;
  left: 27px;
  position: absolute;
  top: 0;
  width: 596px;
}

.carb5-4 {
  align-items: center;
  background-color: var(--primarywhite);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 55px;
  justify-content: center;
  left: 74px;
  padding: 14px 23px;
  position: absolute;
  top: 312px;
  width: 173px;
}

.carb6-6 {
  align-items: center;
  background-color: var(--rainee);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 43px;
  justify-content: center;
  margin-bottom: -8px;
  margin-left: -16px;
  margin-right: -16px;
  margin-top: -8px;
  padding: 14px 23px;
  position: relative;
  width: 159px;
}

.text_label-9 {
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  margin-bottom: -2.5px;
  margin-left: -6.5px;
  margin-right: -6.5px;
  margin-top: -4.5px;
  position: relative;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
  width: 126px;
}

.group-container {
  height: 192px;
  left: 27px;
  position: absolute;
  top: 13px;
  width: 731px;
}

.group_-container-1 {
  height: 134px;
  left: 0;
  position: absolute;
  top: 0;
  width: 659px;
}

.group_8026-1 {
  height: 76px;
  left: 266px;
  position: absolute;
  top: 59px;
  width: 124px;
}

.group_8035-1 {
  height: 128px;
  left: 0;
  position: absolute;
  top: 0;
  width: 659px;
}

.group_8028 {
  height: 60px;
  left: 626px;
  position: absolute;
  top: 132px;
  width: 105px;
}
</style>
