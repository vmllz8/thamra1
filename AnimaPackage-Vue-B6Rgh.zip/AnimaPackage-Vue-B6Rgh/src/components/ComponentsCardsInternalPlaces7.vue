<template>
  <div class="components-cards-internal-places-7">
    <frame480956599
      :componentsCardsInternalPlacesNumber="frame480956599Props.componentsCardsInternalPlacesNumber"
      :frame480956592Props="frame480956599Props.frame480956592Props"
    />
    <components-button-add-to-friends3 />
  </div>
</template>

<script>
import Frame480956599 from "./Frame480956599";
import ComponentsButtonAddToFriends3 from "./ComponentsButtonAddToFriends3";
export default {
  name: "ComponentsCardsInternalPlaces7",
  components: {
    Frame480956599,
    ComponentsButtonAddToFriends3,
  },
  props: ["frame480956599Props"],
};
</script>

<style>
.components-cards-internal-places-7,
.components-cards-internal-places-8 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 200px;
  height: 45px;
  position: relative;
  width: 480px;
}
</style>
