<template>
  <div class="frame-48095659-17">
    <components-cards-internal-places-number :children="componentsCardsInternalPlacesNumber.children" />
    <frame480956592 :nicknameProps="frame480956592Props.nicknameProps" />
  </div>
</template>

<script>
import ComponentsCardsInternalPlacesNumber from "./ComponentsCardsInternalPlacesNumber";
import Frame480956592 from "./Frame480956592";
export default {
  name: "Frame480956597",
  components: {
    ComponentsCardsInternalPlacesNumber,
    Frame480956592,
  },
  props: ["componentsCardsInternalPlacesNumber", "frame480956592Props"],
};
</script>

<style>
.frame-48095659-17,
.x51,
.x51-1 {
  align-items: center;
  display: flex;
  gap: 30px;
  position: relative;
  width: 198px;
}
</style>
