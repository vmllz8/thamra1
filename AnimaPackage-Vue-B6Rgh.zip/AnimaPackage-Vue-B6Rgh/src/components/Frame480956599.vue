<template>
  <div class="frame-48095659-21">
    <components-cards-internal-places-number
      :children="componentsCardsInternalPlacesNumber.children"
      :className="componentsCardsInternalPlacesNumber.className"
    />
    <frame480956592 :nicknameProps="frame480956592Props.nicknameProps" />
  </div>
</template>

<script>
import ComponentsCardsInternalPlacesNumber from "./ComponentsCardsInternalPlacesNumber";
import Frame480956592 from "./Frame480956592";
export default {
  name: "Frame480956599",
  components: {
    ComponentsCardsInternalPlacesNumber,
    Frame480956592,
  },
  props: ["componentsCardsInternalPlacesNumber", "frame480956592Props"],
};
</script>

<style>
.frame-48095659-21,
.frame-48095659-22,
.frame-48095659-23 {
  align-items: center;
  display: flex;
  gap: 30px;
  position: relative;
  width: 198px;
}
</style>
