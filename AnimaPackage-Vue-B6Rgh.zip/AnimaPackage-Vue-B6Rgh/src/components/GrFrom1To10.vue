<template>
  <div :class="[`gr-from-1-to-10`, className || ``]">
    <img
      class="vector-6"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-1.svg"
      alt="Vector 61"
    />
    <div class="components-cards-internal-places-1">
      <div class="components-cards-internal-places">
        <frame48095659
          :componentsCardsInternalPlacesNumber="frame48095659Props.componentsCardsInternalPlacesNumber"
          :frame480956592Props="frame48095659Props.frame480956592Props"
        />
        <a
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          target="_blank"
        >
          <div class="components-button-add-to-friends">
            <div class="text-28 tajawal-medium-white-20px">انضم!</div>
          </div></a
        >
      </div>
    </div>
    <img
      class="vector-6"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="Vector 65"
    />
    <div class="components-cards-internal-places">
      <frame480956593
        :componentsCardsInternalPlacesNumber="frame480956593Props.componentsCardsInternalPlacesNumber"
        :frame480956594Props="frame480956593Props.frame480956594Props"
      />
      <a
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        target="_blank"
      >
        <div class="components-button-add-to-friends">
          <div class="text-28 tajawal-medium-white-20px">انضم!</div>
        </div></a
      >
    </div>
    <img
      class="vector-6"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="Vector 66"
    />
    <div class="components-cards-internal-places">
      <frame480956595 :frame480956592Props="frame480956595Props.frame480956592Props" />
      <a
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        target="_blank"
      >
        <div class="components-button-add-to-friends">
          <div class="text-28 tajawal-medium-white-20px">انضم!</div>
        </div></a
      >
    </div>
    <img
      class="vector-6"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="Vector 67"
    />
    <div class="your-card">
      <a
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        target="_blank"
      >
        <div class="components-cards-internal-places-2">
          <frame480956596 :nicknameProps="frame480956596Props.nicknameProps" />
          <components-button-add-to-friends :text36="componentsButtonAddToFriendsProps.text36" /></div
      ></a>
    </div>
    <a
      href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
      target="_blank"
    >
      <div class="components-cards-internal-places-3">
        <components-cards-internal-places
          :frame4809565962Props="componentsCardsInternalPlacesProps.frame4809565962Props"
        /></div></a
    ><img
      class="vector-6"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="Vector 68"
    />
    <div class="components-cards-internal-places">
      <frame480956597
        :componentsCardsInternalPlacesNumber="frame480956597Props.componentsCardsInternalPlacesNumber"
        :frame480956592Props="frame480956597Props.frame480956592Props"
      />
      <a
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        target="_blank"
      >
        <div class="components-button-add-to-friends">
          <div class="text-28 tajawal-medium-white-20px">انضم!</div>
        </div></a
      >
    </div>
    <img
      class="vector-6"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-69-1.svg"
      alt="Vector 69"
    />
    <a
      href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
      target="_blank"
    >
      <div class="components-cards-internal-places-4">
        <frame480956598
          :componentsCardsInternalPlacesNumber="frame480956598Props.componentsCardsInternalPlacesNumber"
          :frame480956594Props="frame480956598Props.frame480956594Props"
        />
        <components-button-add-to-friends3 /></div></a
    ><img
      class="vector"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
      alt="Vector 70"
    />
    <components-cards-internal-places7 :frame480956599Props="componentsCardsInternalPlaces7Props.frame480956599Props" />
    <img
      class="vector variant-1"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
      alt="Vector 63"
    />
    <components-cards-internal-places8
      :frame4809565910Props="componentsCardsInternalPlaces8Props.frame4809565910Props"
    />
    <img
      class="vector variant-2"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png"
      alt="Vector 69"
    />
    <components-cards-internal-places9
      :frame4809565911Props="componentsCardsInternalPlaces9Props.frame4809565911Props"
    />
    <img
      class="components-cards-internal-open-info"
      :src="componentsCardsinternalOpenInfo"
      alt="Components/CardsInternal/Open Info"
    />
  </div>
</template>

<script>
import Frame48095659 from "./Frame48095659";
import Frame480956593 from "./Frame480956593";
import Frame480956595 from "./Frame480956595";
import Frame480956596 from "./Frame480956596";
import ComponentsButtonAddToFriends from "./ComponentsButtonAddToFriends";
import ComponentsCardsInternalPlaces from "./ComponentsCardsInternalPlaces";
import Frame480956597 from "./Frame480956597";
import Frame480956598 from "./Frame480956598";
import ComponentsButtonAddToFriends3 from "./ComponentsButtonAddToFriends3";
import ComponentsCardsInternalPlaces7 from "./ComponentsCardsInternalPlaces7";
import ComponentsCardsInternalPlaces8 from "./ComponentsCardsInternalPlaces8";
import ComponentsCardsInternalPlaces9 from "./ComponentsCardsInternalPlaces9";
export default {
  name: "GrFrom1To10",
  components: {
    Frame48095659,
    Frame480956593,
    Frame480956595,
    Frame480956596,
    ComponentsButtonAddToFriends,
    ComponentsCardsInternalPlaces,
    Frame480956597,
    Frame480956598,
    ComponentsButtonAddToFriends3,
    ComponentsCardsInternalPlaces7,
    ComponentsCardsInternalPlaces8,
    ComponentsCardsInternalPlaces9,
  },
  props: [
    "componentsCardsinternalOpenInfo",
    "className",
    "frame48095659Props",
    "frame480956593Props",
    "frame480956595Props",
    "frame480956596Props",
    "componentsButtonAddToFriendsProps",
    "componentsCardsInternalPlacesProps",
    "frame480956597Props",
    "frame480956598Props",
    "componentsCardsInternalPlaces7Props",
    "componentsCardsInternalPlaces8Props",
    "componentsCardsInternalPlaces9Props",
  ],
};
</script>

<style>
.gr-from-1-to-10::-webkit-scrollbar {
  display: none;
  width: 0;
}

.gr-from-1-to-10 {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 874px;
  left: 0;
  overflow: hidden;
  overflow-y: scroll;
  position: absolute;
  top: 35px;
  width: 674px;
}

.vector-6,
.gr-from-1-to-10.gr-from-1-to-10-t .vector.variant-1,
.gr-from-1-to-10.gr-from-1-to-10-t .vector.variant-2 {
  height: 1px;
  object-fit: cover;
  position: relative;
  width: 341px;
}

.components-cards-internal-places-1 {
  align-items: center;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 26px;
  position: relative;
}

.components-cards-internal-places {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 200px;
  height: 45px;
  position: relative;
  width: 480px;
}

.components-button-add-to-friends {
  align-items: flex-start;
  background-color: var(--squirrel);
  border-radius: 14px;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 35px;
  padding: 7px 16px;
  position: relative;
  width: 75px;
}

.text-28 {
  direction: rtl;
  letter-spacing: -0.3px;
  line-height: 21px;
  margin-right: -6px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: fit-content;
}

.your-card {
  align-items: flex-start;
  background-color: var(--squirrel);
  border-radius: 9px;
  box-shadow: 0px -3px 50px #b931151a;
  display: flex;
  flex-direction: column;
  gap: 8px;
  height: 99px;
  padding: 19px 30px;
  position: relative;
  width: 540px;
}

.components-cards-internal-places-2 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: inline-flex;
  gap: 200px;
  height: 80px;
  margin-bottom: -19px;
  margin-right: -12px;
  position: relative;
}

.components-cards-internal-places-3 {
  align-items: center;
  cursor: pointer;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 26px;
  position: relative;
}

.components-cards-internal-places-4 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 200px;
  height: 45px;
  position: relative;
  width: 480px;
}

.vector {
  height: 1px;
  margin-left: -766.5px;
  object-fit: cover;
  position: relative;
  width: 341px;
}

.components-cards-internal-open-info {
  height: 65px;
  position: relative;
  width: 561px;
}

.gr-from-1-to-10.gr-from-1-to-10-t {
  height: 891px;
  left: 73px;
  top: 446px;
  width: 657px;
}

.gr-from-1-to-10.gr-from-1-to-10-t .vector {
  margin-left: -1660px;
}
</style>
