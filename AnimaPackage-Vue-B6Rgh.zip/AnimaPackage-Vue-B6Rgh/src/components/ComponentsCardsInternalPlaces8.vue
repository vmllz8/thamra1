<template>
  <div class="components-cards-internal-places-9">
    <frame4809565910
      :componentsCardsInternalPlacesNumber="frame4809565910Props.componentsCardsInternalPlacesNumber"
      :frame480956592Props="frame4809565910Props.frame480956592Props"
    />
    <components-button-add-to-friends3 />
  </div>
</template>

<script>
import Frame4809565910 from "./Frame4809565910";
import ComponentsButtonAddToFriends3 from "./ComponentsButtonAddToFriends3";
export default {
  name: "ComponentsCardsInternalPlaces8",
  components: {
    Frame4809565910,
    ComponentsButtonAddToFriends3,
  },
  props: ["frame4809565910Props"],
};
</script>

<style>
.components-cards-internal-places-9,
.components-cards-internal-places-10 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 200px;
  height: 45px;
  position: relative;
  width: 480px;
}
</style>
