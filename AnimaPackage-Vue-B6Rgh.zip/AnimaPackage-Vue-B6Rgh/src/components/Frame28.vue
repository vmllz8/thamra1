<template>
  <div class="frame-28">
    <img
      class="icon"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon.svg"
      alt="icon"
    />
  </div>
</template>

<script>
export default {
  name: "Frame28",
};
</script>

<style>
.frame-28 {
  align-items: center;
  background-color: var(--primarywhite);
  display: flex;
  height: 84px;
  left: 6px;
  padding: 0 30px;
  position: absolute;
  top: 88px;
  width: 750px;
}

.icon {
  height: 64px;
  margin-left: 626px;
  width: 64px;
}
</style>
