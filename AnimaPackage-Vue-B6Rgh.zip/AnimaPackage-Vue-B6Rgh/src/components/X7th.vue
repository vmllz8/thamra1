<template>
  <div class="container-center-horizontal">
    <div class="x7th screen">
      <div class="overlap-group3-1">
        <frame282 :className="frame282Props.className" />
        <status-bar :className="statusBarProps.className" />
        <img
          class="texture-3"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/texture-3.svg"
          alt="Texture"
        />
        <div class="overlap-group-21 tajawal-normal-black-16px">
          <div class="rectangle-91-2"></div>
          <div class="frame-21-3">
            <router-link to="/11th" className="align-self-flex-center"
              ><img
                class="vuesaxoutlineframe-3"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-3.svg"
                alt="vuesax/outline/frame"
              />
            </router-link>
            <div class="text-50 tajawal-normal-black-16px">{{ text50 }}</div>
          </div>
          <img
            class="iconsax-linearmenuboard-3"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-1.svg"
            alt="Iconsax/Linear/menuboard"
          />
          <div class="text-51">{{ text51 }}</div>
          <div class="icons-other-sizes-star-3" :style="{ 'background-image': 'url(' + iconsOthersizesStar + ')' }">
            <img class="rectangle-65-4" :src="rectangle65" alt="Rectangle 65" /><img
              class="star-3-4"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-13.svg"
              alt="Star 3"
            />
          </div>
          <div class="text-52">{{ text52 }}</div>
          <router-link to="/5th"
            ><img
              class="iconsax-linearedit2-3"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              alt="Iconsax/Linear/edit2"
            />
          </router-link>
          <div class="text-53">{{ text53 }}</div>
          <img
            class="union-3"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/union-3.svg"
            alt="Union"
          />
          <div class="text-54">{{ text54 }}</div>
          <img
            class="iconsax-outlinehome3-3"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
            alt="Iconsax/Outline/home3"
          />
        </div>
        <div class="choose">
          <router-link to="/6th">
            <div class="carb1">
              <div class="text-5-1 tajawal-bold-black-24px">{{ text55 }}</div>
            </div></router-link
          >
          <div class="x2">
            <div class="text-5-1 tajawal-bold-white-24px">{{ text56 }}</div>
          </div>
        </div>
        <router-link to="/6th">
          <div class="carb3">
            <router-link to="/9th">
              <div class="carb4">
                <div class="text_label-12 alef-bold-white-16px">{{ text_Label }}</div>
              </div></router-link
            >
          </div></router-link
        >
        <div class="inside-4th-2">
          <div class="inside-4th2-1"></div>
        </div>
        <img class="group-48095476-1" :src="group48095476" alt="Group 48095476" /><gr-from1-to10
          v-bind="grFrom1To10Props"
        />
        <div class="group_8037">
          <div class="group_-container-2">
            <img class="group_8026-2" :src="group_8026" alt="Group_8026" /><group8034
              :className="group8034Props.className"
            />
            <img class="group_8035-2" :src="group_8035" alt="Group_8035" />
          </div>
          <img class="group_8028-1" :src="group_8028" alt="Group_8028" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Frame282 from "./Frame282";
import StatusBar from "./StatusBar";
import GrFrom1To10 from "./GrFrom1To10";
import Group8034 from "./Group8034";
export default {
  name: "X7th",
  components: {
    Frame282,
    StatusBar,
    GrFrom1To10,
    Group8034,
  },
  props: [
    "text50",
    "text51",
    "iconsOthersizesStar",
    "rectangle65",
    "text52",
    "text53",
    "text54",
    "text55",
    "text56",
    "text_Label",
    "group48095476",
    "group_8026",
    "group_8035",
    "group_8028",
    "frame282Props",
    "statusBarProps",
    "grFrom1To10Props",
    "group8034Props",
  ],
};
</script>

<style>
.x7th {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  height: 1624px;
  overflow: hidden;
  width: 750px;
}

.overlap-group3-1 {
  height: 1570px;
  margin-left: -27px;
  position: relative;
  width: 777px;
}

.texture-3 {
  height: 1490px;
  left: 27px;
  position: absolute;
  top: 0;
  width: 750px;
}

.overlap-group-21 {
  height: 143px;
  left: 69px;
  position: absolute;
  top: 1427px;
  width: 670px;
}

.rectangle-91-2 {
  background-color: var(--concrete);
  border-radius: 31px;
  box-shadow: 0px 4px 4px #00000087;
  height: 125px;
  left: 0;
  position: absolute;
  top: 18px;
  width: 670px;
}

.frame-21-3 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 17px;
  left: 10px;
  min-height: 122px;
  padding: 24.8px 30.8px;
  position: absolute;
  top: 18px;
  width: 124px;
}

.vuesaxoutlineframe-3 {
  align-self: center;
  cursor: pointer;
  height: 33px;
  margin-right: 0.39px;
  margin-top: 3px;
  width: 33px;
}

.text-50 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 60px;
  text-align: center;
  white-space: nowrap;
}

.iconsax-linearmenuboard-3 {
  height: 27px;
  left: 439px;
  position: absolute;
  top: 54px;
  width: 29px;
}

.text-51 {
  direction: rtl;
  left: 415px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.icons-other-sizes-star-3 {
  align-items: center;
  background-size: 100% 100%;
  display: flex;
  gap: 2360px;
  height: 29px;
  left: 568px;
  min-width: 34px;
  position: absolute;
  top: 52px;
}

.rectangle-65-4 {
  align-self: flex-end;
  height: 24px;
  margin-bottom: -1914.1px;
  margin-left: -2379px;
  width: 28px;
}

.star-3-4 {
  height: 13px;
  margin-bottom: 0.91px;
  width: 14px;
}

.text-52 {
  direction: rtl;
  left: 525px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-linearedit2-3 {
  cursor: pointer;
  height: 30px;
  left: 186px;
  position: absolute;
  top: 49px;
  width: 32px;
}

.text-53 {
  direction: rtl;
  left: 164px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.union-3 {
  height: 64px;
  left: 405px;
  position: absolute;
  top: 0;
  width: 104px;
}

.text-54 {
  direction: rtl;
  left: 300px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-outlinehome3-3 {
  height: 30px;
  left: 309px;
  position: absolute;
  top: 52px;
  width: 31px;
}

.choose {
  align-items: center;
  background-color: var(--primarywhite);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 10px;
  height: 109px;
  justify-content: center;
  left: 86px;
  overflow: hidden;
  padding: 3px;
  position: absolute;
  top: 172px;
  width: 661px;
}

.carb1 {
  align-items: center;
  background-color: var(--almond-3);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 60px;
  justify-content: center;
  padding: 14px 23px;
  position: relative;
  width: 250px;
}

.text-5-1 {
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  position: relative;
  text-align: center;
  width: fit-content;
}

.x2 {
  align-items: center;
  background-color: var(--rainee);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 60px;
  justify-content: center;
  padding: 14px 23px;
  position: relative;
  width: 250px;
}

.carb3 {
  align-items: center;
  background-color: var(--primarywhite);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 55px;
  justify-content: center;
  left: 68px;
  padding: 14px 23px;
  position: absolute;
  top: 309px;
  width: 173px;
}

.carb4 {
  align-items: center;
  background-color: var(--rainee);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 43px;
  justify-content: center;
  margin-bottom: -8px;
  margin-left: -16px;
  margin-right: -16px;
  margin-top: -8px;
  padding: 14px 23px;
  position: relative;
  width: 159px;
}

.text_label-12 {
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  margin-bottom: -2.5px;
  margin-left: -6.5px;
  margin-right: -6.5px;
  margin-top: -4.5px;
  position: relative;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
  width: 126px;
}

.inside-4th-2 {
  align-items: flex-start;
  background-color: var(--rainee);
  border-radius: 45px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  height: 992px;
  left: 80px;
  overflow: hidden;
  padding: 22px;
  position: absolute;
  top: 403px;
  width: 640px;
}

.inside-4th2-1 {
  background-color: var(--primarywhite);
  border-radius: 50px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 944px;
  width: 596px;
}

.group-48095476-1 {
  height: 63px;
  left: 301px;
  position: absolute;
  top: 313px;
  width: 418px;
}

.group_8037 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 14px;
  left: 0;
  min-height: 209px;
  position: absolute;
  top: 13px;
  width: 748px;
}

.group_-container-2 {
  align-self: center;
  height: 134px;
  margin-right: 35.36px;
  position: relative;
  width: 659px;
}

.group_8026-2 {
  height: 76px;
  left: 266px;
  position: absolute;
  top: 59px;
  width: 124px;
}

.group_8035-2 {
  height: 128px;
  left: 0;
  position: absolute;
  top: 0;
  width: 659px;
}

.group_8028-1 {
  height: 60px;
  margin-right: 0;
  width: 105px;
}
</style>
