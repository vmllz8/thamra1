<template>
  <div :class="[`frame-48095659-1-1`, className || ``]">
    <nickname :children="nicknameProps.children" :className="nicknameProps.className" />
  </div>
</template>

<script>
import Nickname from "./Nickname";
export default {
  name: "Frame480956592",
  components: {
    Nickname,
  },
  props: ["className", "nicknameProps"],
};
</script>

<style>
.frame-48095659-1-1 {
  align-items: center;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 13px;
  margin-right: -40px;
  position: relative;
}

.frame-48095659-1-1.frame-48095659-2,
.frame-48095659-1-1.x49,
.frame-48095659-1-1.x49-1 {
  align-items: center;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 13px;
  margin-right: -30px;
  position: relative;
}
</style>
