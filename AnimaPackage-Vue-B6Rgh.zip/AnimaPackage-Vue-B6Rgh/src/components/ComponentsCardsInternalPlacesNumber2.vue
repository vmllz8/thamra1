<template>
  <div :class="[`components-cards-internal-places-number-14-1`, className || ``]">
    <div class="overlap-group-20">
      <div class="number-13 abeezee-normal-white-20px">{{ children }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ComponentsCardsInternalPlacesNumber2",
  props: ["children", "className"],
};
</script>

<style>
.components-cards-internal-places-number-14-1 {
  height: 40px;
  position: relative;
  width: 40px;
}

.overlap-group-20 {
  align-items: flex-end;
  background-color: var(--gamboge);
  border-radius: 20px/19.05px;
  display: flex;
  height: 38px;
  justify-content: flex-end;
  min-width: 40px;
  padding: 0.5px 4.5px;
  position: relative;
  top: 2px;
}

.number-13 {
  letter-spacing: -0.38px;
  line-height: 20.6px;
  min-height: 28px;
  text-align: center;
  width: 30px;
}

.components-cards-internal-places-number-14-1.components-cards-internal-places-number-14 .overlap-group-20,
.components-cards-internal-places-number-14-1.components-cards-internal-places-number-15 .overlap-group-20,
.components-cards-internal-places-number-14-1.components-cards-internal-places-number-16 .overlap-group-20 {
  background-color: var(--casal);
}
</style>
