<template>
  <div class="container-center-horizontal">
    <div class="x9th screen">
      <div class="overlap-group3-2">
        <status-bar :className="statusBarProps.className" />
        <frame282 :className="frame282Props.className" />
        <img
          class="texture-4"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-7.svg"
          alt="Texture"
        />
        <div class="overlap-group-23 tajawal-normal-black-16px">
          <div class="rectangle-91-3"></div>
          <div class="frame-21-4">
            <router-link to="/11th" className="align-self-flex-center"
              ><img
                class="vuesaxoutlineframe-4"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-1.svg"
                alt="vuesax/outline/frame"
              />
            </router-link>
            <div class="text-68 tajawal-normal-black-16px">{{ text68 }}</div>
          </div>
          <img
            class="iconsax-linearmenuboard-4"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-1.svg"
            alt="Iconsax/Linear/menuboard"
          />
          <div class="text-69">{{ text69 }}</div>
          <div class="icons-other-sizes-star-4" :style="{ 'background-image': 'url(' + iconsOthersizesStar + ')' }">
            <img class="rectangle-65-5" :src="rectangle65" alt="Rectangle 65" /><img
              class="star-3-5"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-13.svg"
              alt="Star 3"
            />
          </div>
          <div class="text-70">{{ text70 }}</div>
          <router-link to="/5th"
            ><img
              class="iconsax-linearedit2-4"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              alt="Iconsax/Linear/edit2"
            />
          </router-link>
          <div class="text-71">{{ text71 }}</div>
          <img
            class="union-4"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-5.svg"
            alt="Union"
          />
          <div class="text-72">{{ text72 }}</div>
          <img
            class="iconsax-outlinehome3-4"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
            alt="Iconsax/Outline/home3"
          />
        </div>
        <div class="components-tabs-variants-challenges-2">
          <div class="home-work1">
            <div class="text_label-13 tajawal-bold-black-24px">{{ text_Label }}</div>
          </div>
        </div>
        <img class="group-48095476-2" :src="group48095476" alt="Group 48095476" />
        <div class="cards">
          <div class="components-button-main-small">
            <div class="components-cards-internal-add">
              <div class="internal">
                <div class="iconsax-outlinelogout">
                  <div class="vector-container">
                    <img
                      class="vector-1"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector.svg"
                      alt="Vector"
                    />
                    <router-link to="/name"
                      ><img
                        class="vector-2"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-2.svg"
                        alt="Vector"
                      /> </router-link
                    ><img
                      class="vector-3"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-3.svg"
                      alt="Vector"
                    />
                  </div>
                </div>
                <div class="text-73 tajawal-medium-licorice-20px">{{ text73 }}</div>
                <div class="frame-48095656">
                  <div class="frame-48095655"></div>
                </div>
                <img class="icons56x56-background" :src="icons56X56Background1" alt="Icons/56x56/Background" />
              </div>
            </div>
          </div>
          <div class="components-button-main-small-1">
            <div class="components-cards-internal-add">
              <div class="internal-1">
                <div class="frame-48095656">
                  <div class="frame-48095655">
                    <div class="text-74 tajawal-medium-licorice-20px">{{ text74 }}</div>
                  </div>
                </div>
              </div>
              <div class="iconsax-outlinelogout-1">
                <div class="vector-container-1">
                  <img
                    class="vector-1"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-4.svg"
                    alt="Vector"
                  />
                  <router-link to="/name"
                    ><img
                      class="vector-2"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-8.svg"
                      alt="Vector"
                    /> </router-link
                  ><img
                    class="vector-3"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-9.svg"
                    alt="Vector"
                  />
                </div>
              </div>
              <img
                class="icons56x56-background-1"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-10.svg"
                alt="Icons/56x56/Background"
              />
            </div>
          </div>
          <div class="components-button-main-small-2">
            <div class="components-cards-internal-add">
              <div class="internal-2">
                <div class="iconsax-outlinelogout">
                  <div class="vector-container">
                    <img
                      class="vector-1"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-10.svg"
                      alt="Vector"
                    />
                    <router-link to="/name"
                      ><img
                        class="vector-2"
                        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-11.svg"
                        alt="Vector"
                      /> </router-link
                    ><img
                      class="vector-3"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-12.svg"
                      alt="Vector"
                    />
                  </div>
                </div>
                <div class="frame-48095656-1">
                  <div class="frame-48095655">
                    <div class="text-75 tajawal-medium-licorice-20px">{{ text75 }}</div>
                  </div>
                </div>
              </div>
              <img
                class="icons56x56-background-2"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-11.svg"
                alt="Icons/56x56/Background"
              />
            </div>
          </div>
          <div class="components-button-main-small-3">
            <div class="components-cards-internal-add">
              <div class="internal-3">
                <div class="frame-48095656">
                  <div class="frame-48095655"></div>
                  <img
                    class="icons56x56-background-3"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-12.svg"
                    alt="Icons/56x56/Background"
                  />
                </div>
                <div class="text-76 tajawal-medium-licorice-20px">{{ text76 }}</div>
              </div>
              <div class="iconsax-outlinelogout-2">
                <div class="vector-container-2">
                  <img
                    class="vector-1"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-13.svg"
                    alt="Vector"
                  />
                  <router-link to="/name"
                    ><img
                      class="vector-2"
                      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-14.svg"
                      alt="Vector"
                    /> </router-link
                  ><img
                    class="vector-3"
                    src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-15.svg"
                    alt="Vector"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="icons56x56-background-4">
          <div class="overlap-group1-8">
            <img
              class="pharrows-down-up-1"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/ph-arrows-down-up-1.svg"
              alt="ph:arrows-down-up"
            />
          </div>
        </div>
        <img
          class="icons56x56-background-5"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-7.svg"
          alt="Icons/56x56/Background"
        />
        <div class="group_8037-1">
          <div class="group_-container-3">
            <img class="group_8026-3" :src="group_8026" alt="Group_8026" />
            <div class="group_8034-3">
              <div class="overlap-group1-9">
                <div class="ellipse_54-3"></div>
                <img
                  class="path_441-12"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44120-2.svg"
                  alt="Path_44120"
                />
                <img
                  class="path_441-13"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44121-2.svg"
                  alt="Path_44121"
                />
                <img
                  class="path_441-14"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44122-2.svg"
                  alt="Path_44122"
                />
                <img
                  class="path_441-15"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44123-2.svg"
                  alt="Path_44123"
                />
              </div>
              <div class="overlap-group-25">
                <div class="ellipse_54-3"></div>
                <img
                  class="path_441-12"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44116-2.svg"
                  alt="Path_44116"
                />
                <img
                  class="path_441-13"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44117-2.svg"
                  alt="Path_44117"
                />
                <img
                  class="path_441-14"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44118-2.svg"
                  alt="Path_44118"
                />
                <img
                  class="path_441-15"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44119-2.svg"
                  alt="Path_44119"
                />
              </div>
            </div>
            <img class="group_8035-3" :src="group_8035" alt="Group_8035" />
          </div>
          <img class="group_8028-2" :src="group_8028" alt="Group_8028" />
        </div>
        <img class="group-48095495" :src="group48095495" alt="Group 48095495" /><img
          class="icons56x56-background-6"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-8.svg"
          alt="Icons/56x56/Background"
        />
      </div>
    </div>
  </div>
</template>

<script>
import StatusBar from "./StatusBar";
import Frame282 from "./Frame282";
export default {
  name: "X9th",
  components: {
    StatusBar,
    Frame282,
  },
  props: [
    "text68",
    "text69",
    "iconsOthersizesStar",
    "rectangle65",
    "text70",
    "text71",
    "text72",
    "text_Label",
    "group48095476",
    "text73",
    "icons56X56Background1",
    "text74",
    "text75",
    "text76",
    "group_8026",
    "group_8035",
    "group_8028",
    "group48095495",
    "statusBarProps",
    "frame282Props",
  ],
};
</script>

<style>
.x9th {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  height: 1624px;
  width: 750px;
}

.overlap-group3-2 {
  height: 1570px;
  position: relative;
  width: 750px;
}

.texture-4 {
  height: 1469px;
  left: 0;
  position: absolute;
  top: 0;
  width: 750px;
}

.overlap-group-23 {
  height: 143px;
  left: 42px;
  position: absolute;
  top: 1427px;
  width: 670px;
}

.rectangle-91-3 {
  background-color: var(--concrete);
  border-radius: 31px;
  box-shadow: 0px 4px 4px #00000087;
  height: 125px;
  left: 0;
  position: absolute;
  top: 18px;
  width: 670px;
}

.frame-21-4 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 17px;
  left: 10px;
  min-height: 122px;
  padding: 24.8px 30.8px;
  position: absolute;
  top: 18px;
  width: 124px;
}

.vuesaxoutlineframe-4 {
  align-self: center;
  cursor: pointer;
  height: 33px;
  margin-right: 0.39px;
  margin-top: 3px;
  width: 33px;
}

.text-68 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 60px;
  text-align: center;
  white-space: nowrap;
}

.iconsax-linearmenuboard-4 {
  height: 27px;
  left: 439px;
  position: absolute;
  top: 54px;
  width: 29px;
}

.text-69 {
  direction: rtl;
  left: 415px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.icons-other-sizes-star-4 {
  align-items: center;
  background-size: 100% 100%;
  display: flex;
  gap: 3247px;
  height: 29px;
  left: 568px;
  min-width: 34px;
  position: absolute;
  top: 52px;
}

.rectangle-65-5 {
  align-self: flex-end;
  height: 24px;
  margin-bottom: -1914.1px;
  margin-left: -3266px;
  width: 28px;
}

.star-3-5 {
  height: 13px;
  margin-bottom: 0.91px;
  width: 14px;
}

.text-70 {
  direction: rtl;
  left: 525px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-linearedit2-4 {
  cursor: pointer;
  height: 30px;
  left: 186px;
  position: absolute;
  top: 49px;
  width: 32px;
}

.text-71 {
  direction: rtl;
  left: 164px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.union-4 {
  height: 64px;
  left: 405px;
  position: absolute;
  top: 0;
  width: 104px;
}

.text-72 {
  direction: rtl;
  left: 300px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-outlinehome3-4 {
  height: 30px;
  left: 309px;
  position: absolute;
  top: 52px;
  width: 31px;
}

.components-tabs-variants-challenges-2 {
  align-items: center;
  background-color: var(--primarywhite);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 10px;
  height: 109px;
  justify-content: center;
  left: 44px;
  overflow: hidden;
  padding: 3px;
  position: absolute;
  top: 183px;
  width: 661px;
}

.home-work1 {
  align-items: center;
  background-color: var(--rainee);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 69px;
  justify-content: center;
  padding: 14px 23px;
  position: relative;
  width: 488px;
}

.text_label-13 {
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  position: relative;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
  width: fit-content;
}

.group-48095476-2 {
  height: 72px;
  left: 301px;
  position: absolute;
  top: 323px;
  width: 418px;
}

.cards {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  flex-direction: column;
  gap: 8px;
  height: 505px;
  left: 91px;
  position: absolute;
  top: 412px;
  width: 649px;
}

.components-button-main-small {
  align-items: center;
  background-color: #ab613c;
  border-radius: 30px;
  display: flex;
  gap: 8px;
  height: 131px;
  justify-content: center;
  overflow: hidden;
  padding: 14px 27px;
  position: relative;
  width: 600px;
}

.components-cards-internal-add {
  background-color: var(--primarywhite);
  border-radius: 30px;
  height: 115px;
  margin-bottom: -6px;
  margin-left: -14.5px;
  margin-right: -14.5px;
  margin-top: -6px;
  position: relative;
  width: 575px;
}

.internal {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: inline-flex;
  gap: 200px;
  justify-content: center;
  left: 34px;
  position: relative;
  top: 32px;
}

.iconsax-outlinelogout {
  height: 40px;
  position: relative;
  width: 40px;
}

.vector-container {
  height: 29px;
  left: 5px;
  position: relative;
  top: 5px;
  width: 30px;
}

.vector-1 {
  height: 11px;
  left: 23px;
  position: absolute;
  top: 9px;
  width: 7px;
}

.vector-2 {
  cursor: pointer;
  height: 2px;
  left: 10px;
  position: absolute;
  top: 13px;
  width: 19px;
}

.vector-3 {
  height: 29px;
  left: 0;
  position: absolute;
  top: 0;
  width: 16px;
}

.text-73 {
  direction: rtl;
  height: 25px;
  letter-spacing: -0.3px;
  line-height: normal;
  position: relative;
  width: 209px;
}

.frame-48095656 {
  align-items: center;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 12px;
  position: relative;
}

.frame-48095655 {
  position: relative;
  width: 125px;
}

.icons56x56-background {
  height: 56px;
  margin-bottom: -2944.5px;
  margin-left: -1846.5px;
  position: relative;
  width: 56px;
}

.components-button-main-small-1 {
  align-items: center;
  background-color: #c8a92a;
  border-radius: 30px;
  display: flex;
  gap: 8px;
  height: 131px;
  justify-content: center;
  overflow: hidden;
  padding: 14px 27px;
  position: relative;
  width: 600px;
}

.internal-1 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: inline-flex;
  gap: 250px;
  justify-content: center;
  left: 154px;
  position: absolute;
  top: 33px;
}

.text-74 {
  direction: rtl;
  left: -58px;
  letter-spacing: -0.3px;
  line-height: normal;
  position: absolute;
  top: 11px;
  white-space: nowrap;
  width: 386px;
}

.iconsax-outlinelogout-1 {
  height: 30px;
  left: 40px;
  position: absolute;
  top: 41px;
  width: 30px;
}

.vector-container-1 {
  height: 29px;
  position: relative;
}

.icons56x56-background-1 {
  height: 64px;
  left: 499px;
  position: absolute;
  top: 26px;
  width: 64px;
}

.components-button-main-small-2 {
  align-items: center;
  background-color: #254341;
  border-radius: 30px;
  display: flex;
  gap: 8px;
  height: 131px;
  justify-content: center;
  overflow: hidden;
  padding: 14px 27px;
  position: relative;
  width: 600px;
}

.internal-2 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: inline-flex;
  gap: 250px;
  justify-content: center;
  left: 40px;
  position: absolute;
  top: 33px;
}

.frame-48095656-1 {
  align-items: center;
  display: inline-flex;
  gap: 12px;
  left: 112px;
  position: absolute;
  top: -8px;
}

.text-75 {
  direction: rtl;
  left: 110px;
  letter-spacing: -0.3px;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 16px;
  white-space: nowrap;
}

.icons56x56-background-2 {
  height: 64px;
  left: 501px;
  position: absolute;
  top: 25px;
  width: 64px;
}

.components-button-main-small-3 {
  align-items: center;
  background-color: var(--squirrel);
  border-radius: 30px;
  display: flex;
  gap: 8px;
  height: 131px;
  justify-content: center;
  margin-bottom: -43px;
  overflow: hidden;
  padding: 14px 27px;
  position: relative;
  width: 600px;
}

.internal-3 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: inline-flex;
  gap: 250px;
  justify-content: center;
  left: 34px;
  position: absolute;
  top: 32px;
}

.icons56x56-background-3 {
  height: 64px;
  left: 466px;
  position: absolute;
  top: 0;
  width: 64px;
}

.text-76 {
  direction: rtl;
  left: 224px;
  letter-spacing: -0.3px;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 14px;
  white-space: nowrap;
}

.iconsax-outlinelogout-2 {
  height: 31px;
  left: 47px;
  position: absolute;
  top: 42px;
  width: 31px;
}

.vector-container-2 {
  height: 29px;
  left: 1px;
  position: relative;
  top: 1px;
  width: 30px;
}

.icons56x56-background-4 {
  align-items: center;
  background-image: url(https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/ellipse-14-1.svg);
  background-size: 100% 100%;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  height: 45px;
  justify-content: flex-end;
  left: 109px;
  min-width: 45px;
  padding: 0 3.2px;
  position: absolute;
  top: 323px;
}

.overlap-group1-8 {
  align-items: flex-end;
  background-image: url(https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/ellipse-15-1.svg);
  background-size: 100% 100%;
  display: flex;
  height: 37px;
  min-width: 39px;
  padding: 0 1.8px;
}

.pharrows-down-up-1 {
  height: 35px;
  margin-bottom: -0.02px;
  width: 35px;
}

.icons56x56-background-5 {
  height: 45px;
  left: 45px;
  position: absolute;
  top: 323px;
  width: 45px;
}

.group_8037-1 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 14px;
  left: 0;
  min-height: 200px;
  position: absolute;
  top: 23px;
  width: 729px;
}

.group_-container-3 {
  height: 129px;
  position: relative;
  width: 668px;
}

.group_8026-3 {
  height: 73px;
  left: 285px;
  position: absolute;
  top: 56px;
  width: 120px;
}

.group_8034-3 {
  align-items: flex-start;
  display: flex;
  gap: 485px;
  height: 104px;
  left: 70px;
  min-width: 537px;
  position: absolute;
  top: 9px;
}

.overlap-group1-9 {
  align-self: flex-end;
  height: 26px;
  margin-bottom: 0;
  position: relative;
  width: 26px;
}

.ellipse_54-3 {
  background-color: var(--white);
  border-radius: 11.24px/10.97px;
  height: 22px;
  left: 2px;
  position: absolute;
  top: 2px;
  width: 22px;
}

.path_441-12 {
  height: 26px;
  left: 11px;
  position: absolute;
  top: 0;
  width: 4px;
}

.path_441-13 {
  height: 4px;
  left: 0;
  position: absolute;
  top: 11px;
  width: 26px;
}

.path_441-14 {
  height: 4px;
  left: 5px;
  position: absolute;
  top: 11px;
  width: 16px;
}

.path_441-15 {
  height: 16px;
  left: 11px;
  position: absolute;
  top: 5px;
  width: 4px;
}

.overlap-group-25 {
  height: 26px;
  margin-top: 0;
  position: relative;
  width: 26px;
}

.group_8035-3 {
  height: 122px;
  left: 0;
  position: absolute;
  top: 0;
  width: 668px;
}

.group_8028-2 {
  align-self: flex-end;
  height: 58px;
  margin-right: 0;
  width: 103px;
}

.group-48095495 {
  height: 366px;
  left: 0;
  position: absolute;
  top: 1129px;
  width: 129px;
}

.icons56x56-background-6 {
  height: 64px;
  left: 626px;
  position: absolute;
  top: 446px;
  width: 64px;
}
</style>
