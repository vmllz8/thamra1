<template>
  <div :class="[`sign_up-2`, className || ``]">
    <div class="overlap-group4">
      <div class="text-21 tajawal-bold-russett-24px">{{ children }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "SignUp",
  props: ["children", "className"],
};
</script>

<style>
.sign_up-2 {
  align-items: flex-start;
  display: flex;
  height: 66px;
  left: 188px;
  min-width: 521px;
  position: absolute;
  top: 916px;
}

.overlap-group4 {
  align-items: flex-start;
  border: 1.01px solid;
  border-color: var(--russett);
  border-radius: 8.08px;
  display: flex;
  height: 66px;
  min-width: 519px;
  padding: 15.4px 178px;
}

.text-21 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 34px;
  text-align: center;
  width: 159px;
}

.sign_up-2.sign_up-3 {
  height: unset;
  left: unset;
  margin-top: 50px;
  position: unset;
  top: unset;
}
</style>
