<template>
  <div class="container-center-horizontal">
    <div class="third screen">
      <div class="overlap-group4-3">
        <img
          class="right_-background"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/right-background.svg"
          alt="Right_Background"
        />
        <div class="right_-group-1">
          <div class="eamil_id-1">
            <div class="overlap-group-33">
              <div class="rectangle-9-1"></div>
              <div class="number-16 poppins-normal-fuscous-gray-14-1px">{{ number }}</div>
            </div>
          </div>
          <div class="text_label-15 tajawal-bold-squirrel-24px">{{ text_Label1 }}</div>
          <div class="overlap-group3-5">
            <div class="password-2">
              <div class="overlap-group1-12">
                <div class="rectangle-9-1"></div>
                <div class="text-95 poppins-normal-fuscous-gray-14-1px">{{ text95 }}</div>
              </div>
            </div>
            <div class="rectangle-10"></div>
            <img
              class="frame"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/frame.svg"
              alt="Frame"
            />
          </div>
          <div class="text-96">{{ text96 }}</div>
          <router-link to="/4th"><img class="login_-now" :src="login_Now" alt="Login_Now" /></router-link>
          <div class="or-1">
            <img
              class="line-1-1"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-1.svg"
              alt="Line 1"
            />
            <div class="text-97 poppins-normal-black-14-1px">{{ text97 }}</div>
            <img
              class="line-2-1"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-2.svg"
              alt="Line 2"
            />
          </div>
          <sign-up :children="signUpProps.children" :className="signUpProps.className" />
        </div>
        <status-bar :className="statusBarProps.className" />
        <img class="logo-thmar-2-2" :src="logoThmar2" alt="Logo thmar  2" />
        <div class="text_label-16">{{ text_Label2 }}</div>
        <div class="text_label-17 tajawal-bold-squirrel-24px">{{ text_Label3 }}</div>
        <div class="rectangle-10-1"></div>
        <img class="mail_icon" :src="mail_Icon" alt="mail_icon" /><img
          class="texture-6"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-1.svg"
          alt="Texture"
        />
        <img
          class="icon-2"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-1.svg"
          alt="icon"
        />
        <img
          class="icon-11"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-2.svg"
          alt="icon"
        />
      </div>
    </div>
  </div>
</template>

<script>
import SignUp from "./SignUp";
import StatusBar from "./StatusBar";
export default {
  name: "Third",
  components: {
    SignUp,
    StatusBar,
  },
  props: [
    "number",
    "text_Label1",
    "text95",
    "text96",
    "login_Now",
    "text97",
    "logoThmar2",
    "text_Label2",
    "text_Label3",
    "mail_Icon",
    "signUpProps",
    "statusBarProps",
  ],
};
</script>

<style>
.third {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  overflow: hidden;
  width: 750px;
}

.overlap-group4-3 {
  height: 1624px;
  margin-left: -1px;
  position: relative;
  width: 765px;
}

.right_-background {
  height: 1272px;
  left: 1px;
  position: absolute;
  top: 184px;
  width: 750px;
}

.right_-group-1 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  left: 128px;
  min-height: 578px;
  padding: 0px 0;
  position: absolute;
  top: 587px;
  width: 637px;
}

.eamil_id-1 {
  align-items: flex-start;
  display: flex;
  margin-left: 0;
  min-width: 635px;
}

.overlap-group-33 {
  height: 66px;
  position: relative;
  width: 633px;
}

.rectangle-9-1 {
  background-color: var(--gallery);
  border-radius: 8.08px;
  height: 66px;
  left: 0;
  position: absolute;
  top: 0;
  width: 519px;
}

.number-16 {
  left: 379px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 22px;
  width: 254px;
}

.text_label-15 {
  align-self: flex-end;
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  margin-right: 126.98px;
  margin-top: 36px;
  min-height: 29px;
  min-width: 121px;
  text-align: center;
}

.overlap-group3-5 {
  height: 67px;
  margin-top: 12px;
  position: relative;
  width: 545px;
}

.password-2 {
  align-items: flex-start;
  display: flex;
  height: 66px;
  left: 0;
  min-width: 545px;
  position: absolute;
  top: 0;
}

.overlap-group1-12 {
  height: 66px;
  position: relative;
  width: 543px;
}

.text-95 {
  direction: rtl;
  left: 369px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: left;
  top: 21px;
  width: 174px;
}

.rectangle-10 {
  background-color: var(--rainee);
  border-radius: 8.08px;
  height: 66px;
  left: 0;
  position: absolute;
  top: 0;
  width: 61px;
}

.frame {
  height: 32px;
  left: 18px;
  position: absolute;
  top: 19px;
  width: 29px;
}

.text-96 {
  color: var(--redwood);
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: var(--font-size-xxs);
  font-weight: 400;
  letter-spacing: 0;
  line-height: normal;
  margin-left: 61px;
  margin-top: 11px;
  min-height: 28px;
  text-align: left;
  text-decoration: underline;
  width: 152px;
}

.login_-now {
  cursor: pointer;
  height: 115px;
  margin-left: -24.23px;
  margin-top: 58px;
  width: 567px;
}

.or-1 {
  align-items: center;
  display: flex;
  height: 28px;
  margin-top: 13px;
  min-width: 520px;
  padding: 0 0px;
}

.line-1-1 {
  height: 1px;
  margin-top: 0.59px;
  width: 223px;
}

.text-97 {
  align-self: flex-end;
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  margin-bottom: 0;
  margin-left: 24px;
  min-height: 28px;
  text-align: left;
  width: 24px;
}

.line-2-1 {
  height: 1px;
  margin-left: 25px;
  margin-top: 0.59px;
  width: 223px;
}

.logo-thmar-2-2 {
  height: 209px;
  left: 276px;
  object-fit: cover;
  position: absolute;
  top: 244px;
  width: 221px;
}

.text_label-16 {
  color: var(--black);
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: var(--font-size-xs);
  font-weight: 700;
  left: 310px;
  letter-spacing: -0.5px;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 433px;
  white-space: nowrap;
}

.text_label-17 {
  direction: rtl;
  left: 521px;
  letter-spacing: -0.5px;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 544px;
}

.rectangle-10-1 {
  background-color: var(--rainee);
  border-radius: 8.08px;
  height: 66px;
  left: 128px;
  position: absolute;
  top: 587px;
  width: 61px;
}

.mail_icon {
  height: 32px;
  left: 144px;
  position: absolute;
  top: 604px;
  width: 29px;
}

.texture-6 {
  height: 1624px;
  left: 1px;
  position: absolute;
  top: 0;
  width: 750px;
}

.icon-2 {
  height: 64px;
  left: 657px;
  position: absolute;
  top: 98px;
  width: 64px;
}

.icon-11 {
  height: 64px;
  left: 31px;
  position: absolute;
  top: 98px;
  width: 64px;
}
</style>
