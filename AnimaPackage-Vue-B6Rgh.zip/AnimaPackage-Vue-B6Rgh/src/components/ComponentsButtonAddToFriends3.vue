<template>
  <div class="components-button-add-to-friends-2"><div class="text-30 tajawal-medium-white-20px">انضم!</div></div>
</template>

<script>
export default {
  name: "ComponentsButtonAddToFriends3",
};
</script>

<style>
.components-button-add-to-friends-2,
.x442,
.components-button-add-to-friends-3,
.components-button-add-to-friends-4,
.components-button-add-to-friends-5,
.components-button-add-to-friends-6 {
  align-items: flex-start;
  background-color: var(--squirrel);
  border-radius: 14px;
  display: flex;
  gap: 8px;
  height: 35px;
  padding: 7px 16px;
  position: relative;
  width: 75px;
}

.text-30,
.text-6-1 {
  direction: rtl;
  letter-spacing: -0.3px;
  line-height: 21px;
  margin-right: -6px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: fit-content;
}
</style>
