<template>
  <div :class="[`frame-48095659-8-1`, className || ``]">
    <div class="nickname-11">
      <div class="text-31 tajawal-medium-licorice-24px">{{ children }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Frame480956594",
  props: ["children", "className"],
};
</script>

<style>
.frame-48095659-8-1 {
  align-items: center;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 13px;
  margin-right: -100px;
  position: relative;
}

.nickname-11 {
  align-items: flex-start;
  display: inline-flex;
  flex: 0 0 auto;
  flex-direction: column;
  position: relative;
}

.text-31 {
  direction: rtl;
  height: 16px;
  letter-spacing: -0.38px;
  line-height: 20.6px;
  margin-top: -1px;
  position: relative;
  text-align: left;
  white-space: nowrap;
  width: 228px;
}

.frame-48095659-8-1.frame-48095659-8 .nickname-11,
.frame-48095659-8-1.frame-48095659-9 .nickname-11,
.frame-48095659-8-1.frame-48095659-10 .nickname-11 {
  height: 21px;
}

.frame-48095659-8-1.frame-48095659-8 .text-31,
.frame-48095659-8-1.frame-48095659-9 .text-31,
.frame-48095659-8-1.frame-48095659-10 .text-31 {
  height: 42px;
  margin-bottom: -20px;
  white-space: unset;
}
</style>
