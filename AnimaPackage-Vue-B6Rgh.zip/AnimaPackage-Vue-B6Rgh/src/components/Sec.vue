<template>
  <div class="container-center-horizontal">
    <div class="sec screen">
      <status-bar />
      <div class="overlap-group1">
        <div class="group-12">
          <div class="flex-row">
            <div class="ellipse-20"></div>
            <img class="logo-thmar-2" :src="logoThmar2" alt="Logo thmar  2" />
            <div class="ellipse-18"></div>
          </div>
          <h1 class="text_label">{{ text_Label1 }}</h1>
          <p class="text_label-1 tajawal-bold-squirrel-24px">{{ text_Label2 }}</p>
          <div class="ellipse-15"></div>
        </div>
        <div class="ellipse-21"></div>
        <div class="group-13">
          <div class="overlap-group">
            <img
              class="vector-7"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-7.svg"
              alt="Vector 7"
            />
            <div class="rectangle-13"></div>
            <div class="rectangle-14"></div>
            <img class="sign_up" :src="sign_Up1" alt="Sign_up" /><img class="sign_up-1" :src="sign_Up2" alt="Sign_up" />
          </div>
        </div>
        <p class="text-2 tajawal-bold-russett-24px" v-html="text2"></p>
      </div>
    </div>
  </div>
</template>

<script>
import StatusBar from "./StatusBar";
export default {
  name: "Sec",
  components: {
    StatusBar,
  },
  props: ["logoThmar2", "text_Label1", "text_Label2", "sign_Up1", "sign_Up2", "text2"],
};
</script>

<style>
.sec {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  flex-direction: column;
  height: 1624px;
  overflow: hidden;
  position: relative;
  width: 750px;
}

.overlap-group1 {
  height: 1994px;
  margin-left: -553px;
  position: relative;
  width: 2040px;
}

.group-12 {
  align-items: center;
  display: flex;
  flex-direction: column;
  left: 0;
  min-height: 1994px;
  position: absolute;
  top: 0;
  width: 1378px;
}

.flex-row {
  align-items: flex-start;
  align-self: flex-end;
  display: flex;
  height: 173px;
  margin-right: 4px;
  margin-top: -2px;
  min-width: 926px;
}

.ellipse-20 {
  border: 4px solid;
  border-color: var(--black);
  border-radius: 66px;
  height: 132px;
  width: 132px;
}

.logo-thmar-2 {
  align-self: flex-end;
  height: 142px;
  margin-left: 268px;
  object-fit: cover;
  width: 161px;
}

.ellipse-18 {
  align-self: center;
  background-color: var(--rainee);
  border-radius: 18px;
  height: 36px;
  margin-bottom: 5px;
  margin-left: 329px;
  width: 36px;
}

.text_label {
  color: var(--squirrel);
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: var(--font-size-xxl);
  font-weight: 700;
  letter-spacing: -0.5px;
  line-height: normal;
  margin-left: 478px;
  min-height: 43px;
  min-width: 134px;
  text-align: center;
  white-space: nowrap;
}

.text_label-1 {
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  margin-left: 476px;
  margin-top: 190px;
  min-height: 29px;
  min-width: 374px;
  text-align: center;
}

.ellipse-15 {
  align-self: flex-start;
  background-color: #f0d7c19e;
  border-radius: 463.5px;
  height: 927px;
  margin-top: 634px;
  width: 927px;
}

.ellipse-21 {
  background-color: var(--gallery);
  border-radius: 463.5px;
  height: 927px;
  left: 1113px;
  position: absolute;
  top: 387px;
  width: 927px;
}

.group-13 {
  align-items: flex-start;
  display: flex;
  height: 1013px;
  justify-content: flex-end;
  left: 468px;
  min-width: 748px;
  padding: 4.9px 0;
  position: absolute;
  top: 377px;
  transform: rotate(52.22deg);
}

.overlap-group {
  height: 957px;
  position: relative;
  width: 953px;
}

.vector-7 {
  height: 595px;
  left: 113px;
  position: absolute;
  top: 181px;
  transform: rotate(-52.22deg);
  width: 750px;
}

.rectangle-13 {
  background-color: #866161;
  border-radius: 20px;
  height: 72px;
  left: 671px;
  position: absolute;
  top: 501px;
  transform: rotate(-14.03deg);
  width: 72px;
}

.rectangle-14 {
  background-color: var(--rainee);
  border-radius: 10px;
  height: 56px;
  left: 378px;
  position: absolute;
  top: 294px;
  width: 56px;
}

.sign_up {
  height: 68px;
  left: -33px;
  position: absolute;
  top: 161px;
  transform: rotate(-52.22deg);
  width: 308px;
}

.sign_up-1 {
  height: 68px;
  left: 38px;
  position: absolute;
  top: 216px;
  transform: rotate(-52.22deg);
  width: 308px;
}

.text-2 {
  direction: rtl;
  left: 576px;
  letter-spacing: -0.5px;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 251px;
  width: 680px;
}
</style>
