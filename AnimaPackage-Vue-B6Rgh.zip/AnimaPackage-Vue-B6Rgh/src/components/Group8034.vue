<template>
  <div :class="[`group_8034`, className || ``]">
    <div class="overlap-group1-4">
      <div class="ellipse_54"></div>
      <img
        class="path_441"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44120-1.svg"
        alt="Path_44120"
      />
      <img
        class="path_441-1"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44121-1.svg"
        alt="Path_44121"
      />
      <img
        class="path_441-2"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44122-1.svg"
        alt="Path_44122"
      />
      <img
        class="path_441-3"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44123-1.svg"
        alt="Path_44123"
      />
    </div>
    <div class="overlap-group-4">
      <div class="ellipse_54"></div>
      <img
        class="path_441"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44116-1.svg"
        alt="Path_44116"
      />
      <img
        class="path_441-1"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44117-1.svg"
        alt="Path_44117"
      />
      <img
        class="path_441-2"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44118-1.svg"
        alt="Path_44118"
      />
      <img
        class="path_441-3"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/path-44119-1.svg"
        alt="Path_44119"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "Group8034",
  props: ["className"],
};
</script>

<style>
.group_8034 {
  align-items: flex-start;
  display: flex;
  gap: 497px;
  height: 109px;
  left: 45px;
  min-width: 551px;
  padding: 0 0px;
  position: absolute;
  top: 10px;
}

.overlap-group1-4 {
  align-self: flex-end;
  height: 27px;
  margin-bottom: 0;
  position: relative;
  width: 27px;
}

.ellipse_54 {
  background-color: var(--white);
  border-radius: 11.54px/11.46px;
  height: 23px;
  left: 2px;
  position: absolute;
  top: 2px;
  width: 23px;
}

.path_441 {
  height: 27px;
  left: 12px;
  position: absolute;
  top: 0;
  width: 4px;
}

.path_441-1 {
  height: 4px;
  left: 0;
  position: absolute;
  top: 11px;
  width: 27px;
}

.path_441-2 {
  height: 4px;
  left: 5px;
  position: absolute;
  top: 11px;
  width: 16px;
}

.path_441-3 {
  height: 16px;
  left: 12px;
  position: absolute;
  top: 5px;
  width: 4px;
}

.overlap-group-4 {
  height: 27px;
  margin-top: 0;
  position: relative;
  width: 27px;
}

.group_8034.group_8034-1,
.group_8034.group_8034-2 {
  justify-content: flex-end;
  padding: unset;
}
</style>
