<template>
  <div :class="[`components-cards-internal-places-number-5`, className || ``]">
    <div class="overlap-group-8">
      <div class="ellipse-68"></div>
      <div class="number-1 abeezee-normal-white-20px">{{ children }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ComponentsCardsInternalPlacesNumber",
  props: ["children", "className"],
};
</script>

<style>
.components-cards-internal-places-number-5 {
  height: 40px;
  position: relative;
  width: 40px;
}

.overlap-group-8 {
  height: 49px;
  position: relative;
  top: 2px;
}

.ellipse-68 {
  background-color: var(--piper);
  border-radius: 20px/19.05px;
  height: 38px;
  left: 0;
  position: absolute;
  top: 0;
  width: 40px;
}

.number-1 {
  left: 13px;
  letter-spacing: -0.38px;
  line-height: 20.6px;
  position: absolute;
  text-align: center;
  top: 9px;
  width: 14px;
}

.components-cards-internal-places-number-5.components-cards-internal-places-number-6 .ellipse-68,
.components-cards-internal-places-number-5.x24 .ellipse-68,
.components-cards-internal-places-number-5.x24-1 .ellipse-68,
.components-cards-internal-places-number-5.components-cards-internal-places-number-8 .ellipse-68,
.components-cards-internal-places-number-5.components-cards-internal-places-number-1 .ellipse-68,
.components-cards-internal-places-number-5.components-cards-internal-places-number-3 .ellipse-68 {
  background-color: var(--redwood);
}

.components-cards-internal-places-number-5.components-cards-internal-places-number .ellipse-68,
.components-cards-internal-places-number-5.components-cards-internal-places-number-2 .ellipse-68,
.components-cards-internal-places-number-5.components-cards-internal-places-number-4 .ellipse-68 {
  background-color: var(--almond);
}
</style>
