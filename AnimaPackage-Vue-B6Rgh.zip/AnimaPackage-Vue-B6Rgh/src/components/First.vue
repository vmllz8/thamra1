<template>
  <div class="container-center-horizontal">
    <div class="first screen">
      <div class="overlap-group-34" :style="{ 'background-image': 'url(' + overlapGroup + ')' }">
        <img class="group-13-1" :src="group13" alt="Group 13" /><router-link
          to="/sec"
          className="align-self-flex-center"
          ><img class="frame-27" :src="frame27" alt="Frame 27"
        /></router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "First",
  props: ["overlapGroup", "group13", "frame27"],
};
</script>

<style>
.first {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  height: 1624px;
  width: 750px;
}

.overlap-group-34 {
  align-items: flex-start;
  background-size: 100% 100%;
  display: flex;
  flex-direction: column;
  gap: 535px;
  min-height: 1624px;
  width: 750px;
}

.group-13-1 {
  height: 837px;
  width: 663px;
}

.frame-27 {
  align-self: center;
  cursor: pointer;
  height: 136px;
  width: 638px;
}
</style>
