<template>
  <div class="frame-48095659-12">
    <div class="components-cards-internal-places-number-10">
      <div class="overlap-group-14">
        <div class="ellipse-68-2"></div>
        <div class="number-7 abeezee-normal-white-20px">4</div>
      </div>
    </div>
    <div class="frame-48095659-13">
      <nickname :children="nicknameProps.children" :className="nicknameProps.className" />
    </div>
  </div>
</template>

<script>
import Nickname from "./Nickname";
export default {
  name: "Frame480956596",
  components: {
    Nickname,
  },
  props: ["nicknameProps"],
};
</script>

<style>
.frame-48095659-12,
.x42,
.x42-1 {
  align-items: center;
  display: flex;
  gap: 30px;
  position: relative;
  width: 198px;
}

.components-cards-internal-places-number-10,
.components-cards-internal-places-number-11,
.components-cards-internal-places-number-12 {
  height: 40px;
  position: relative;
  width: 40px;
}

.overlap-group-14,
.overlap-group-15,
.overlap-group-16 {
  height: 47px;
  position: relative;
  top: 2px;
}

.ellipse-68-2,
.ellipse-68-3,
.ellipse-68-4 {
  background-color: var(--gamboge);
  border-radius: 20px/19.05px;
  height: 38px;
  left: 0;
  position: absolute;
  top: 0;
  width: 40px;
}

.number-7,
.number-8,
.number-9 {
  left: 13px;
  letter-spacing: -0.38px;
  line-height: 20.6px;
  position: absolute;
  text-align: center;
  top: 7px;
  width: 14px;
}

.frame-48095659-13,
.frame-48095659-14,
.frame-48095659-15 {
  align-items: center;
  display: flex;
  gap: 13px;
  height: 42px;
  margin-right: -142px;
  position: relative;
  width: 270px;
}
</style>
