<template>
  <div :class="[`header`, className || ``]">
    <router-link to="/4th"
      ><article
        class="icon-3"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-3.svg"
        alt="icon"
      />
    </router-link>
    <article
      class="icon-4"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-1.svg"
      alt="icon"
    />
  </div>
</template>

<script>
export default {
  name: "Frame282",
  props: ["className"],
};
</script>

<style>
.header {
  align-items: center;
  background-color: var(--primarywhite);
  display: flex;
  gap: 562px;
  height: 84px;
  left: 27px;
  padding: 0 30px;
  position: absolute;
  top: 88px;
  width: 750px;
}

.icon-3 {
  cursor: pointer;
  height: 64px;
  width: 64px;
}

.icon-4 {
  height: 64px;
  width: 64px;
}

.header.frame-28-1 .icon-3 {
  cursor: unset;
}

.header.frame-28-2,
.header.frame-28-4 {
  left: 0;
}

.header.frame-28-3 {
  left: 8px;
}

.header.frame-28-1 .icon-4 {
  cursor: unset;
  height: 64px;
  width: 64px;
}
</style>
