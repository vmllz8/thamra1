<template>
  <div :class="[`nickname-6`, className || ``]">
    <div class="text-29-1 tajawal-medium-licorice-24px">{{ children }}</div>
  </div>
</template>

<script>
export default {
  name: "Nickname",
  props: ["children", "className"],
};
</script>

<style>
.nickname-6 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  position: relative;
  width: 168px;
}

.text-29-1 {
  direction: rtl;
  height: 1px;
  letter-spacing: -0.38px;
  line-height: 20.6px;
  margin-right: -59px;
  margin-top: -1px;
  position: relative;
  text-align: left;
  white-space: nowrap;
  width: 227px;
}

.nickname-6.nickname-7 .text-29-1,
.nickname-6.nickname-1-2 .text-29-1,
.nickname-6.nickname-2-2 .text-29-1 {
  height: 14px;
  margin-right: -98px;
  width: 266px;
}

.nickname-6.nickname-8 .text-29-1,
.nickname-6.nickname-1-3 .text-29-1,
.nickname-6.nickname-2-3 .text-29-1 {
  height: 29px;
  margin-right: -86px;
  white-space: unset;
  width: 254px;
}

.nickname-6.nickname-9 .text-29-1,
.nickname-6.nickname-1-4 .text-29-1,
.nickname-6.nickname-2-4 .text-29-1 {
  height: 21px;
  margin-right: -141px;
  width: 309px;
}

.nickname-6.nickname-10 .text-29-1,
.nickname-6.nickname-1-5 .text-29-1,
.nickname-6.nickname-2-5 .text-29-1 {
  height: 13px;
  margin-right: -65px;
  width: 233px;
}

.nickname-6.nickname .text-29-1,
.nickname-6.nickname-1 .text-29-1,
.nickname-6.nickname-2 .text-29-1 {
  height: 21px;
  margin-right: -64px;
  width: 232px;
}

.nickname-6.nickname-3,
.nickname-6.nickname-4,
.nickname-6.nickname-5 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  height: 21px;
  position: relative;
  width: 168px;
}

.nickname-6.nickname-3 .text-29-1,
.nickname-6.nickname-4 .text-29-1,
.nickname-6.nickname-5 .text-29-1 {
  height: 42px;
  margin-bottom: -20px;
  margin-right: -60px;
  white-space: unset;
  width: 228px;
}
</style>
