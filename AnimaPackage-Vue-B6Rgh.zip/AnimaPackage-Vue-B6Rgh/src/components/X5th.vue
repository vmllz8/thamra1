<template>
  <div class="container-center-horizontal">
    <div class="x5th screen">
      <div class="overlap-group2-3">
        <div class="rectangle-89"></div>
        <status-bar :className="statusBarProps.className" />
        <frame282 :className="frame282Props.className" />
        <div class="rectangle-87"></div>
        <div class="text-101 tajawal-extra-bold-black-30px">{{ text101 }}</div>
        <img class="group-48095487" :src="group48095487" alt="Group 48095487" />
        <div class="icons56x56-background-7">
          <div class="overlap-group-35">
            <img
              class="stop-svgrepo-com-1"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/stop-svgrepo-com-1.svg"
              alt="stop-svgrepo-com 1"
            />
          </div>
        </div>
        <img
          class="icons56x56-background-8"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-5.svg"
          alt="Icons/56x56/Background"
        />
        <img
          class="texture-7"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-3.svg"
          alt="Texture"
        />
        <div class="components-button-main-small-4">
          <div class="components-cards-internal-add-1"></div>
          <img
            class="icons56x56-background-9"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icons-56x56-background-6.svg"
            alt="Icons/56x56/Background"
          />
          <img
            class="texture-8"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-4.svg"
            alt="Texture"
          />
        </div>
        <div class="text-32 tajawal-extra-bold-black-32px">{{ text }}</div>
        <div class="overlap-group1-13 tajawal-normal-black-16px">
          <div class="rectangle-91-5"></div>
          <div class="frame-21-6">
            <router-link to="/11th" className="align-self-flex-center"
              ><img
                class="vuesaxoutlineframe-6"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-2.svg"
                alt="vuesax/outline/frame"
              />
            </router-link>
            <div class="text-102 tajawal-normal-black-16px">{{ text102 }}</div>
          </div>
          <router-link to="/6th"
            ><img
              class="iconsax-linearmenuboard-6"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard.svg"
              alt="Iconsax/Linear/menuboard"
            />
          </router-link>
          <div class="text-103">{{ text103 }}</div>
          <router-link to="/10th">
            <div class="icons-other-sizes-star-8" :style="{ 'background-image': 'url(' + iconsOthersizesStar + ')' }">
              <img class="rectangle-65-8" :src="rectangle65" alt="Rectangle 65" /><img
                class="star-3-10"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-7.svg"
                alt="Star 3"
              /></div
          ></router-link>
          <div class="text-104">{{ text104 }}</div>
          <router-link to="/5th"
            ><img
              class="iconsax-linearedit2-6"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2-2.svg"
              alt="Iconsax/Linear/edit2"
            />
          </router-link>
          <div class="text-105">{{ text105 }}</div>
          <img
            class="union-6"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-2.svg"
            alt="Union"
          />
          <div class="text-106">{{ text106 }}</div>
          <img
            class="iconsax-outlinehome3-6"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3.svg"
            alt="Iconsax/Outline/home3"
          />
        </div>
        <h1 class="text-107">{{ text107 }}</h1>
      </div>
    </div>
  </div>
</template>

<script>
import StatusBar from "./StatusBar";
import Frame282 from "./Frame282";
export default {
  name: "X5th",
  components: {
    StatusBar,
    Frame282,
  },
  props: [
    "text101",
    "group48095487",
    "text",
    "text102",
    "text103",
    "iconsOthersizesStar",
    "rectangle65",
    "text104",
    "text105",
    "text106",
    "text107",
    "statusBarProps",
    "frame282Props",
  ],
};
</script>

<style>
.x5th {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  width: 750px;
}

.overlap-group2-3 {
  height: 1624px;
  position: relative;
  width: 750px;
}

.rectangle-89 {
  background-color: var(--albescent-white);
  border: 6px solid;
  border-color: #ffffff4c;
  border-radius: 50px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 776px;
  left: 42px;
  position: absolute;
  top: 339px;
  width: 658px;
}

.rectangle-87 {
  background-color: var(--moon-mist);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 68px;
  left: 175px;
  position: absolute;
  top: 172px;
  width: 390px;
}

.text-101 {
  direction: rtl;
  left: 292px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: left;
  text-shadow: 0px 4px 4px #00000040;
  top: 190px;
  white-space: nowrap;
  width: 288px;
}

.group-48095487 {
  height: 642px;
  left: 35px;
  position: absolute;
  top: 727px;
  width: 670px;
}

.icons56x56-background-7 {
  align-items: flex-start;
  background-image: url(https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/ellipse-14.svg);
  background-size: 100% 100%;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  height: 73px;
  left: 62px;
  min-width: 75px;
  padding: 6.5px 5.3px;
  position: absolute;
  top: 727px;
}

.overlap-group-35 {
  align-items: flex-start;
  background-image: url(https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/ellipse-15.svg);
  background-size: 100% 100%;
  display: flex;
  height: 60px;
  min-width: 64px;
  padding: 4.5px 8.7px;
}

.stop-svgrepo-com-1 {
  height: 51px;
  width: 46px;
}

.icons56x56-background-8 {
  height: 81px;
  left: 56px;
  position: absolute;
  top: 302px;
  width: 83px;
}

.texture-7 {
  height: 1624px;
  left: 0;
  position: absolute;
  top: 0;
  width: 750px;
}

.components-button-main-small-4 {
  align-items: center;
  background-color: #808080;
  border-radius: 30px;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 250px;
  justify-content: center;
  left: 61px;
  overflow: hidden;
  padding: 14px 27px;
  position: absolute;
  top: 1080px;
  width: 625px;
}

.components-cards-internal-add-1 {
  background-color: var(--primarywhite);
  border-radius: 30px;
  height: 237px;
  margin-bottom: -7.5px;
  margin-left: -18.5px;
  margin-right: -18.5px;
  margin-top: -7.5px;
  position: relative;
  width: 608px;
}

.icons56x56-background-9 {
  height: 63px;
  left: 18px;
  position: absolute;
  top: 25px;
  width: 66px;
}

.texture-8 {
  height: 250px;
  left: 0;
  position: absolute;
  top: 0;
  width: 625px;
}

.text-32 {
  -webkit-text-stroke: 3px var(--primarywhite);
  left: 214px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 995px;
  white-space: nowrap;
}

.overlap-group1-13 {
  height: 142px;
  left: 42px;
  position: absolute;
  top: 1428px;
  width: 670px;
}

.rectangle-91-5 {
  background-color: var(--concrete);
  border-radius: 31px;
  box-shadow: 0px 4px 4px #00000087;
  height: 125px;
  left: 0;
  position: absolute;
  top: 17px;
  width: 670px;
}

.frame-21-6 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 17px;
  left: 10px;
  min-height: 122px;
  padding: 24.8px 30.8px;
  position: absolute;
  top: 17px;
  width: 124px;
}

.vuesaxoutlineframe-6 {
  align-self: center;
  cursor: pointer;
  height: 33px;
  margin-right: 0.39px;
  margin-top: 3px;
  width: 33px;
}

.text-102 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 60px;
  text-align: center;
  white-space: nowrap;
}

.iconsax-linearmenuboard-6 {
  cursor: pointer;
  height: 27px;
  left: 439px;
  position: absolute;
  top: 53px;
  width: 29px;
}

.text-103 {
  direction: rtl;
  left: 415px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 97px;
  white-space: nowrap;
}

.icons-other-sizes-star-8 {
  align-items: center;
  background-size: 100% 100%;
  cursor: pointer;
  display: flex;
  gap: 550px;
  height: 29px;
  left: 568px;
  min-width: 34px;
  position: absolute;
  top: 51px;
}

.rectangle-65-8 {
  align-self: flex-end;
  height: 24px;
  margin-bottom: -1914.1px;
  margin-left: -569px;
  width: 28px;
}

.star-3-10 {
  height: 13px;
  margin-bottom: 0.91px;
  width: 14px;
}

.text-104 {
  direction: rtl;
  left: 525px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 97px;
  white-space: nowrap;
}

.iconsax-linearedit2-6 {
  cursor: pointer;
  height: 30px;
  left: 186px;
  position: absolute;
  top: 48px;
  width: 32px;
}

.text-105 {
  direction: rtl;
  left: 164px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 97px;
  white-space: nowrap;
}

.union-6 {
  height: 64px;
  left: 149px;
  position: absolute;
  top: 0;
  width: 104px;
}

.text-106 {
  direction: rtl;
  left: 300px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 97px;
  white-space: nowrap;
}

.iconsax-outlinehome3-6 {
  height: 30px;
  left: 309px;
  position: absolute;
  top: 51px;
  width: 31px;
}

.text-107 {
  -webkit-text-stroke: 3px var(--primarywhite);
  color: var(--black);
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: 32px;
  font-weight: 700;
  left: 200px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: left;
  text-shadow: 0px 4px 4px #00000040;
  top: 1093px;
  white-space: nowrap;
}
</style>
