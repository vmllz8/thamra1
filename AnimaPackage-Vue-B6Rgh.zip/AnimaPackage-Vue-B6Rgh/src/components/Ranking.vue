<template>
  <div class="ranking screen">
    <div class="ranking-1">
      <div class="overlap-group3-4">
        <div class="x1-4 tajawal-extra-bold-black-36px">
          <img
            class="x1-4-item"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-1-1.svg"
            alt="Vector 1"
          />
          <h1 class="text-91">
            <span class="tajawal-extra-bold-black-36px">{{ spanText1 }}</span
            ><span class="tajawal-extra-bold-black-25px">{{ spanText2 }}</span>
          </h1>
          <img
            class="x1-4-item"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
            alt="2"
          />
          <p class="text-92">
            <span class="tajawal-extra-bold-black-36px">{{ spanText3 }}</span
            ><span class="tajawal-extra-bold-black-25px">{{ spanText4 }}</span>
          </p>
          <img
            class="x1-4-item"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
            alt="3"
          />
          <p class="text-93">
            <span class="tajawal-extra-bold-black-36px">{{ spanText5 }}</span
            ><span class="tajawal-extra-bold-black-25px">{{ spanText6 }}</span>
          </p>
          <img
            class="x1-4-item"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2-1.svg"
            alt="4"
          />
          <p class="text-94">
            <span class="tajawal-extra-bold-black-36px">{{ spanText7 }}</span
            ><span class="tajawal-extra-bold-black-25px">{{ spanText8 }}</span>
          </p>
          <div class="group-48095499" :style="{ 'background-image': 'url(' + group48095499 + ')' }">
            <div class="group-48095494">
              <img
                class="star-3-8"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-9.svg"
                alt="Star 3"
              />
            </div>
          </div>
          <icons-other-sizes-star :iconsOthersizesStar="iconsOtherSizesStar1Props.iconsOthersizesStar" />
          <div class="group-48095495-1" :style="{ 'background-image': 'url(' + group48095495 + ')' }">
            <div class="overlap-group1-11">
              <img
                class="star-4"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-4-1.svg"
                alt="Star 4"
              />
              <img
                class="rectangle-66"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-66-1.svg"
                alt="Rectangle 66"
              />
            </div>
          </div>
          <icons-other-sizes-star
            :iconsOthersizesStar="iconsOtherSizesStar2Props.iconsOthersizesStar"
            :className="iconsOtherSizesStar2Props.className"
          />
        </div>
        <router-link to="/10th">
          <div class="components-tabs-variants-challenges-3">
            <div class="home-work1-1">
              <div class="text_label-14">{{ text_Label }}</div>
            </div>
          </div></router-link
        >
      </div>
    </div>
  </div>
</template>

<script>
import IconsOtherSizesStar from "./IconsOtherSizesStar";
export default {
  name: "Ranking",
  components: {
    IconsOtherSizesStar,
  },
  props: [
    "spanText1",
    "spanText2",
    "spanText3",
    "spanText4",
    "spanText5",
    "spanText6",
    "spanText7",
    "spanText8",
    "group48095499",
    "group48095495",
    "text_Label",
    "iconsOtherSizesStar1Props",
    "iconsOtherSizesStar2Props",
  ],
};
</script>

<style>
.ranking {
  align-items: flex-start;
  background-color: #ffffff4c;
  display: flex;
  height: 1322px;
  width: 750px;
}

.ranking-1::-webkit-scrollbar,
.x1-4::-webkit-scrollbar {
  display: none;
  width: 0;
}

.ranking-1 {
  align-items: flex-end;
  background-color: var(--primarywhite);
  border-radius: 50px 50px 0px 0px;
  display: flex;
  height: 1322px;
  overflow: hidden;
  overflow-y: scroll;
  width: 750px;
}

.overlap-group3-4 {
  height: 1679px;
  margin-bottom: -372px;
  margin-left: -128px;
  position: relative;
  width: 1171px;
}

.x1-4 {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 40px;
  height: 1679px;
  left: 0;
  overflow-y: scroll;
  position: absolute;
  top: 0;
  width: 1171px;
}

.x1-4-item {
  height: 1px;
  object-fit: cover;
  position: relative;
  width: 341px;
}

.text-91 {
  direction: rtl;
  height: 229px;
  letter-spacing: 0;
  line-height: normal;
  position: relative;
  width: 469px;
}

.text-92 {
  direction: rtl;
  height: 223px;
  letter-spacing: 0;
  line-height: normal;
  position: relative;
  width: 483px;
}

.text-93 {
  direction: rtl;
  height: 216px;
  letter-spacing: 0;
  line-height: normal;
  position: relative;
  width: 489px;
}

.text-94 {
  direction: rtl;
  height: 271px;
  letter-spacing: 0;
  line-height: normal;
  position: relative;
  width: 504px;
}

.group-48095499 {
  background-size: 100% 100%;
  height: 102px;
  left: 213px;
  position: absolute;
  top: 40px;
  width: 92px;
}

.group-48095494 {
  align-items: flex-end;
  background-image: url(https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-9.svg);
  background-size: 100% 100%;
  display: flex;
  height: 83px;
  left: 8px;
  min-width: 77px;
  padding: 14.6px 13.5px;
  position: relative;
  top: 8px;
}

.star-3-8 {
  height: 54px;
  width: 49px;
}

.group-48095495-1 {
  background-size: 100% 100%;
  height: 102px;
  left: 213px;
  position: absolute;
  top: 660px;
  width: 92px;
}

.overlap-group1-11 {
  height: 83px;
  left: 8px;
  position: relative;
  top: 8px;
  width: 77px;
}

.star-4 {
  height: 54px;
  left: 13px;
  position: absolute;
  top: 15px;
  width: 49px;
}

.rectangle-66 {
  height: 83px;
  left: 0;
  position: absolute;
  top: 0;
  width: 77px;
}

.components-tabs-variants-challenges-3 {
  align-items: center;
  background-color: var(--primarywhite);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 10px;
  height: 74px;
  justify-content: center;
  left: 333px;
  overflow: hidden;
  padding: 3px;
  position: absolute;
  top: 1179px;
  width: 323px;
}

.home-work1-1 {
  align-items: center;
  background-color: var(--rainee);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 51px;
  justify-content: center;
  padding: 14px 23px;
  position: relative;
  width: 306px;
}

.text_label-14 {
  color: var(--redwood);
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: var(--font-size-m);
  font-weight: 700;
  letter-spacing: -0.5px;
  line-height: normal;
  margin-bottom: -2px;
  margin-left: -12px;
  margin-right: -12px;
  margin-top: -4px;
  position: relative;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
  width: fit-content;
}

#overlay-ranking {
  align-items: center;
  background-color: #ffffff4d;
  justify-content: center;
}
</style>
