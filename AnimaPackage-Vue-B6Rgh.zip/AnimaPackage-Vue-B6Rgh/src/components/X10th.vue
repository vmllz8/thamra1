<template>
  <div class="container-center-horizontal">
    <div class="x10th screen">
      <img class="ellipse-709" :src="ellipse709" alt="Ellipse 709" />
      <div class="overlap-group11">
        <status-bar :className="statusBarProps.className" />
        <frame282 :className="frame282Props.className" />
        <div class="rectangle-70"></div>
        <div class="text-78 tajawal-extra-bold-black-30px">{{ text78 }}</div>
        <div class="text-79 tajawal-extra-bold-black-20px">{{ text79 }}</div>
        <div class="rectangle-85"></div>
        <img
          class="line-3"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-3.svg"
          alt="Line 3"
        />
        <div class="overlap-group-26">
          <div class="rectangle-86"></div>
          <div class="text-80">{{ text80 }}</div>
        </div>
        <div class="overlap-group1-10">
          <div class="text-81 tajawal-extra-bold-black-25px">{{ text81 }}</div>
          <div class="overlap-group-27">
            <div class="rectangle"></div>
            <img
              class="rectangle-77"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-77.svg"
              alt="Rectangle 77"
            />
            <div class="phone tajawal-extra-bold-black-20px">{{ phone1 }}</div>
          </div>
        </div>
        <div class="overlap-group2-2">
          <div class="text-82 tajawal-extra-bold-black-25px">{{ text82 }}</div>
          <div class="overlap-group-28">
            <div class="rectangle"></div>
            <div class="rectangle-79"></div>
            <div class="phone-1 tajawal-extra-bold-black-20px">{{ phone2 }}</div>
          </div>
        </div>
        <div class="overlap-group3-3">
          <div class="text-83 tajawal-extra-bold-black-25px">{{ text83 }}</div>
          <div class="overlap-group-29">
            <div class="rectangle"></div>
            <img class="rectangle-81" :src="rectangle81" alt="Rectangle 81" />
            <div class="phone-2 tajawal-extra-bold-black-20px">{{ phone3 }}</div>
          </div>
        </div>
        <div class="group-48095502">
          <img class="rectangle-69" :src="rectangle69" alt="Rectangle 69" />
          <div class="overlap-group4-2" :style="{ 'background-image': 'url(' + overlapGroup4 + ')' }">
            <div class="text-85 tajawal-extra-bold-black-25px">{{ text85 }}</div>
            <div class="overlap-group-30">
              <img
                class="rectangle-82"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-82.svg"
                alt="Rectangle 82"
              />
              <div class="rectangle-83"></div>
              <div class="text-84 tajawal-extra-bold-black-20px">{{ text84 }}</div>
            </div>
          </div>
        </div>
        <h1 class="title tajawal-extra-bold-black-32px">{{ title }}</h1>
        <img
          class="texture-5"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-2.svg"
          alt="Texture"
        />
        <div class="overlap-group5-1 tajawal-normal-black-16px">
          <div class="rectangle-91-4"></div>
          <div class="frame-21-5">
            <router-link to="/11th" className="align-self-flex-center"
              ><img
                class="vuesaxoutlineframe-5"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-1.svg"
                alt="vuesax/outline/frame"
              />
            </router-link>
            <div class="text-86 tajawal-normal-black-16px">{{ text86 }}</div>
          </div>
          <img
            class="iconsax-linearmenuboard-5"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-1.svg"
            alt="Iconsax/Linear/menuboard"
          />
          <div class="text-87">{{ text87 }}</div>
          <div class="icons-other-sizes-star-5" :style="{ 'background-image': 'url(' + iconsOthersizesStar + ')' }">
            <img class="rectangle-65-6" :src="rectangle651" alt="Rectangle 65" /><img
              class="star-3-6"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-2.svg"
              alt="Star 3"
            />
          </div>
          <div class="text-88">{{ text88 }}</div>
          <router-link to="/5th"
            ><img
              class="iconsax-linearedit2-5"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              alt="Iconsax/Linear/edit2"
            />
          </router-link>
          <div class="text-89">{{ text89 }}</div>
          <img
            class="union-5"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-1.svg"
            alt="Union"
          />
          <div class="text-90">{{ text90 }}</div>
          <img
            class="iconsax-outlinehome3-5"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
            alt="Iconsax/Outline/home3"
          />
        </div>
        <div class="rectangle-76"></div>
        <div class="overlap-group6" :style="{ 'background-image': 'url(' + overlapGroup6 + ')' }">
          <div class="overlap-group-31">
            <img
              class="star-3-7"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-3.svg"
              alt="Star 3"
            />
          </div>
        </div>
        <div class="overlap-group7" :style="{ 'background-image': 'url(' + overlapGroup7 + ')' }">
          <img
            class="star"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
            alt="Star 3"
          />
          <img
            class="rectangle-6"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-4.svg"
            alt="Rectangle 65"
          />
        </div>
        <div class="overlap-group8" :style="{ 'background-image': 'url(' + overlapGroup8 + ')' }">
          <img
            class="star"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-4.svg"
            alt="Star 4"
          />
          <img
            class="rectangle-6"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-66.svg"
            alt="Rectangle 66"
          />
        </div>
        <div class="overlap-group9" :style="{ 'background-image': 'url(' + overlapGroup9 + ')' }">
          <img
            class="star"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
            alt="Star 3"
          />
          <img
            class="rectangle-6"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-5.svg"
            alt="Rectangle 65"
          />
        </div>
        <div class="overlap-group10" :style="{ 'background-image': 'url(' + overlapGroup10 + ')' }">
          <img
            class="star"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
            alt="Star 3"
          />
          <img
            class="rectangle-6"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-6.svg"
            alt="Rectangle 65"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import StatusBar from "./StatusBar";
import Frame282 from "./Frame282";
export default {
  name: "X10th",
  components: {
    StatusBar,
    Frame282,
  },
  props: [
    "ellipse709",
    "text78",
    "text79",
    "text80",
    "text81",
    "phone1",
    "text82",
    "phone2",
    "text83",
    "rectangle81",
    "phone3",
    "rectangle69",
    "overlapGroup4",
    "text85",
    "text84",
    "title",
    "text86",
    "text87",
    "iconsOthersizesStar",
    "rectangle651",
    "text88",
    "text89",
    "text90",
    "overlapGroup6",
    "overlapGroup7",
    "overlapGroup8",
    "overlapGroup9",
    "overlapGroup10",
    "statusBarProps",
    "frame282Props",
  ],
};
</script>

<style>
.x10th {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  gap: 2218px;
  overflow: hidden;
  width: 750px;
}

.ellipse-709 {
  height: 102px;
  margin-left: -2340px;
  margin-top: 4274px;
  width: 113px;
}

.overlap-group11 {
  height: 1624px;
  position: relative;
  width: 758px;
}

.rectangle-70 {
  background-color: var(--moon-mist);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 68px;
  left: 188px;
  position: absolute;
  top: 177px;
  width: 390px;
}

.text-78 {
  direction: rtl;
  left: 268px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: left;
  text-shadow: 0px 4px 4px #00000040;
  top: 190px;
  width: 321px;
}

.text-79 {
  left: 575px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 340px;
  width: 113px;
}

.rectangle-85 {
  background-color: var(--apple);
  border: 1px solid;
  border-color: transparent;
  border-radius: 14px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 15px;
  left: 287px;
  position: absolute;
  top: 343px;
  width: 78px;
}

.line-3 {
  height: 12px;
  left: 58px;
  object-fit: cover;
  position: absolute;
  top: 442px;
  width: 634px;
}

.overlap-group-26 {
  height: 26px;
  left: 673px;
  position: absolute;
  top: 337px;
  width: 76px;
}

.rectangle-86 {
  background-color: var(--moon-mist);
  border-radius: 10px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 26px;
  left: 0;
  position: absolute;
  top: 0;
  width: 75px;
}

.text-80 {
  color: var(--black);
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: 15px;
  font-weight: 800;
  left: 14px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: left;
  text-shadow: 0px 4px 4px #00000040;
  top: 4px;
  white-space: nowrap;
  width: 62px;
}

.overlap-group1-10 {
  align-items: flex-end;
  background-color: var(--albescent-white);
  border-radius: 21px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  flex-direction: column;
  gap: 14px;
  left: 43px;
  min-height: 181px;
  padding: 26px 1px;
  position: absolute;
  top: 493px;
  width: 666px;
}

.text-81 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 29px;
  text-align: left;
  text-shadow: 0px 4px 4px #00000040;
  white-space: nowrap;
  width: 188px;
}

.overlap-group-27 {
  height: 30px;
  margin-right: 27px;
  position: relative;
  width: 412px;
}

.rectangle {
  background-color: var(--alto);
  border-radius: 7px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 30px;
  left: 0;
  position: absolute;
  top: 0;
  width: 383px;
}

.rectangle-77 {
  height: 23px;
  left: 2px;
  position: absolute;
  top: 7px;
  width: 295px;
}

.phone {
  left: 299px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 5px;
  white-space: nowrap;
  width: 113px;
}

.overlap-group2-2 {
  align-items: flex-end;
  background-color: var(--albescent-white);
  border-radius: 21px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  flex-direction: column;
  gap: 21px;
  left: 48px;
  min-height: 181px;
  padding: 24px 9px;
  position: absolute;
  top: 714px;
  width: 666px;
}

.text-82 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 28px;
  text-align: left;
  text-shadow: 0px 4px 4px #00000040;
  white-space: nowrap;
  width: 166px;
}

.overlap-group-28 {
  height: 30px;
  margin-right: 12px;
  position: relative;
  width: 412px;
}

.rectangle-79 {
  background-color: var(--apple);
  border-radius: 14px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 15px;
  left: 6px;
  position: absolute;
  top: 7px;
  width: 220px;
}

.phone-1 {
  left: 299px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 4px;
  white-space: nowrap;
  width: 113px;
}

.overlap-group3-3 {
  align-items: flex-end;
  background-color: var(--albescent-white);
  border-radius: 21px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  flex-direction: column;
  left: 52px;
  min-height: 181px;
  padding: 23px;
  position: absolute;
  top: 935px;
  width: 666px;
}

.text-83 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 44px;
  text-align: left;
  text-shadow: 0px 4px 4px #00000040;
  width: 199px;
}

.overlap-group-29 {
  height: 31px;
  margin-right: 5px;
  position: relative;
  width: 421px;
}

.rectangle-81 {
  height: 23px;
  left: 8px;
  position: absolute;
  top: 8px;
  width: 142px;
}

.phone-2 {
  left: 308px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 5px;
  white-space: nowrap;
  width: 113px;
}

.group-48095502 {
  align-items: flex-start;
  display: flex;
  gap: 2847px;
  height: 207px;
  left: 48px;
  min-width: 670px;
  position: absolute;
  top: 1164px;
}

.rectangle-69 {
  align-self: flex-end;
  height: 113px;
  margin-bottom: -3396px;
  margin-left: -3436px;
  width: 585px;
}

.overlap-group4-2 {
  align-items: flex-end;
  background-size: 100% 100%;
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-height: 189px;
  padding: 20px 24px;
  width: 674px;
}

.text-85 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  margin-right: 19px;
  min-height: 39px;
  text-align: left;
  text-shadow: 0px 4px 4px #00000040;
  width: 175px;
}

.overlap-group-30 {
  height: 38px;
  position: relative;
  width: 416px;
}

.rectangle-82 {
  height: 38px;
  left: 0;
  position: absolute;
  top: 0;
  width: 391px;
}

.rectangle-83 {
  background-color: #74ad46;
  border-radius: 14px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 15px;
  left: 10px;
  position: absolute;
  top: 7px;
  width: 41px;
}

.text-84 {
  left: 303px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 5px;
  white-space: nowrap;
  width: 113px;
}

.title {
  left: 566px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 278px;
  white-space: nowrap;
  width: 177px;
}

.texture-5 {
  height: 1624px;
  left: 8px;
  position: absolute;
  top: 0;
  width: 750px;
}

.overlap-group5-1 {
  height: 143px;
  left: 50px;
  position: absolute;
  top: 1427px;
  width: 670px;
}

.rectangle-91-4 {
  background-color: var(--concrete);
  border-radius: 31px;
  box-shadow: 0px 4px 4px #00000087;
  height: 125px;
  left: 0;
  position: absolute;
  top: 18px;
  width: 670px;
}

.frame-21-5 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 17px;
  left: 10px;
  min-height: 122px;
  padding: 24.8px 30.8px;
  position: absolute;
  top: 18px;
  width: 124px;
}

.vuesaxoutlineframe-5 {
  align-self: center;
  cursor: pointer;
  height: 33px;
  margin-right: 0.39px;
  margin-top: 3px;
  width: 33px;
}

.text-86 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 60px;
  text-align: center;
  white-space: nowrap;
}

.iconsax-linearmenuboard-5 {
  height: 27px;
  left: 439px;
  position: absolute;
  top: 54px;
  width: 29px;
}

.text-87 {
  direction: rtl;
  left: 415px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.icons-other-sizes-star-5 {
  align-items: center;
  background-size: 100% 100%;
  display: flex;
  gap: 4074px;
  height: 29px;
  left: 568px;
  min-width: 34px;
  position: absolute;
  top: 52px;
}

.rectangle-65-6 {
  align-self: flex-end;
  height: 24px;
  margin-bottom: -1914.1px;
  margin-left: -4093px;
  width: 28px;
}

.star-3-6 {
  height: 13px;
  margin-bottom: 0.91px;
  width: 14px;
}

.text-88 {
  direction: rtl;
  left: 525px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-linearedit2-5 {
  cursor: pointer;
  height: 30px;
  left: 186px;
  position: absolute;
  top: 49px;
  width: 32px;
}

.text-89 {
  direction: rtl;
  left: 164px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.union-5 {
  height: 64px;
  left: 533px;
  position: absolute;
  top: 0;
  width: 104px;
}

.text-90 {
  direction: rtl;
  left: 300px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-outlinehome3-5 {
  height: 30px;
  left: 309px;
  position: absolute;
  top: 52px;
  width: 31px;
}

.rectangle-76 {
  background-color: var(--alto);
  border-radius: 7px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 30px;
  left: 264px;
  position: absolute;
  top: 337px;
  width: 383px;
}

.overlap-group6 {
  align-items: flex-start;
  background-size: 100% 100%;
  display: flex;
  height: 108px;
  left: 88px;
  min-width: 100px;
  padding: 8px 7.5px;
  position: absolute;
  top: 522px;
}

.overlap-group-31 {
  align-items: flex-start;
  background-image: url(https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-3.svg);
  background-size: 100% 100%;
  display: flex;
  height: 90px;
  min-width: 85px;
  padding: 22.3px 24.1px;
}

.star-3-7 {
  height: 36px;
  width: 36px;
}

.overlap-group7 {
  background-size: 100% 100%;
  height: 108px;
  left: 88px;
  position: absolute;
  top: 756px;
  width: 100px;
}

.star {
  height: 36px;
  left: 32px;
  position: absolute;
  top: 30px;
  width: 36px;
}

.rectangle-6 {
  height: 90px;
  left: 8px;
  position: absolute;
  top: 8px;
  width: 85px;
}

.overlap-group8 {
  background-size: 100% 100%;
  height: 108px;
  left: 88px;
  position: absolute;
  top: 977px;
  width: 100px;
}

.overlap-group9 {
  background-size: 100% 100%;
  height: 108px;
  left: 84px;
  position: absolute;
  top: 303px;
  width: 100px;
}

.overlap-group10 {
  background-size: 100% 100%;
  height: 108px;
  left: 92px;
  position: absolute;
  top: 1208px;
  width: 100px;
}
</style>
