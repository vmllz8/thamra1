<template>
  <div class="frame-48095659-27">
    <components-cards-internal-places-number2
      :children="componentsCardsInternalPlacesNumber.children"
      :className="componentsCardsInternalPlacesNumber.className"
    />
    <div class="frame-48095659-28">
      <div class="nickname-12">
        <div class="text-47 tajawal-normal-licorice-24px">{{ text47 }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import ComponentsCardsInternalPlacesNumber2 from "./ComponentsCardsInternalPlacesNumber2";
export default {
  name: "Frame4809565911",
  components: {
    ComponentsCardsInternalPlacesNumber2,
  },
  props: ["text47", "componentsCardsInternalPlacesNumber"],
};
</script>

<style>
.frame-48095659-27,
.frame-48095659-29,
.frame-48095659-31 {
  align-items: center;
  display: flex;
  gap: 30px;
  position: relative;
  width: 198px;
}

.frame-48095659-28,
.frame-48095659-30,
.frame-48095659-32 {
  align-items: center;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 13px;
  height: 39px;
  margin-right: -40px;
  position: relative;
}

.nickname-12,
.nickname-13,
.nickname-14 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  position: relative;
  width: 168px;
}

.text-47,
.text_label-10,
.text_label-11 {
  direction: rtl;
  height: 21px;
  letter-spacing: -0.38px;
  line-height: 20.6px;
  margin-right: -60px;
  margin-top: -1px;
  position: relative;
  text-align: left;
  white-space: nowrap;
  width: 228px;
}
</style>
