<template>
  <div :class="[`status-bar`, className || ``]">
    <div class="text-1 abhayalibreextrabold-regular-normal-black-30px">9:41</div>
    <img
      class="cellular-connection"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/cellular-connection.svg"
      alt="Cellular Connection"
    />
    <img
      class="wifi"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/wifi.svg"
      alt="Wifi"
    />
    <img
      class="battery"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/battery@2x.png"
      alt="Battery"
    />
  </div>
</template>

<script>
export default {
  name: "StatusBar",
  props: ["className"],
};
</script>

<style>
.status-bar {
  align-items: center;
  background-color: var(--primarywhite);
  display: flex;
  height: 88px;
  margin-top: 6px;
  padding: 25px 29.3px;
  width: 750px;
}

.text-1 {
  align-self: flex-start;
  letter-spacing: 0;
  line-height: normal;
  margin-left: 35px;
  min-height: 35px;
  min-width: 51px;
  white-space: nowrap;
}

.cellular-connection {
  height: 21px;
  margin-left: 472px;
  margin-top: 4px;
  width: 34px;
}

.wifi {
  height: 22px;
  margin-left: 10px;
  margin-top: 3.26px;
  width: 31px;
}

.battery {
  height: 23px;
  margin-left: 10px;
  margin-top: 4px;
  width: 49px;
}

.status-bar.status-bar-1 {
  left: 6px;
  margin-top: unset;
  position: absolute;
  top: 0;
}

.status-bar.status-bar-2 {
  left: 66px;
  margin-top: unset;
  position: absolute;
  top: 0;
}

.status-bar.status-bar-3,
.status-bar.status-bar-4 {
  left: 27px;
  margin-top: unset;
  position: absolute;
  top: 0;
}

.status-bar.status-bar-5,
.status-bar.status-bar-6,
.status-bar.status-bar-8 {
  left: 0;
  margin-top: unset;
  position: absolute;
  top: 0;
}

.status-bar.status-bar-7 {
  left: 0;
  margin-top: unset;
  position: absolute;
  top: 10px;
}
</style>
