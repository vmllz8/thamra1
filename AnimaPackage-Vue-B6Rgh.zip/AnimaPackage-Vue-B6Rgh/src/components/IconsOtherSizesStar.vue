<template>
  <div
    :class="[`icons-other-sizes-star-6`, className || ``]"
    :style="{ 'background-image': 'url(' + iconsOthersizesStar + ')' }"
  >
    <div class="overlap-group-32">
      <img
        class="star-3-9"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg"
        alt="Star 3"
      />
      <img
        class="rectangle-65-7"
        src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-10.svg"
        alt="Rectangle 65"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "IconsOtherSizesStar",
  props: ["iconsOthersizesStar", "className"],
};
</script>

<style>
.icons-other-sizes-star-6 {
  background-size: 100% 100%;
  box-shadow: 0px 4px 4px #00000040, inset 0px 4px 4px #00000040;
  height: 100px;
  left: 213px;
  position: absolute;
  top: 349px;
  width: 92px;
}

.overlap-group-32 {
  height: 82px;
  left: 8px;
  position: relative;
  top: 8px;
  width: 77px;
}

.star-3-9 {
  height: 53px;
  left: 13px;
  position: absolute;
  top: 15px;
  width: 49px;
}

.rectangle-65-7 {
  height: 82px;
  left: 0;
  position: absolute;
  top: 0;
  width: 77px;
}

.icons-other-sizes-star-6.icons-other-sizes-star-7 {
  background-image: url(https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-11@2x.png);
  top: 964px;
}
</style>
