<template>
  <div class="name-1 screen">
    <div class="name-3"><gr-from1-to10-t v-bind="grFrom1To10TProps" /></div>
  </div>
</template>

<script>
import GrFrom1To10T from "./GrFrom1To10T";
export default {
  name: "Name",
  components: {
    GrFrom1To10T,
  },
  props: ["grFrom1To10TProps"],
};
</script>

<style>
.name-1 {
  align-items: flex-start;
  background-color: #ffffff80;
  display: flex;
  height: 893px;
  position: relative;
  width: 629px;
}

.name-3::-webkit-scrollbar {
  display: none;
  width: 0;
}

.name-3 {
  align-items: flex-end;
  background-color: var(--primarywhite);
  border-radius: 50px 50px 0px 0px;
  display: flex;
  height: 893px;
  overflow: hidden;
  overflow-y: scroll;
  padding: 0 12px;
  position: relative;
  width: 629px;
}

#overlay-name {
  align-items: center;
  background-color: #ffffff80;
  justify-content: center;
}
</style>
