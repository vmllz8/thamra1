<template>
  <div class="x442-1"><div class="x5-2 tajawal-medium-white-16px">استمع</div></div>
</template>

<script>
export default {
  name: "X24",
};
</script>

<style>
.x442-1,
.components-button-add-to-friends-7,
.components-button-add-to-friends-8,
.components-button-add-to-friends-9,
.components-button-add-to-friends-10 {
  align-items: flex-start;
  background-color: var(--squirrel);
  border-radius: 14px;
  display: flex;
  gap: 8px;
  height: 35px;
  padding: 7px 16px;
  position: relative;
  width: 75px;
}

.x5-2,
.x,
.x-1,
.x-2,
.x-3 {
  direction: rtl;
  letter-spacing: -0.3px;
  line-height: 16.8px;
  margin-right: -3px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: fit-content;
}
</style>
