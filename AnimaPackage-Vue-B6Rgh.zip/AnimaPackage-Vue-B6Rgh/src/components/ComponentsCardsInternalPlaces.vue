<template>
  <div class="components-cards-internal-places-6">
    <frame4809565962 :frame480956592Props="frame4809565962Props.frame480956592Props" />
    <components-button-add-to-friends3 />
  </div>
</template>

<script>
import Frame4809565962 from "./Frame4809565962";
import ComponentsButtonAddToFriends3 from "./ComponentsButtonAddToFriends3";
export default {
  name: "ComponentsCardsInternalPlaces",
  components: {
    Frame4809565962,
    ComponentsButtonAddToFriends3,
  },
  props: ["frame4809565962Props"],
};
</script>

<style>
.components-cards-internal-places-6,
.x46 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 200px;
  height: 45px;
  position: relative;
  width: 480px;
}
</style>
