<template>
  <div class="gr-from-1-to-10-t-1">
    <img
      class="gr-from-1-to-10-t-item-1"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-1.svg"
      alt="Vector 1"
    />
    <div class="x1-1">
      <div class="x12-1">
        <frame48095659
          :componentsCardsInternalPlacesNumber="frame48095659Props.componentsCardsInternalPlacesNumber"
          :frame480956592Props="frame48095659Props.frame480956592Props"
        />
        <a
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          target="_blank"
        >
          <div class="link-1">
            <div class="x1-2 tajawal-medium-white-16px">
              <span class="tajawal-medium-white-16px">{{ spanText1 }}</span
              ><span class="span1-1 tajawal-medium-white-20px">{{ spanText2 }}</span>
            </div>
          </div></a
        >
      </div>
    </div>
    <img
      class="gr-from-1-to-10-t-item-1"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="2"
    />
    <div class="x21-1">
      <frame480956593
        :componentsCardsInternalPlacesNumber="frame480956593Props.componentsCardsInternalPlacesNumber"
        :frame480956594Props="frame480956593Props.frame480956594Props"
      />
      <a
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        target="_blank"
      >
        <div class="link-1">
          <div class="x2-1 tajawal-medium-white-16px">{{ x22 }}</div>
        </div></a
      >
    </div>
    <img
      class="gr-from-1-to-10-t-item-1"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="3"
    />
    <div class="x31-1">
      <frame480956595 :frame480956592Props="frame480956595Props.frame480956592Props" />
      <a
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        target="_blank"
      >
        <div class="link-1">
          <div class="x3 tajawal-medium-white-16px">{{ x32 }}</div>
        </div></a
      >
    </div>
    <img
      class="gr-from-1-to-10-t-item-1"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="4"
    />
    <div class="x412-1">
      <a
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        target="_blank"
      >
        <div class="x41-1">
          <frame480956596 :nicknameProps="frame480956596Props.nicknameProps" />
          <components-button-add-to-friends :text36="componentsButtonAddToFriendsProps.text36" /></div
      ></a>
    </div>
    <a
      href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
      target="_blank"
    >
      <div class="x45-1">
        <div class="x46-1">
          <frame4809565962 :frame480956592Props="frame4809565962Props.frame480956592Props" />
          <x24 />
        </div></div></a
    ><img
      class="gr-from-1-to-10-t-item-1"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="Vector 5"
    />
    <div class="x5-1">
      <frame480956597
        :componentsCardsInternalPlacesNumber="frame480956597Props.componentsCardsInternalPlacesNumber"
        :frame480956592Props="frame480956597Props.frame480956592Props"
      />
      <a
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        target="_blank"
      >
        <div class="link-1">
          <div class="x6 tajawal-medium-white-16px">{{ x6 }}</div>
        </div></a
      >
    </div>
    <img
      class="gr-from-1-to-10-t-item-1"
      src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/2.svg"
      alt="Vector 6"
    />
    <a
      href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
      target="_blank"
    >
      <div class="components-cards-internal-places-13">
        <frame480956598
          :componentsCardsInternalPlacesNumber="frame480956598Props.componentsCardsInternalPlacesNumber"
          :frame480956594Props="frame480956598Props.frame480956594Props"
        />
        <x24 /></div></a
    ><img class="gr-from-1-to-10-t-item-1" :src="vector70" alt="Vector 70" />
    <div class="components-cards-internal-places-14">
      <frame480956599
        :componentsCardsInternalPlacesNumber="frame480956599Props.componentsCardsInternalPlacesNumber"
        :frame480956592Props="frame480956599Props.frame480956592Props"
      />
      <x24 />
    </div>
    <img class="gr-from-1-to-10-t-item-1" :src="vector63" alt="Vector 63" />
    <div class="components-cards-internal-places-15">
      <frame4809565910
        :componentsCardsInternalPlacesNumber="frame4809565910Props.componentsCardsInternalPlacesNumber"
        :frame480956592Props="frame4809565910Props.frame480956592Props"
      />
      <x24 />
    </div>
    <img class="gr-from-1-to-10-t-item-1" :src="vector69" alt="Vector 69" />
    <div class="components-cards-internal-places-16">
      <frame4809565911
        :text47="frame4809565911Props.text47"
        :componentsCardsInternalPlacesNumber="frame4809565911Props.componentsCardsInternalPlacesNumber"
      />
      <x24 />
    </div>
    <img
      class="components-cards-internal-open-info-2"
      :src="componentsCardsinternalOpenInfo"
      alt="Components/CardsInternal/Open Info"
    />
  </div>
</template>

<script>
import Frame48095659 from "./Frame48095659";
import Frame480956593 from "./Frame480956593";
import Frame480956595 from "./Frame480956595";
import Frame480956596 from "./Frame480956596";
import ComponentsButtonAddToFriends from "./ComponentsButtonAddToFriends";
import Frame4809565962 from "./Frame4809565962";
import X24 from "./X24";
import Frame480956597 from "./Frame480956597";
import Frame480956598 from "./Frame480956598";
import Frame480956599 from "./Frame480956599";
import Frame4809565910 from "./Frame4809565910";
import Frame4809565911 from "./Frame4809565911";
export default {
  name: "GrFrom1To10T",
  components: {
    Frame48095659,
    Frame480956593,
    Frame480956595,
    Frame480956596,
    ComponentsButtonAddToFriends,
    Frame4809565962,
    X24,
    Frame480956597,
    Frame480956598,
    Frame480956599,
    Frame4809565910,
    Frame4809565911,
  },
  props: [
    "spanText1",
    "spanText2",
    "x22",
    "x32",
    "x6",
    "vector70",
    "vector63",
    "vector69",
    "componentsCardsinternalOpenInfo",
    "frame48095659Props",
    "frame480956593Props",
    "frame480956595Props",
    "frame480956596Props",
    "componentsButtonAddToFriendsProps",
    "frame4809565962Props",
    "frame480956597Props",
    "frame480956598Props",
    "frame480956599Props",
    "frame4809565910Props",
    "frame4809565911Props",
  ],
};
</script>

<style>
.gr-from-1-to-10-t-1::-webkit-scrollbar {
  display: none;
  width: 0;
}

.gr-from-1-to-10-t-1 {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 50px;
  height: 1637px;
  margin-bottom: -744px;
  margin-left: 1px;
  overflow-y: scroll;
  position: relative;
  width: 604px;
}

.gr-from-1-to-10-t-item-1 {
  height: 1px;
  object-fit: cover;
  position: relative;
  width: 341px;
}

.x1-1 {
  align-items: center;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 26px;
  position: relative;
}

.x12-1,
.x21-1,
.x31-1,
.x46-1,
.x5-1,
.components-cards-internal-places-14,
.components-cards-internal-places-15,
.components-cards-internal-places-16 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 200px;
  height: 45px;
  position: relative;
  width: 480px;
}

.link-1 {
  align-items: flex-start;
  background-color: var(--squirrel);
  border-radius: 14px;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 35px;
  padding: 7px 16px;
  position: relative;
  width: 75px;
}

.x1-2 {
  direction: rtl;
  letter-spacing: -0.3px;
  line-height: 16.8px;
  margin-right: -3px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  width: fit-content;
}

.span1-1 {
  line-height: 21px;
}

.x2-1,
.x3,
.x6 {
  direction: rtl;
  letter-spacing: -0.3px;
  line-height: 16.8px;
  margin-right: -3px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  white-space: nowrap;
  width: fit-content;
}

.x412-1 {
  align-items: flex-start;
  background-color: var(--squirrel);
  border-radius: 9px;
  box-shadow: 0px -3px 50px #b931151a;
  display: flex;
  flex-direction: column;
  gap: 8px;
  height: 99px;
  padding: 19px 30px;
  position: relative;
  width: 540px;
}

.x41-1 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: inline-flex;
  gap: 200px;
  height: 80px;
  margin-bottom: -19px;
  margin-right: -12px;
  position: relative;
}

.x45-1 {
  align-items: center;
  cursor: pointer;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 26px;
  position: relative;
}

.components-cards-internal-places-13 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 200px;
  height: 45px;
  position: relative;
  width: 480px;
}

.components-cards-internal-open-info-2 {
  height: 65px;
  position: relative;
  width: 561px;
}
</style>
