<template>
  <div class="components-cards-internal-places-11">
    <frame4809565911
      :text47="frame4809565911Props.text47"
      :componentsCardsInternalPlacesNumber="frame4809565911Props.componentsCardsInternalPlacesNumber"
    />
    <components-button-add-to-friends3 />
  </div>
</template>

<script>
import Frame4809565911 from "./Frame4809565911";
import ComponentsButtonAddToFriends3 from "./ComponentsButtonAddToFriends3";
export default {
  name: "ComponentsCardsInternalPlaces9",
  components: {
    Frame4809565911,
    ComponentsButtonAddToFriends3,
  },
  props: ["frame4809565911Props"],
};
</script>

<style>
.components-cards-internal-places-11,
.components-cards-internal-places-12 {
  align-items: center;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 200px;
  height: 45px;
  position: relative;
  width: 480px;
}
</style>
