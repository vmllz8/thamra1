<template>
  <div class="container-center-horizontal">
    <div class="x11th screen">
      <div class="overlap-group5">
        <status-bar :className="statusBarProps.className" />
        <img
          class="texture-1"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture-6.svg"
          alt="Texture"
        />
        <div class="overlap-group1-2">
          <div class="frame-21-1">
            <div class="overlap-group-2">
              <router-link to="/11th"
                ><img
                  class="vuesaxoutlineframe-1"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame-1.svg"
                  alt="vuesax/outline/frame"
                /> </router-link
              ><img
                class="union-1"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union-4.svg"
                alt="Union"
              />
            </div>
            <div class="text-12 tajawal-normal-black-16px">{{ text12 }}</div>
          </div>
          <div class="flex-col">
            <router-link to="/5th"
              ><img
                class="iconsax-linearedit2-1"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2-4.svg"
                alt="Iconsax/Linear/edit2"
              />
            </router-link>
            <div class="text-15 tajawal-normal-black-16px">{{ text15 }}</div>
          </div>
          <div class="flex-col-1">
            <img
              class="iconsax-outlinehome3-1"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3-1.svg"
              alt="Iconsax/Outline/home3"
            />
            <div class="text-16 tajawal-normal-black-16px">{{ text16 }}</div>
          </div>
          <div class="flex-col-2">
            <img
              class="iconsax-linearmenuboard-1"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard-4.svg"
              alt="Iconsax/Linear/menuboard"
            />
            <div class="text-13 tajawal-normal-black-16px">{{ text13 }}</div>
          </div>
          <div class="flex-col-3">
            <div class="icons-other-sizes-star-1" :style="{ 'background-image': 'url(' + iconsOthersizesStar + ')' }">
              <img class="rectangle-65-2" :src="rectangle65" alt="Rectangle 65" /><img
                class="star-3-2"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-2.svg"
                alt="Star 3"
              />
            </div>
            <div class="text-14 tajawal-normal-black-16px">{{ text14 }}</div>
          </div>
        </div>
        <img
          class="iconsax-outlineheart"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-heart.svg"
          alt="Iconsax/Outline/heart"
        />
        <p class="text_label-3">
          <span class="tajawal-medium-russett-24px">{{ spanText1 }}</span
          ><span class="span1">{{ spanText2 }}</span
          ><span class="tajawal-medium-russett-24px">{{ spanText3 }}</span>
        </p>
        <h1 class="text_label-4">{{ text_Label1 }}</h1>
        <div class="group_-container">
          <img class="group_8026" :src="group_8026" alt="Group_8026" /><group8034 />
          <img class="group_8035" :src="group_8035" alt="Group_8035" />
        </div>
        <div class="overlap-group3 tajawal-bold-squirrel-24px">
          <div class="components-tabs-variants-challenges"></div>
          <div class="right_-group">
            <div class="eamil_id">
              <div class="overlap-group-3">
                <div class="rectangle-9"></div>
                <div class="text-17 poppins-normal-squirrel-24px">{{ text17 }}</div>
              </div>
            </div>
            <div class="text_label-5">{{ text_Label2 }}</div>
            <div class="password">
              <div class="overlap-group1-3">
                <div class="rectangle-9"></div>
                <img
                  class="pharrows-down-up"
                  src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/ph-arrows-down-up.svg"
                  alt="ph:arrows-down-up"
                />
                <div class="text-18 poppins-normal-squirrel-24px">{{ text18 }}</div>
              </div>
            </div>
            <div class="text_label-6">{{ text_Label3 }}</div>
            <div class="password-1">
              <div class="overlap-group2">
                <div class="rectangle-9"></div>
                <div class="a1234567a poppins-normal-squirrel-24px">{{ a1234567A }}</div>
              </div>
              <div class="text-20 poppins-normal-squirrel-24px">{{ text20 }}</div>
            </div>
            <div class="carb">
              <div class="text_label-7 tajawal-bold-white-24px">{{ text_Label4 }}</div>
            </div>
            <div class="or">
              <img
                class="line-1"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-1-1.svg"
                alt="Line 1"
              />
              <div class="text-19 poppins-normal-black-14-1px">{{ text19 }}</div>
              <img
                class="line-2"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/line-2-1.svg"
                alt="Line 2"
              />
            </div>
          </div>
          <div class="text_label-8">{{ text_Label5 }}</div>
        </div>
        <sign-up :children="signUpProps.children" />
        <img
          class="icon-1"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/icon-4.svg"
          alt="icon"
        />
      </div>
    </div>
  </div>
</template>

<script>
import StatusBar from "./StatusBar";
import Group8034 from "./Group8034";
import SignUp from "./SignUp";
export default {
  name: "X11th",
  components: {
    StatusBar,
    Group8034,
    SignUp,
  },
  props: [
    "text12",
    "text15",
    "text16",
    "text13",
    "iconsOthersizesStar",
    "rectangle65",
    "text14",
    "spanText1",
    "spanText2",
    "spanText3",
    "text_Label1",
    "group_8026",
    "group_8035",
    "text17",
    "text_Label2",
    "text18",
    "text_Label3",
    "a1234567A",
    "text20",
    "text_Label4",
    "text19",
    "text_Label5",
    "statusBarProps",
    "signUpProps",
  ],
};
</script>

<style>
.x11th {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  overflow: hidden;
  width: 750px;
}

.overlap-group5 {
  height: 1624px;
  margin-left: -66px;
  position: relative;
  width: 1099px;
}

.texture-1 {
  height: 1624px;
  left: 66px;
  position: absolute;
  top: 0;
  width: 750px;
}

.overlap-group1-2 {
  align-items: center;
  background-color: var(--concrete);
  border-radius: 31px;
  box-shadow: 0px 4px 4px #00000087;
  display: flex;
  height: 125px;
  left: 108px;
  min-width: 670px;
  padding: 0 10px;
  position: absolute;
  top: 1445px;
}

.frame-21-1 {
  align-items: flex-start;
  align-self: flex-start;
  display: flex;
  flex-direction: column;
  gap: 17px;
  min-height: 122px;
  padding: 0 9.6px;
  width: 124px;
}

.overlap-group-2 {
  height: 79px;
  margin-top: -18px;
  position: relative;
  width: 104px;
}

.vuesaxoutlineframe-1 {
  cursor: pointer;
  height: 33px;
  left: 35px;
  position: absolute;
  top: 46px;
  width: 33px;
}

.union-1 {
  height: 64px;
  left: 0;
  position: absolute;
  top: 0;
  width: 104px;
}

.text-12 {
  align-self: center;
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  margin-left: 2.23px;
  min-height: 19px;
  min-width: 60px;
  text-align: center;
  white-space: nowrap;
}

.flex-col {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 19px;
  margin-left: 30px;
  margin-top: 5px;
  min-height: 68px;
  width: 76px;
}

.iconsax-linearedit2-1 {
  cursor: pointer;
  height: 30px;
  margin-right: 0.48px;
  width: 32px;
}

.text-15 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 76px;
  text-align: center;
  white-space: nowrap;
}

.flex-col-1 {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-left: 60px;
  margin-top: 8px;
  min-height: 65px;
  width: 55px;
}

.iconsax-outlinehome3-1 {
  height: 30px;
  margin-right: 6px;
  width: 31px;
}

.text-16 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 55px;
  text-align: center;
  white-space: nowrap;
}

.flex-col-2 {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 17px;
  margin-left: 60px;
  margin-top: 10px;
  min-height: 63px;
  width: 71px;
}

.iconsax-linearmenuboard-1 {
  height: 27px;
  margin-left: 6px;
  width: 29px;
}

.text-13 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 71px;
  text-align: center;
  white-space: nowrap;
}

.flex-col-3 {
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: 17px;
  margin-left: 39px;
  margin-top: 8px;
  min-height: 65px;
  width: 111px;
}

.icons-other-sizes-star-1 {
  align-items: center;
  background-size: 100% 100%;
  display: flex;
  gap: 4961px;
  height: 29px;
  margin-left: 9px;
  min-width: 34px;
}

.rectangle-65-2 {
  align-self: flex-end;
  height: 24px;
  margin-bottom: -1914.1px;
  margin-left: -4980px;
  width: 28px;
}

.star-3-2 {
  height: 13px;
  margin-bottom: 0.91px;
  width: 14px;
}

.text-14 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 111px;
  text-align: center;
  white-space: nowrap;
}

.iconsax-outlineheart {
  height: 22px;
  left: 629px;
  position: absolute;
  top: 1263px;
  width: 21px;
}

.text_label-3 {
  color: transparent;
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: var(--font-size-m);
  font-weight: 500;
  left: 0;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 1262px;
  width: 863px;
}

.span1 {
  color: var(--black);
}

.text_label-4 {
  color: var(--black);
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: 40px;
  font-weight: 700;
  left: 311px;
  letter-spacing: -0.5px;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 192px;
  white-space: nowrap;
}

.group_-container {
  height: 139px;
  left: 66px;
  position: absolute;
  top: 13px;
  width: 659px;
}

.group_8026 {
  height: 76px;
  left: 300px;
  position: absolute;
  top: 63px;
  width: 124px;
}

.group_8035 {
  height: 128px;
  left: 0;
  position: absolute;
  top: 0;
  width: 659px;
}

.overlap-group3 {
  height: 765px;
  left: 122px;
  position: absolute;
  top: 265px;
  width: 979px;
}

.components-tabs-variants-challenges {
  background-color: var(--primarywhite);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  height: 765px;
  left: 0;
  position: absolute;
  top: 0;
  width: 641px;
}

.right_-group {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  left: 56px;
  min-height: 532px;
  padding: 0px 0;
  position: absolute;
  top: 97px;
  width: 923px;
}

.eamil_id {
  align-items: flex-start;
  display: flex;
  margin-left: 10px;
  min-width: 577px;
}

.overlap-group-3 {
  height: 66px;
  position: relative;
  width: 575px;
}

.rectangle-9 {
  background-color: var(--gallery);
  border-radius: 8.08px;
  height: 66px;
  left: 0;
  position: absolute;
  top: 0;
  width: 519px;
}

.text-17 {
  direction: rtl;
  left: 321px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: left;
  top: 16px;
  white-space: nowrap;
  width: 254px;
}

.text_label-5 {
  align-self: center;
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  margin-right: 34px;
  margin-top: 21px;
  min-height: 29px;
  min-width: 169px;
  text-align: center;
}

.password {
  align-items: flex-start;
  display: flex;
  margin-left: 10px;
  margin-top: 21px;
  min-width: 625px;
}

.overlap-group1-3 {
  height: 91px;
  position: relative;
  width: 623px;
}

.pharrows-down-up {
  height: 24px;
  left: 25px;
  position: absolute;
  top: 17px;
  width: 24px;
}

.text-18 {
  direction: rtl;
  left: 369px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: left;
  top: 15px;
  width: 254px;
}

.text_label-6 {
  align-self: center;
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  margin-left: 14px;
  margin-top: 7px;
  min-height: 29px;
  min-width: 121px;
  text-align: center;
}

.password-1 {
  align-items: flex-start;
  align-self: flex-end;
  display: flex;
  gap: 32px;
  height: 93px;
  margin-top: 27px;
  min-width: 911px;
}

.overlap-group2 {
  align-self: flex-end;
  height: 92px;
  position: relative;
  width: 621px;
}

.a1234567a {
  left: 367px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 16px;
  width: 254px;
}

.text-20 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 76px;
  text-align: left;
  width: 254px;
}

.carb {
  align-items: center;
  background-color: var(--rainee);
  border-radius: 8.08px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 80px;
  justify-content: center;
  margin-left: 22px;
  margin-top: 7px;
  padding: 14px 23px;
  position: relative;
  width: 500px;
}

.text_label-7 {
  direction: rtl;
  letter-spacing: -0.5px;
  line-height: normal;
  position: relative;
  text-align: center;
  width: fit-content;
}

.or {
  align-items: center;
  display: flex;
  height: 28px;
  margin-top: 33px;
  min-width: 520px;
}

.line-1 {
  height: 1px;
  margin-bottom: 4.63px;
  width: 223px;
}

.text-19 {
  align-self: flex-start;
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  margin-left: 30px;
  margin-top: 0;
  min-height: 28px;
  text-align: left;
  width: 24px;
}

.line-2 {
  height: 1px;
  margin-bottom: 4.63px;
  margin-left: 18px;
  width: 223px;
}

.text_label-8 {
  direction: rtl;
  left: 500px;
  letter-spacing: -0.5px;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 52px;
}

.icon-1 {
  height: 64px;
  left: 731px;
  position: absolute;
  top: 82px;
  width: 64px;
}
</style>
