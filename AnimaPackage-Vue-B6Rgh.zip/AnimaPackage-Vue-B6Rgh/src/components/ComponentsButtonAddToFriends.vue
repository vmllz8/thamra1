<template>
  <div class="components-button-add-to-friends-1">
    <div class="text-36 tajawal-medium-white-16px">{{ text36 }}</div>
  </div>
</template>

<script>
export default {
  name: "ComponentsButtonAddToFriends",
  props: ["text36"],
};
</script>

<style>
.components-button-add-to-friends-1,
.x43,
.x43-1 {
  align-items: flex-start;
  background-color: var(--redwood);
  border-radius: 14px;
  display: flex;
  gap: 8px;
  height: 32px;
  padding: 7px 16px;
  position: relative;
  width: 94px;
}

.text-36,
.text-60,
.x4 {
  direction: rtl;
  letter-spacing: -0.3px;
  line-height: 16.8px;
  margin-right: -5px;
  margin-top: -1px;
  position: relative;
  text-align: center;
  width: 67px;
}
</style>
