<template>
  <div class="container-center-horizontal">
    <div class="x4th screen">
      <div class="overlap-group1-1">
        <div class="carb6"></div>
        <router-link to="/10th">
          <div class="carb6-1">
            <div class="number tajawal-extra-bold-black-25px">{{ number }}</div>
          </div></router-link
        ><status-bar :className="statusBarProps.className" />
        <frame28 />
        <img
          class="texture"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/texture.svg"
          alt="Texture"
        />
        <div class="carb5"></div>
        <img class="logo-thmar-2-1" :src="logoThmar2" alt="Logo thmar  2" />
        <h1 class="user">{{ user }}</h1>
        <div class="carb5-1">
          <div class="carb5-2">
            <router-link to="/5th">
              <div class="carb6-2">
                <div class="text_label-2 tajawal-bold-black-36px">{{ text_Label1 }}</div>
              </div></router-link
            >
          </div>
          <p class="text-5">{{ text5 }}</p>
          <div class="carb6-3">
            <div class="carb6-4" id="carb6">
              <p class="text-4">{{ text4 }}</p>
            </div>
            <div class="carb5-3">
              <router-link to="/6th">
                <div class="carb6-5">
                  <div class="text_label-2 tajawal-bold-black-36px">{{ text_Label2 }}</div>
                </div></router-link
              >
            </div>
          </div>
        </div>
        <img class="group-48095477" :src="group48095477" alt="Group 48095477" /><router-link to="/ranking"
          ><img
            class="star-3"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3.svg"
            alt="Star 3"
          /> </router-link
        ><img
          class="rectangle-65"
          src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65.svg"
          alt="Rectangle 65"
        />
        <div class="overlap-group-1 tajawal-normal-black-16px">
          <div class="rectangle-91"></div>
          <div class="frame-21">
            <router-link to="/11th" className="align-self-flex-center"
              ><img
                class="vuesaxoutlineframe"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vuesax-outline-frame.svg"
                alt="vuesax/outline/frame"
              />
            </router-link>
            <div class="text-6 tajawal-normal-black-16px">{{ text6 }}</div>
          </div>
          <router-link to="/6th"
            ><img
              class="iconsax-linearmenuboard"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-menuboard.svg"
              alt="Iconsax/Linear/menuboard"
            />
          </router-link>
          <div class="text-7">{{ text7 }}</div>
          <router-link to="/10th">
            <div class="icons-other-sizes-star" :style="{ 'background-image': 'url(' + iconsOthersizesStar + ')' }">
              <img
                class="star-3-1"
                src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-1.svg"
                alt="Star 3"
              />
              <img class="rectangle-65-1" :src="rectangle652" alt="Rectangle 65" /></div
          ></router-link>
          <div class="text-8">{{ text8 }}</div>
          <router-link to="/5th"
            ><img
              class="iconsax-linearedit2"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-linear-edit2.svg"
              alt="Iconsax/Linear/edit2"
            />
          </router-link>
          <div class="text-9">{{ text9 }}</div>
          <img
            class="union"
            src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/union.svg"
            alt="Union"
          />
          <div class="text-10">{{ text10 }}</div>
          <a href="#carb6"
            ><img
              class="iconsax-outlinehome3"
              src="https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/iconsax-outline-home3.svg"
              alt="Iconsax/Outline/home3"
            />
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import StatusBar from "./StatusBar";
import Frame28 from "./Frame28";
export default {
  name: "X4th",
  components: {
    StatusBar,
    Frame28,
  },
  props: [
    "number",
    "logoThmar2",
    "user",
    "text_Label1",
    "text5",
    "text4",
    "text_Label2",
    "group48095477",
    "text6",
    "text7",
    "iconsOthersizesStar",
    "rectangle652",
    "text8",
    "text9",
    "text10",
    "statusBarProps",
  ],
};
</script>

<style>
.x4th {
  align-items: flex-start;
  background-color: var(--primarywhite);
  display: flex;
  height: 1624px;
  overflow: hidden;
  width: 750px;
}

.overlap-group1-1 {
  height: 1633px;
  margin-left: -6px;
  position: relative;
  width: 761px;
}

.carb6 {
  background-color: var(--almond-2);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 49px;
  left: 54px;
  position: absolute;
  top: 265px;
  width: 119px;
}

.carb6-1 {
  align-items: center;
  background-color: var(--concrete);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 40px;
  justify-content: center;
  left: 60px;
  opacity: 0.5;
  padding: 14px 23px;
  position: absolute;
  top: 270px;
  width: 108px;
}

.number {
  height: 29px;
  letter-spacing: 0;
  line-height: normal;
  margin-bottom: -7.5px;
  margin-left: -4.5px;
  margin-right: -4.5px;
  margin-top: -9.5px;
  position: relative;
  white-space: nowrap;
  width: 71px;
}

.texture {
  height: 1624px;
  left: 6px;
  position: absolute;
  top: 0;
  width: 750px;
}

.carb5 {
  background-color: var(--primarywhite);
  border-radius: 250px 0px 0px 0px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 1128px;
  left: 0;
  position: absolute;
  top: 505px;
  width: 761px;
}

.logo-thmar-2-1 {
  height: 165px;
  left: 558px;
  object-fit: cover;
  position: absolute;
  top: 188px;
  width: 150px;
}

.user {
  color: var(--black);
  direction: rtl;
  font-family: var(--font-family-tajawal);
  font-size: var(--font-size-xxl);
  font-weight: 500;
  left: 379px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
  top: 267px;
  width: 186px;
}

.carb5-1 {
  align-items: flex-end;
  background-color: var(--almond-2);
  border: 1px solid;
  border-color: var(--primarywhite);
  border-radius: 250px 0px 0px 0px;
  box-shadow: inset 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  flex-direction: column;
  left: 6px;
  min-height: 1104px;
  position: absolute;
  top: 520px;
  width: 750px;
}

.carb5-2 {
  align-items: center;
  background-color: var(--primarywhite);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 95px;
  justify-content: center;
  margin-right: 59px;
  margin-top: 48px;
  padding: 14px 23px;
  position: relative;
  width: 378px;
}

.carb6-2 {
  align-items: center;
  background-color: var(--rainee-2);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 82px;
  justify-content: center;
  margin-bottom: -7.5px;
  margin-left: -17px;
  margin-right: -17px;
  margin-top: -7.5px;
  padding: 14px 23px;
  position: relative;
  width: 366px;
}

.text_label-2 {
  direction: rtl;
  height: 43px;
  letter-spacing: -0.5px;
  line-height: normal;
  position: relative;
  text-align: center;
  text-shadow: 0px 4px 4px #00000040;
  white-space: nowrap;
  width: 305px;
}

.text-5 {
  color: #3f3d56;
  direction: rtl;
  font-family: var(--font-family-noto_sans_arabic);
  font-size: var(--font-size-s);
  font-weight: 500;
  letter-spacing: 0;
  line-height: normal;
  margin-right: 6px;
  margin-top: 16px;
  min-height: 79px;
  position: relative;
  text-shadow: 0px 4px 4px #00000040;
  width: 484px;
}

.carb6-3 {
  background-color: var(--primarywhite);
  border: 1px solid;
  border-radius: 250px 0px 0px 0px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 746px;
  margin-top: 120px;
  position: relative;
  width: 750px;
}

.carb6-4 {
  background-color: var(--rainee-2);
  border-radius: 250px 0px 0px 0px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  height: 734px;
  left: 12px;
  position: absolute;
  top: 12px;
  width: 738px;
}

.text-4 {
  color: var(--black);
  direction: rtl;
  font-family: var(--font-family-noto_sans_arabic);
  font-size: var(--font-size-s);
  font-weight: 500;
  left: 185px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-shadow: 0px 4px 4px #00000040;
  top: 159px;
  width: 551px;
}

.carb5-3 {
  align-items: center;
  background-color: var(--primarywhite);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040;
  display: flex;
  gap: 8px;
  height: 95px;
  justify-content: center;
  left: 313px;
  padding: 14px 23px;
  position: absolute;
  top: 48px;
  width: 378px;
}

.carb6-5 {
  align-items: center;
  background-color: var(--almond-2);
  border-radius: 26.5px;
  box-shadow: 0px 4px 4px #00000040, 0px 4px 4px #00000040;
  cursor: pointer;
  display: flex;
  gap: 8px;
  height: 82px;
  justify-content: center;
  margin-bottom: -7.5px;
  margin-left: -17px;
  margin-right: -17px;
  margin-top: -7.5px;
  padding: 14px 23px;
  position: relative;
  width: 366px;
}

.group-48095477 {
  height: 62px;
  left: 20px;
  position: absolute;
  top: 265px;
  width: 58px;
}

.star-3 {
  cursor: pointer;
  height: 19px;
  left: 39px;
  position: absolute;
  top: 281px;
  width: 19px;
}

.rectangle-65 {
  height: 53px;
  left: 24px;
  position: absolute;
  top: 269px;
  width: 50px;
}

.overlap-group-1 {
  height: 143px;
  left: 48px;
  position: absolute;
  top: 1427px;
  width: 670px;
}

.rectangle-91 {
  background-color: var(--concrete);
  border-radius: 31px;
  box-shadow: 0px 4px 4px #00000087;
  height: 125px;
  left: 0;
  position: absolute;
  top: 18px;
  width: 670px;
}

.frame-21 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  gap: 17px;
  left: 10px;
  min-height: 122px;
  padding: 24.8px 30.8px;
  position: absolute;
  top: 18px;
  width: 124px;
}

.vuesaxoutlineframe {
  align-self: center;
  cursor: pointer;
  height: 33px;
  margin-right: 0.39px;
  margin-top: 3px;
  width: 33px;
}

.text-6 {
  direction: rtl;
  letter-spacing: 0;
  line-height: normal;
  min-height: 19px;
  min-width: 60px;
  text-align: center;
  white-space: nowrap;
}

.iconsax-linearmenuboard {
  cursor: pointer;
  height: 27px;
  left: 439px;
  position: absolute;
  top: 54px;
  width: 29px;
}

.text-7 {
  direction: rtl;
  left: 415px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.icons-other-sizes-star {
  align-items: center;
  background-size: 100% 100%;
  cursor: pointer;
  display: flex;
  gap: 234px;
  height: 29px;
  justify-content: flex-end;
  left: 568px;
  min-width: 34px;
  position: absolute;
  top: 52px;
}

.star-3-1 {
  height: 13px;
  margin-bottom: 0.91px;
  width: 14px;
}

.rectangle-65-1 {
  align-self: flex-end;
  height: 24px;
  margin-bottom: -1914.1px;
  width: 28px;
}

.text-8 {
  direction: rtl;
  left: 525px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-linearedit2 {
  cursor: pointer;
  height: 30px;
  left: 186px;
  position: absolute;
  top: 49px;
  width: 32px;
}

.text-9 {
  direction: rtl;
  left: 164px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.union {
  height: 64px;
  left: 274px;
  position: absolute;
  top: 0;
  width: 104px;
}

.text-10 {
  direction: rtl;
  left: 300px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 98px;
  white-space: nowrap;
}

.iconsax-outlinehome3 {
  cursor: pointer;
  height: 30px;
  left: 309px;
  position: absolute;
  top: 52px;
  width: 31px;
}
</style>
