<template>
  <div class="frame-48095659-18">
    <components-cards-internal-places-number
      :children="componentsCardsInternalPlacesNumber.children"
      :className="componentsCardsInternalPlacesNumber.className"
    />
    <frame480956594 :children="frame480956594Props.children" :className="frame480956594Props.className" />
  </div>
</template>

<script>
import ComponentsCardsInternalPlacesNumber from "./ComponentsCardsInternalPlacesNumber";
import Frame480956594 from "./Frame480956594";
export default {
  name: "Frame480956598",
  components: {
    ComponentsCardsInternalPlacesNumber,
    Frame480956594,
  },
  props: ["componentsCardsInternalPlacesNumber", "frame480956594Props"],
};
</script>

<style>
.frame-48095659-18,
.frame-48095659-19,
.frame-48095659-20 {
  align-items: center;
  display: flex;
  gap: 30px;
  position: relative;
  width: 198px;
}
</style>
