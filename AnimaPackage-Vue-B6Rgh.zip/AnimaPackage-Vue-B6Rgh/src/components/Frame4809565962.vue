<template>
  <div class="frame-48095659-16">
    <div class="components-cards-internal-places-number-13">
      <div class="overlap-group-17">
        <div class="ellipse-68-5"></div>
        <div class="number-10 abeezee-normal-white-20px">5</div>
      </div>
    </div>
    <frame480956592 :className="frame480956592Props.className" :nicknameProps="frame480956592Props.nicknameProps" />
  </div>
</template>

<script>
import Frame480956592 from "./Frame480956592";
export default {
  name: "Frame4809565962",
  components: {
    Frame480956592,
  },
  props: ["frame480956592Props"],
};
</script>

<style>
.frame-48095659-16,
.x47,
.x47-1 {
  align-items: center;
  display: flex;
  gap: 20px;
  position: relative;
  width: 198px;
}

.components-cards-internal-places-number-13,
.x48,
.x48-1 {
  height: 40px;
  position: relative;
  width: 40px;
}

.overlap-group-17,
.overlap-group-18,
.overlap-group-19 {
  height: 48px;
  position: relative;
  top: -1px;
}

.ellipse-68-5,
.ellipse-68-6,
.ellipse-68-7 {
  background-color: var(--casal);
  border-radius: 20px/19.05px;
  height: 38px;
  left: 0;
  position: absolute;
  top: 0;
  width: 40px;
}

.number-10,
.number-11,
.number-12 {
  left: 12px;
  letter-spacing: -0.38px;
  line-height: 20.6px;
  position: absolute;
  text-align: center;
  top: 8px;
  width: 14px;
}
</style>
