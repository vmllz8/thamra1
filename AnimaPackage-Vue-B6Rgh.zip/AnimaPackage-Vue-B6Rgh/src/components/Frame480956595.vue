<template>
  <div class="frame-48095659-11">
    <div class="components-cards-internal-places-number-9">
      <div class="overlap-group-11">
        <div class="ellipse-68-1"></div>
        <div class="number-4 abeezee-normal-white-20px">3</div>
      </div>
    </div>
    <frame480956592 :nicknameProps="frame480956592Props.nicknameProps" />
  </div>
</template>

<script>
import Frame480956592 from "./Frame480956592";
export default {
  name: "Frame480956595",
  components: {
    Frame480956592,
  },
  props: ["frame480956592Props"],
};
</script>

<style>
.frame-48095659-11,
.x33,
.x33-1 {
  align-items: center;
  display: flex;
  gap: 30px;
  position: relative;
  width: 198px;
}

.components-cards-internal-places-number-9,
.x34,
.x34-1 {
  height: 40px;
  position: relative;
  width: 40px;
}

.overlap-group-11,
.overlap-group-12,
.overlap-group-13 {
  height: 49px;
  position: relative;
  top: 2px;
}

.ellipse-68-1,
.ellipse-34,
.ellipse-34-1 {
  background-color: var(--almond);
  border-radius: 20px/19.05px;
  height: 38px;
  left: 0;
  position: absolute;
  top: 0;
  width: 40px;
}

.number-4,
.number-5,
.number-6 {
  left: 13px;
  letter-spacing: -0.38px;
  line-height: 20.6px;
  position: absolute;
  text-align: center;
  top: 9px;
  width: 14px;
}
</style>
