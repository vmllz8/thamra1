export const statusBar2Data = {
    className: "status-bar-1",
};

export const x4thData = {
    number: "50",
    logoThmar2: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/logo-thmar--2.png",
    user: "أهلا! user@",
    text_Label1: "مصحح ثمار",
    text5: "أداة مصحح التلاوة صممت لتساعدك فهي تقوم بكتابة الأخطاء المتواجدة في تلاوتك لتصحهها.",
    text4: "حلقات ثمار هي حلقات قرآنية تمكن الطالب من الدخول الى حلقات عامة وخاصة  تهدف الى تحسين قراءتهم وتعزيز مستواهم  ، حيث توفر  الاداة فرصة للمعلم لتوجيه الطلاب وإدارة واجبات إضافية لتعزيز تقدمهم خلال حلقات ثمار.",
    text_Label2: "حلقات ثمار",
    group48095477: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477@2x.png",
    text6: "الإعدادات",
    text7: "حلقات ثمار",
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-1@2x.png",
    rectangle652: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png",
    text8: "قائمة المتصدرين",
    text9: "مصحح ثمار",
    text10: "الرئيسية",
    statusBarProps: statusBar2Data,
};

export const statusBar3Data = {
    className: "status-bar-2",
};

export const signUp1Data = {
    children: "تسجيل خروج",
};

export const x11thData = {
    text12: "الإعدادات",
    text15: "مصحح ثمار",
    text16: "الرئيسية",
    text13: "حلقات ثمار",
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-1@2x.png",
    rectangle65: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png",
    text14: "قائمة المتصدرين",
    spanText1: "صنع بـ",
    spanText2: "    ",
    spanText3: "لتحدي التطبيقات القرآنية بواسطة فريق Q mind <br />2024©",
    text_Label1: "تعديل معلوماتي",
    group_8026: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8026-1@2x.png",
    group_8035: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8035.png",
    text17: "ليان عبدالله المقرن",
    text_Label2: "المنطقة الإدارية:",
    text18: "منطقة الرياض",
    text_Label3: "كلمة المرور:",
    a1234567A: "A1234567a",
    text20: "منطقة الرياض",
    text_Label4: "حفظ التغييرات",
    text19: "أو",
    text_Label5: "الاسم:",
    statusBarProps: statusBar3Data,
    signUpProps: signUp1Data,
};

export const statusBar4Data = {
    className: "status-bar-3",
};

export const componentsCardsInternalPlacesNumber1Data = {
    children: "1",
};

export const nickname1Data = {
    children: "حلقة مسجد دار الإيمان",
    className: "",
};

export const frame4809565921Data = {
    nicknameProps: nickname1Data,
};

export const frame480956591Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber1Data,
    frame480956592Props: frame4809565921Data,
};

export const componentsCardsInternalPlacesNumber2Data = {
    children: "2",
    className: "components-cards-internal-places-number-6",
};

export const frame4809565941Data = {
    children: "حلقة مسجد الوالدين",
};

export const frame4809565931Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber2Data,
    frame480956594Props: frame4809565941Data,
};

export const nickname2Data = {
    children: "حلقة دار البصائر",
    className: "nickname-7",
};

export const frame4809565922Data = {
    nicknameProps: nickname2Data,
};

export const frame4809565951Data = {
    frame480956592Props: frame4809565922Data,
};

export const nickname3Data = {
    children: "حلقة مسجد أسامة بن زيد",
    className: "nickname-8",
};

export const frame4809565961Data = {
    nicknameProps: nickname3Data,
};

export const componentsButtonAddToFriends1Data = {
    text36: "انضممت!",
};

export const nickname4Data = {
    children: "حلقة مسجد أبي بن كعب",
    className: "nickname-9",
};

export const frame4809565923Data = {
    className: "frame-48095659-2",
    nicknameProps: nickname4Data,
};

export const frame48095659621Data = {
    frame480956592Props: frame4809565923Data,
};

export const componentsCardsInternalPlaces1Data = {
    frame4809565962Props: frame48095659621Data,
};

export const componentsCardsInternalPlacesNumber3Data = {
    children: "6",
};

export const nickname5Data = {
    children: "حلقة دار التبيان",
    className: "nickname-10",
};

export const frame4809565924Data = {
    nicknameProps: nickname5Data,
};

export const frame4809565971Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber3Data,
    frame480956592Props: frame4809565924Data,
};

export const componentsCardsInternalPlacesNumber4Data = {
    children: "7",
    className: "components-cards-internal-places-number-8",
};

export const frame4809565942Data = {
    children: "حلقة دار الرياحين",
    className: "frame-48095659-8",
};

export const frame4809565981Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber4Data,
    frame480956594Props: frame4809565942Data,
};

export const componentsCardsInternalPlacesNumber5Data = {
    children: "8",
    className: "components-cards-internal-places-number",
};

export const nickname6Data = {
    children: "حلقة مسجد ذي النورين",
    className: "nickname",
};

export const frame4809565925Data = {
    nicknameProps: nickname6Data,
};

export const frame4809565991Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber5Data,
    frame480956592Props: frame4809565925Data,
};

export const componentsCardsInternalPlaces71Data = {
    frame480956599Props: frame4809565991Data,
};

export const componentsCardsInternalPlacesNumber22Data = {
    children: "9",
};

export const nickname7Data = {
    children: "حلقة دار البراعم",
    className: "nickname-3",
};

export const frame4809565926Data = {
    nicknameProps: nickname7Data,
};

export const frame48095659101Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber22Data,
    frame480956592Props: frame4809565926Data,
};

export const componentsCardsInternalPlaces81Data = {
    frame4809565910Props: frame48095659101Data,
};

export const componentsCardsInternalPlacesNumber23Data = {
    children: "10",
    className: "components-cards-internal-places-number-14",
};

export const frame48095659111Data = {
    text47: "حلقة منار الريادة",
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber23Data,
};

export const componentsCardsInternalPlaces91Data = {
    frame4809565911Props: frame48095659111Data,
};

export const grFrom1To101Data = {
    componentsCardsinternalOpenInfo: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/components-cardsinternal-open-info.png",
    frame48095659Props: frame480956591Data,
    frame480956593Props: frame4809565931Data,
    frame480956595Props: frame4809565951Data,
    frame480956596Props: frame4809565961Data,
    componentsButtonAddToFriendsProps: componentsButtonAddToFriends1Data,
    componentsCardsInternalPlacesProps: componentsCardsInternalPlaces1Data,
    frame480956597Props: frame4809565971Data,
    frame480956598Props: frame4809565981Data,
    componentsCardsInternalPlaces7Props: componentsCardsInternalPlaces71Data,
    componentsCardsInternalPlaces8Props: componentsCardsInternalPlaces81Data,
    componentsCardsInternalPlaces9Props: componentsCardsInternalPlaces91Data,
};

export const group80342Data = {
    className: "group_8034-1",
};

export const x6thData = {
    text23: "الإعدادات",
    text24: "حلقات ثمار",
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-1@2x.png",
    rectangle65: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png",
    text25: "قائمة المتصدرين",
    text26: "مصحح ثمار",
    text27: "الرئيسية",
    group48095476: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095476@2x.png",
    text28: "حلقة عامة",
    text_Label1: "حلقة خاصة",
    text_Label2: "استعراض الواجبات",
    group_8026: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8026@2x.png",
    group_8035: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8035.png",
    group_8028: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8028@2x.png",
    statusBarProps: statusBar4Data,
    grFrom1To10Props: grFrom1To101Data,
    group8034Props: group80342Data,
};

export const frame2822Data = {
    className: "frame-28-1",
};

export const statusBar5Data = {
    className: "status-bar-4",
};

export const componentsCardsInternalPlacesNumber6Data = {
    children: "1",
};

export const nickname8Data = {
    children: "سارة محمد",
    className: "",
};

export const frame4809565927Data = {
    nicknameProps: nickname8Data,
};

export const frame4809565912Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber6Data,
    frame480956592Props: frame4809565927Data,
};

export const componentsCardsInternalPlacesNumber7Data = {
    children: "2",
    className: "x24",
};

export const frame4809565943Data = {
    children: "حمد خالد",
};

export const frame4809565932Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber7Data,
    frame480956594Props: frame4809565943Data,
};

export const nickname9Data = {
    children: "نورة أحمد",
    className: "nickname-1-2",
};

export const frame4809565928Data = {
    nicknameProps: nickname9Data,
};

export const frame4809565952Data = {
    frame480956592Props: frame4809565928Data,
};

export const nickname10Data = {
    children: "ثامر يوسف",
    className: "nickname-1-3",
};

export const frame4809565963Data = {
    nicknameProps: nickname10Data,
};

export const componentsButtonAddToFriends2Data = {
    text36: "انضممت!",
};

export const nickname11Data = {
    children: "فيصل علي",
    className: "nickname-1-4",
};

export const frame4809565929Data = {
    className: "x49",
    nicknameProps: nickname11Data,
};

export const frame48095659622Data = {
    frame480956592Props: frame4809565929Data,
};

export const componentsCardsInternalPlaces2Data = {
    frame4809565962Props: frame48095659622Data,
};

export const componentsCardsInternalPlacesNumber8Data = {
    children: "6",
};

export const nickname12Data = {
    children: "لمياء ثابت",
    className: "nickname-1-5",
};

export const frame48095659210Data = {
    nicknameProps: nickname12Data,
};

export const frame4809565972Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber8Data,
    frame480956592Props: frame48095659210Data,
};

export const componentsCardsInternalPlacesNumber9Data = {
    children: "7",
    className: "components-cards-internal-places-number-1",
};

export const frame4809565944Data = {
    children: "خالد عبدالرحمن",
    className: "frame-48095659-9",
};

export const frame4809565982Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber9Data,
    frame480956594Props: frame4809565944Data,
};

export const componentsCardsInternalPlacesNumber10Data = {
    children: "8",
    className: "components-cards-internal-places-number-2",
};

export const nickname13Data = {
    children: "سناء عثمان",
    className: "nickname-1",
};

export const frame48095659211Data = {
    nicknameProps: nickname13Data,
};

export const frame4809565992Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber10Data,
    frame480956592Props: frame48095659211Data,
};

export const componentsCardsInternalPlaces72Data = {
    frame480956599Props: frame4809565992Data,
};

export const componentsCardsInternalPlacesNumber24Data = {
    children: "9",
};

export const nickname14Data = {
    children: "رنا محمد",
    className: "nickname-4",
};

export const frame48095659212Data = {
    nicknameProps: nickname14Data,
};

export const frame48095659102Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber24Data,
    frame480956592Props: frame48095659212Data,
};

export const componentsCardsInternalPlaces82Data = {
    frame4809565910Props: frame48095659102Data,
};

export const componentsCardsInternalPlacesNumber25Data = {
    children: "10",
    className: "components-cards-internal-places-number-15",
};

export const frame48095659112Data = {
    text47: "سلطان عبدالله",
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber25Data,
};

export const componentsCardsInternalPlaces92Data = {
    frame4809565911Props: frame48095659112Data,
};

export const grFrom1To102Data = {
    componentsCardsinternalOpenInfo: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/components-cardsinternal-open-info-1.png",
    className: "gr-from-1-to-10-t",
    frame48095659Props: frame4809565912Data,
    frame480956593Props: frame4809565932Data,
    frame480956595Props: frame4809565952Data,
    frame480956596Props: frame4809565963Data,
    componentsButtonAddToFriendsProps: componentsButtonAddToFriends2Data,
    componentsCardsInternalPlacesProps: componentsCardsInternalPlaces2Data,
    frame480956597Props: frame4809565972Data,
    frame480956598Props: frame4809565982Data,
    componentsCardsInternalPlaces7Props: componentsCardsInternalPlaces72Data,
    componentsCardsInternalPlaces8Props: componentsCardsInternalPlaces82Data,
    componentsCardsInternalPlaces9Props: componentsCardsInternalPlaces92Data,
};

export const group80343Data = {
    className: "group_8034-2",
};

export const x7thData = {
    text50: "الإعدادات",
    text51: "حلقات ثمار",
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-1@2x.png",
    rectangle65: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png",
    text52: "قائمة المتصدرين",
    text53: "مصحح ثمار",
    text54: "الرئيسية",
    text55: "حلقة عامة",
    text56: "حلقة خاصة",
    text_Label: "استعراض الواجبات",
    group48095476: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095476-1@2x.png",
    group_8026: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/group-8026-2@2x.png",
    group_8035: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8035.png",
    group_8028: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b139fd2bc168d44025ce4f/img/group-8028-1@2x.png",
    frame282Props: frame2822Data,
    statusBarProps: statusBar5Data,
    grFrom1To10Props: grFrom1To102Data,
    group8034Props: group80343Data,
};

export const statusBar6Data = {
    className: "status-bar-5",
};

export const frame2823Data = {
    className: "frame-28-2",
};

export const x9thData = {
    text68: "الإعدادات",
    text69: "حلقات ثمار",
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-1@2x.png",
    rectangle65: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png",
    text70: "قائمة المتصدرين",
    text71: "مصحح ثمار",
    text72: "الرئيسية",
    text_Label: "الواجبات",
    group48095476: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095476-2@2x.png",
    text73: "مراجعة سورة العلق كاملة",
    icons56X56Background1: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png",
    text74: "مراجعة سورة المدثر كاملة",
    text75: "مراجعة سورة الفاتحة كاملة",
    text76: "مراجعة سورة القارعة كاملة",
    group_8026: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8026-2@2x.png",
    group_8035: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8035-2.png",
    group_8028: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-8028-1@2x.png",
    group48095495: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095495@2x.png",
    statusBarProps: statusBar6Data,
    frame282Props: frame2823Data,
};

export const statusBar7Data = {
    className: "status-bar-6",
};

export const frame2824Data = {
    className: "frame-28-3",
};

export const x10thData = {
    ellipse709: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/ellipse-709@2x.png",
    text78: "قائمة المتصدرين",
    text79: "50/800",
    text80: "ثمارك",
    text81: "سارة محمد",
    phone1: "650/800",
    text82: "أحمد ناصر",
    phone2: "450/800",
    text83: "عبدالله يوسف",
    rectangle81: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-81.png",
    phone3: "250/800",
    rectangle69: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-69.png",
    overlapGroup4: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-72.png",
    text85: "تالا عبدالرحمن",
    text84: "25/800",
    title: "@user",
    text86: "الإعدادات",
    text87: "حلقات ثمار",
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-1@2x.png",
    rectangle651: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png",
    text88: "قائمة المتصدرين",
    text89: "مصحح ثمار",
    text90: "الرئيسية",
    overlapGroup6: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095477-7@2x.png",
    overlapGroup7: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095477-8@2x.png",
    overlapGroup8: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095478@2x.png",
    overlapGroup9: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095477-9@2x.png",
    overlapGroup10: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b13ddf9afa7456efe2306c/img/group-48095477-9@2x.png",
    statusBarProps: statusBar7Data,
    frame282Props: frame2824Data,
};

export const iconsOtherSizesStar1Data = {
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-10@2x.png",
};

export const iconsOtherSizesStar2Data = {
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/star-3-4.svg",
    className: "icons-other-sizes-star-7",
};

export const rankingData = {
    spanText1: "المستوى الذهبي:<br />",
    spanText2: " عندما تتألق بأكثر من 650 نقطة، تصبح نجمًا ذهبيًا في عالم قراءتك للقرآن. ذلك اللمعان الذهبي يعكس العناء والتفاني الذي وضعته في فهم كلمات الله عز وجل. استمتع بلحظات التألق واستعد لمزيد من التحديات التي تعزز من إشراقتك.",
    spanText3: "المستوى الفضي:",
    spanText4: "بتحقيقك 450 نقطة، أنت الآن جزء من تلك الفرقة المتألقة بالفضة. استمتع بلحظات الفخر والإنجاز، وتذوق حلاوة تقدمك. لا تنسى أن تُلهم الآخرين من حولك، حيث تكون قصتك نبراسًا يستنير به الطلاب الطامحون.",
    spanText5: "المستوى البرونزي:",
    spanText6: "بتحقيقك 250 نقطة، أنت الآن في بداية رحلتك القرآنية. استمر في السعي للتحسين واستفد من كل توجيه يقدمه المعلم. تلك الخطوات الأولى تعد نقطة انطلاق قوية لتحقيق التقدم واستمرار التطور.",
    spanText7: "المستوى الأخضر:",
    spanText8: "عندما تكون في مستوى الأخضر، تكون في مرحلة محمسة من التحدي والتعلم. استمتع بكل لحظة من تطورك، وابحث عن فرص التحسين المستمر. تفاعل مع المعلم وزملائك، واستمتع برحلة اكتشاف إمكانياتك في عالم القراءة والتلاوة.",
    group48095499: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-9@2x.png",
    group48095495: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095478-1@2x.png",
    text_Label: "استعراض قائمة المتصدرين",
    iconsOtherSizesStar1Props: iconsOtherSizesStar1Data,
    iconsOtherSizesStar2Props: iconsOtherSizesStar2Data,
};

export const componentsCardsInternalPlacesNumber11Data = {
    children: "1",
};

export const nickname15Data = {
    children: "القارئ ماهر المعيقلي",
    className: "",
};

export const frame48095659213Data = {
    nicknameProps: nickname15Data,
};

export const frame4809565913Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber11Data,
    frame480956592Props: frame48095659213Data,
};

export const componentsCardsInternalPlacesNumber12Data = {
    children: "2",
    className: "x24-1",
};

export const frame4809565945Data = {
    children: "القارئ عبدالرحمن السديس",
};

export const frame4809565933Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber12Data,
    frame480956594Props: frame4809565945Data,
};

export const nickname16Data = {
    children: "القارئ ياسر بن الدوسري",
    className: "nickname-2-2",
};

export const frame48095659214Data = {
    nicknameProps: nickname16Data,
};

export const frame4809565953Data = {
    frame480956592Props: frame48095659214Data,
};

export const nickname17Data = {
    children: "القارئ سعود ال شريم",
    className: "nickname-2-3",
};

export const frame4809565964Data = {
    nicknameProps: nickname17Data,
};

export const componentsButtonAddToFriends4Data = {
    text36: "استمع",
};

export const nickname18Data = {
    children: "القارئ فيصل غزاوي",
    className: "nickname-2-4",
};

export const frame48095659215Data = {
    className: "x49-1",
    nicknameProps: nickname18Data,
};

export const frame48095659623Data = {
    frame480956592Props: frame48095659215Data,
};

export const componentsCardsInternalPlacesNumber13Data = {
    children: "6",
};

export const nickname19Data = {
    children: "القارئ عبدالله الجهني",
    className: "nickname-2-5",
};

export const frame48095659216Data = {
    nicknameProps: nickname19Data,
};

export const frame4809565973Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber13Data,
    frame480956592Props: frame48095659216Data,
};

export const componentsCardsInternalPlacesNumber14Data = {
    children: "7",
    className: "components-cards-internal-places-number-3",
};

export const frame4809565946Data = {
    children: "القارئ بندر بليلة",
    className: "frame-48095659-10",
};

export const frame4809565983Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber14Data,
    frame480956594Props: frame4809565946Data,
};

export const componentsCardsInternalPlacesNumber15Data = {
    children: "8",
    className: "components-cards-internal-places-number-4",
};

export const nickname20Data = {
    children: "القارئ صالح المحيميد",
    className: "nickname-2",
};

export const frame48095659217Data = {
    nicknameProps: nickname20Data,
};

export const frame4809565993Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber15Data,
    frame480956592Props: frame48095659217Data,
};

export const componentsCardsInternalPlacesNumber26Data = {
    children: "9",
};

export const nickname21Data = {
    children: "القارئ عادل الكلباني",
    className: "nickname-5",
};

export const frame48095659218Data = {
    nicknameProps: nickname21Data,
};

export const frame48095659103Data = {
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber26Data,
    frame480956592Props: frame48095659218Data,
};

export const componentsCardsInternalPlacesNumber27Data = {
    children: "10",
    className: "components-cards-internal-places-number-16",
};

export const frame48095659113Data = {
    text47: "القارئ صالح الطالب",
    componentsCardsInternalPlacesNumber: componentsCardsInternalPlacesNumber27Data,
};

export const grFrom1To10TData = {
    spanText1: "استمع",
    spanText2: "",
    x22: "استمع",
    x32: "استمع",
    x6: "استمع",
    vector70: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-70@2x.png",
    vector63: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-70@2x.png",
    vector69: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/vector-70@2x.png",
    componentsCardsinternalOpenInfo: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/components-cardsinternal-open-info.png",
    frame48095659Props: frame4809565913Data,
    frame480956593Props: frame4809565933Data,
    frame480956595Props: frame4809565953Data,
    frame480956596Props: frame4809565964Data,
    componentsButtonAddToFriendsProps: componentsButtonAddToFriends4Data,
    frame4809565962Props: frame48095659623Data,
    frame480956597Props: frame4809565973Data,
    frame480956598Props: frame4809565983Data,
    frame480956599Props: frame4809565993Data,
    frame4809565910Props: frame48095659103Data,
    frame4809565911Props: frame48095659113Data,
};

export const nameData = {
    grFrom1To10TProps: grFrom1To10TData,
};

export const signUp2Data = {
    children: "تسجيل جديد",
    className: "sign_up-3",
};

export const statusBar8Data = {
    className: "status-bar-7",
};

export const thirdData = {
    number: "11223344556",
    text_Label1: "كلمة المرور:",
    text95: "ادخل كلمة المرور",
    text96: "نسيت كلمة المرور",
    login_Now: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/login-now.png",
    text97: "أو",
    logoThmar2: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/logo-thmar--2.png",
    text_Label2: "تسجيل الدخول كـــ طالب",
    text_Label3: "رقم الهوية:",
    mail_Icon: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/mail-icon@2x.png",
    signUpProps: signUp2Data,
    statusBarProps: statusBar8Data,
};

export const statusBar9Data = {
    className: "status-bar-8",
};

export const frame2825Data = {
    className: "frame-28-4",
};

export const x5thData = {
    text101: "مصحح التلاوة",
    group48095487: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095487.png",
    text: "",
    text102: "الإعدادات",
    text103: "حلقات ثمار",
    iconsOthersizesStar: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-48095477-1@2x.png",
    rectangle65: "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/rectangle-65-1@2x.png",
    text104: "قائمة المتصدرين",
    text105: "مصحح ثمار",
    text106: "الرئيسية",
    text107: "استمع للآيات بشكل صحيح:",
    statusBarProps: statusBar9Data,
    frame282Props: frame2825Data,
};

