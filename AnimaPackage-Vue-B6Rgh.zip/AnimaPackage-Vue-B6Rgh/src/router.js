import Vue from "vue";
import Router from "vue-router";
import Sec from "./components/Sec";
import X4th from "./components/X4th";
import X11th from "./components/X11th";
import X6th from "./components/X6th";
import X7th from "./components/X7th";
import X9th from "./components/X9th";
import X10th from "./components/X10th";
import Ranking from "./components/Ranking";
import Name from "./components/Name";
import Third from "./components/Third";
import First from "./components/First";
import X5th from "./components/X5th";
import {
  x4thData,
  x11thData,
  x6thData,
  x7thData,
  x9thData,
  x10thData,
  rankingData,
  nameData,
  thirdData,
  x5thData,
} from "./data";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/sec",
      component: Sec,
      props: {
        logoThmar2:
          "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/logo-thmar--2.png",
        text_Label1: "من نحن؟",
        text_Label2: "من فضلك اختر طريقة تسجيل الدخول",
        sign_Up1:
          "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/sign-up@2x.png",
        sign_Up2:
          "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/sign-up-1@2x.png",
        text2:
          "تطبيق يساعدك في تصحيح قراءتك للقرآن الكريم  <br />ويوفر ميزة الحلقات القرآنية الإلكترونية لتستطيع تسميع ما حفظت أينما كنت وتتنافس مع المسلمين بين جميع أنحاء العالم",
      },
    },
    {
      path: "/4th",
      component: X4th,
      props: { ...x4thData },
    },
    {
      path: "/11th",
      component: X11th,
      props: { ...x11thData },
    },
    {
      path: "/6th",
      component: X6th,
      props: { ...x6thData },
    },
    {
      path: "/7th",
      component: X7th,
      props: { ...x7thData },
    },
    {
      path: "/9th",
      component: X9th,
      props: { ...x9thData },
    },
    {
      path: "/10th",
      component: X10th,
      props: { ...x10thData },
    },
    {
      path: "/ranking",
      component: Ranking,
      props: { ...rankingData },
    },
    {
      path: "/name",
      component: Name,
      props: { grFrom1To10TProps: nameData.grFrom1To10TProps },
    },
    {
      path: "/third",
      component: Third,
      props: { ...thirdData },
    },
    {
      path: "/5th",
      component: X5th,
      props: { ...x5thData },
    },
    {
      path: "*",
      component: First,
      props: {
        overlapGroup:
          "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-12.png",
        group13:
          "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/group-13.png",
        frame27:
          "https://cdn.animaapp.com/projects/65b135a5af06a9ea2eca66f4/releases/65b1390c5ab4c25d3eb21f3a/img/frame-27.png",
      },
    },
  ],
});
