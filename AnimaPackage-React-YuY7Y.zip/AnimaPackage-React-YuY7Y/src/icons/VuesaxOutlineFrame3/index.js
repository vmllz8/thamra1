export { VuesaxOutlineFrame3 } from "./VuesaxOutlineFrame3";
