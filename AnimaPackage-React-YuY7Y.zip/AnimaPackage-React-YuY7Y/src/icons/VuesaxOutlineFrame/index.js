export { VuesaxOutlineFrame } from "./VuesaxOutlineFrame";
