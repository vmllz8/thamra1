export { Icon2 } from "./Icon2";
