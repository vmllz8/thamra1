export { Icon1 } from "./Icon1";
