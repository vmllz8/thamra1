/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const StatusBar = ({ darkMode, className, wifi = "/img/wifi-1.svg", divClassName }) => {
  return (
    <div className={`status-bar ${darkMode} ${className}`}>
      <img className="battery" alt="Battery" src={darkMode === "off" ? "/img/battery-1.png" : "/img/battery.png"} />
      <img className="wifi" alt="Wifi" src={darkMode === "off" ? wifi : "/img/image.svg"} />
      <img
        className="cellular-connection"
        alt="Cellular connection"
        src={darkMode === "off" ? "/img/cellular-connection-1.svg" : "/img/cellular-connection.svg"}
      />
      <div className={`text-wrapper ${divClassName}`}>9:41</div>
    </div>
  );
};

StatusBar.propTypes = {
  darkMode: PropTypes.oneOf(["off", "on"]),
  wifi: PropTypes.string,
};
