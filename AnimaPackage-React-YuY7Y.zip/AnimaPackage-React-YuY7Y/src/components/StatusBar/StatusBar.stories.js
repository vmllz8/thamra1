import { StatusBar } from ".";

export default {
  title: "Components/StatusBar",
  component: StatusBar,
  argTypes: {
    darkMode: {
      options: ["off", "on"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    darkMode: "off",
    className: {},
    wifi: "/img/wifi-1.svg",
    divClassName: {},
  },
};
