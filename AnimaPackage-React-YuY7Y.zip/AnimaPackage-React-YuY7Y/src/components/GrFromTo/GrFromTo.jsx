/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const GrFromTo = ({
  className,
  text = "حلقة مسجد دار الإيمان",
  text1 = "حلقة مسجد الوالدين",
  text2 = "حلقة دار البصائر",
  text3 = "حلقة مسجد أسامة بن زيد",
  text4 = "حلقة مسجد أبي بن كعب",
  text5 = "حلقة دار التبيان",
  text6 = "حلقة دار الرياحين",
  vectorClassName,
  text7 = "حلقة مسجد ذي النورين",
  vectorClassNameOverride,
  text8 = "حلقة دار البراعم",
  imgClassName,
  text9 = "حلقة منار الريادة",
}) => {
  return (
    <div className={`gr-from-to ${className}`}>
      <img className="vector" alt="Vector" />
      <div className="components">
        <div className="div">
          <div className="frame-2">
            <div className="overlap-group-wrapper">
              <div className="overlap-group">
                <div className="ellipse" />
                <div className="text-wrapper-2">1</div>
              </div>
            </div>
            <div className="nickname-wrapper">
              <div className="nickname">
                <div className="text-wrapper-3">{text}</div>
              </div>
            </div>
          </div>
          <a
            className="components-button"
            href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
            rel="noopener noreferrer"
            target="_blank"
          >
            <div className="text-wrapper-4">انضم!</div>
          </a>
        </div>
      </div>
      <img className="vector" alt="Vector" />
      <div className="div">
        <div className="frame-2">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="ellipse-2" />
              <div className="text-wrapper-2">2</div>
            </div>
          </div>
          <div className="frame-3">
            <div className="nickname-2">
              <div className="text-wrapper-5">{text1}</div>
            </div>
          </div>
        </div>
        <a
          className="components-button"
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          rel="noopener noreferrer"
          target="_blank"
        >
          <div className="text-wrapper-4">انضم!</div>
        </a>
      </div>
      <img className="vector" alt="Vector" />
      <div className="div">
        <div className="frame-2">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="ellipse-3" />
              <div className="text-wrapper-2">3</div>
            </div>
          </div>
          <div className="nickname-wrapper">
            <div className="nickname">
              <div className="text-wrapper-6">{text2}</div>
            </div>
          </div>
        </div>
        <a
          className="components-button"
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          rel="noopener noreferrer"
          target="_blank"
        >
          <div className="text-wrapper-4">انضم!</div>
        </a>
      </div>
      <img className="vector" alt="Vector" />
      <div className="your-card">
        <a
          className="components-2"
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          rel="noopener noreferrer"
          target="_blank"
        >
          <div className="frame-2">
            <div className="overlap-group-wrapper">
              <div className="overlap-group-2">
                <div className="ellipse-4" />
                <div className="text-wrapper-7">4</div>
              </div>
            </div>
            <div className="frame-4">
              <div className="nickname">
                <p className="p">{text3}</p>
              </div>
            </div>
          </div>
          <div className="components-button-2">
            <div className="text-wrapper-8">انضممت!</div>
          </div>
        </a>
      </div>
      <a
        className="components"
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        rel="noopener noreferrer"
        target="_blank"
      >
        <div className="div">
          <div className="frame-5">
            <div className="overlap-group-wrapper">
              <div className="overlap-group-3">
                <div className="ellipse-5" />
                <div className="text-wrapper-9">5</div>
              </div>
            </div>
            <div className="frame-6">
              <div className="nickname">
                <p className="text-wrapper-10">{text4}</p>
              </div>
            </div>
          </div>
          <div className="components-button">
            <div className="text-wrapper-4">انضم!</div>
          </div>
        </div>
      </a>
      <img className="vector" alt="Vector" />
      <div className="div">
        <div className="frame-2">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="ellipse" />
              <div className="text-wrapper-2">6</div>
            </div>
          </div>
          <div className="nickname-wrapper">
            <div className="nickname">
              <div className="text-wrapper-11">{text5}</div>
            </div>
          </div>
        </div>
        <a
          className="components-button"
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          rel="noopener noreferrer"
          target="_blank"
        >
          <div className="text-wrapper-4">انضم!</div>
        </a>
      </div>
      <img className="vector" alt="Vector" />
      <a
        className="div"
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        rel="noopener noreferrer"
        target="_blank"
      >
        <div className="frame-2">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="ellipse-2" />
              <div className="text-wrapper-2">7</div>
            </div>
          </div>
          <div className="frame-3">
            <div className="nickname-3">
              <div className="text-wrapper-12">{text6}</div>
            </div>
          </div>
        </div>
        <div className="components-button">
          <div className="text-wrapper-4">انضم!</div>
        </div>
      </a>
      <img className={`img ${vectorClassName}`} alt="Vector" />
      <div className="div">
        <div className="frame-2">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="ellipse-3" />
              <div className="text-wrapper-2">8</div>
            </div>
          </div>
          <div className="nickname-wrapper">
            <div className="nickname">
              <div className="text-wrapper-13">{text7}</div>
            </div>
          </div>
        </div>
        <div className="components-button">
          <div className="text-wrapper-4">انضم!</div>
        </div>
      </div>
      <img className={`img ${vectorClassNameOverride}`} alt="Vector" />
      <div className="div">
        <div className="frame-2">
          <div className="overlap-group-wrapper">
            <div className="overlap-group-4">
              <div className="text-wrapper-14">9</div>
            </div>
          </div>
          <div className="nickname-wrapper">
            <div className="nickname-4">
              <div className="text-wrapper-15">{text8}</div>
            </div>
          </div>
        </div>
        <div className="components-button">
          <div className="text-wrapper-4">انضم!</div>
        </div>
      </div>
      <img className={`img ${imgClassName}`} alt="Vector" />
      <div className="div">
        <div className="frame-2">
          <div className="overlap-group-wrapper">
            <div className="overlap-group-5">
              <div className="text-wrapper-14">10</div>
            </div>
          </div>
          <div className="frame-7">
            <div className="nickname">
              <div className="text-wrapper-16">{text9}</div>
            </div>
          </div>
        </div>
        <div className="components-button">
          <div className="text-wrapper-4">انضم!</div>
        </div>
      </div>
      <img className="components-3" alt="Components" />
    </div>
  );
};

GrFromTo.propTypes = {
  text: PropTypes.string,
  text1: PropTypes.string,
  text2: PropTypes.string,
  text3: PropTypes.string,
  text4: PropTypes.string,
  text5: PropTypes.string,
  text6: PropTypes.string,
  text7: PropTypes.string,
  text8: PropTypes.string,
  text9: PropTypes.string,
};
