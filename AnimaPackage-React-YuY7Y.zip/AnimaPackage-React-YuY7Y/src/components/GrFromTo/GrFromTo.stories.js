import { GrFromTo } from ".";

export default {
  title: "Components/GrFromTo",
  component: GrFromTo,
};

export const Default = {
  args: {
    className: {},
    text: "حلقة مسجد دار الإيمان",
    text1: "حلقة مسجد الوالدين",
    text2: "حلقة دار البصائر",
    text3: "حلقة مسجد أسامة بن زيد",
    text4: "حلقة مسجد أبي بن كعب",
    text5: "حلقة دار التبيان",
    text6: "حلقة دار الرياحين",
    vectorClassName: {},
    text7: "حلقة مسجد ذي النورين",
    vectorClassNameOverride: {},
    text8: "حلقة دار البراعم",
    imgClassName: {},
    text9: "حلقة منار الريادة",
  },
};
