import { GrFromToT } from ".";

export default {
  title: "Components/GrFromToT",
  component: GrFromToT,
};

export const Default = {
  args: {
    className: {},
  },
};
