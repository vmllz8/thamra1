/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import "./style.css";

export const GrFromToT = ({ className }) => {
  return (
    <div className={`gr-from-to-t ${className}`}>
      <img className="img-2" alt="Vector" />
      <div className="element-wrapper">
        <div className="div-2">
          <div className="div-3">
            <div className="overlap-group-wrapper-2">
              <div className="overlap-group-6">
                <div className="div-4" />
                <div className="text-wrapper-17">1</div>
              </div>
            </div>
            <div className="nickname-wrapper-2">
              <div className="nickname-5">
                <div className="name-2">القارئ ماهر المعيقلي</div>
              </div>
            </div>
          </div>
          <a
            className="div-wrapper-2"
            href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
            rel="noopener noreferrer"
            target="_blank"
          >
            <p className="element-2">
              <span className="span">استمع</span>
              <span className="text-wrapper-18">&nbsp;</span>
            </p>
          </a>
        </div>
      </div>
      <img className="img-2" alt="Element" />
      <div className="div-2">
        <div className="div-3">
          <div className="overlap-group-wrapper-2">
            <div className="overlap-group-6">
              <div className="ellipse-6" />
              <div className="text-wrapper-17">2</div>
            </div>
          </div>
          <div className="nickname-wrapper-3">
            <div className="name-wrapper">
              <div className="name-3">القارئ عبدالرحمن السديس</div>
            </div>
          </div>
        </div>
        <a
          className="div-wrapper-2"
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          rel="noopener noreferrer"
          target="_blank"
        >
          <div className="text-wrapper-19">استمع</div>
        </a>
      </div>
      <img className="img-2" alt="Element" />
      <div className="div-2">
        <div className="div-3">
          <div className="overlap-group-wrapper-2">
            <div className="overlap-group-6">
              <div className="ellipse-7" />
              <div className="text-wrapper-17">3</div>
            </div>
          </div>
          <div className="nickname-wrapper-2">
            <div className="nickname-5">
              <div className="name-4">القارئ ياسر بن الدوسري</div>
            </div>
          </div>
        </div>
        <a
          className="div-wrapper-2"
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          rel="noopener noreferrer"
          target="_blank"
        >
          <div className="text-wrapper-19">استمع</div>
        </a>
      </div>
      <img className="img-2" alt="Element" />
      <div className="element-3">
        <a
          className="element-4"
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          rel="noopener noreferrer"
          target="_blank"
        >
          <div className="div-3">
            <div className="overlap-group-wrapper-2">
              <div className="overlap-group-7">
                <div className="ellipse-8" />
                <div className="text-wrapper-20">4</div>
              </div>
            </div>
            <div className="frame-8">
              <div className="nickname-5">
                <div className="text-wrapper-21">القارئ سعود ال شريم</div>
              </div>
            </div>
          </div>
          <div className="element-5">
            <div className="element-6">استمع</div>
          </div>
        </a>
      </div>
      <a
        className="element-wrapper"
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        rel="noopener noreferrer"
        target="_blank"
      >
        <div className="div-2">
          <div className="element-7">
            <div className="overlap-group-wrapper-2">
              <div className="overlap-group-8">
                <div className="ellipse-9" />
                <div className="text-wrapper-22">5</div>
              </div>
            </div>
            <div className="element-8">
              <div className="nickname-5">
                <div className="name-5">القارئ فيصل غزاوي</div>
              </div>
            </div>
          </div>
          <div className="div-wrapper-2">
            <div className="text-wrapper-19">استمع</div>
          </div>
        </div>
      </a>
      <img className="img-2" alt="Vector" />
      <div className="div-2">
        <div className="div-3">
          <div className="overlap-group-wrapper-2">
            <div className="overlap-group-6">
              <div className="div-4" />
              <div className="text-wrapper-17">6</div>
            </div>
          </div>
          <div className="nickname-wrapper-2">
            <div className="nickname-5">
              <div className="text-wrapper-23">القارئ عبدالله الجهني</div>
            </div>
          </div>
        </div>
        <a
          className="div-wrapper-2"
          href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
          rel="noopener noreferrer"
          target="_blank"
        >
          <div className="text-wrapper-19">استمع</div>
        </a>
      </div>
      <img className="img-2" alt="Vector" />
      <a
        className="div-2"
        href="https://teams.microsoft.com/l/meetup-join/19%3ameeting_MGM2NTVjNmMtYjQ2Zi00ZWRjLWFjYzAtOWY0ODY0YjczZjMz%40thread.v2/0?context=%7b%22Tid%22%3a%22add7e95a-90f7-46f5-8bb7-c861a9d333a5%22%2c%22Oid%22%3a%2267aafc78-aee2-4f51-8765-f7504cc89b1d%22%7d"
        rel="noopener noreferrer"
        target="_blank"
      >
        <div className="div-3">
          <div className="overlap-group-wrapper-2">
            <div className="overlap-group-6">
              <div className="ellipse-6" />
              <div className="text-wrapper-17">7</div>
            </div>
          </div>
          <div className="nickname-wrapper-3">
            <div className="nickname-6">
              <div className="text-wrapper-24">القارئ بندر بليلة</div>
            </div>
          </div>
        </div>
        <div className="div-wrapper-2">
          <div className="text-wrapper-19">استمع</div>
        </div>
      </a>
      <img className="img-2" alt="Vector" />
      <div className="div-2">
        <div className="div-3">
          <div className="overlap-group-wrapper-2">
            <div className="overlap-group-6">
              <div className="ellipse-7" />
              <div className="text-wrapper-17">8</div>
            </div>
          </div>
          <div className="nickname-wrapper-2">
            <div className="nickname-5">
              <div className="text-wrapper-25">القارئ صالح المحيميد</div>
            </div>
          </div>
        </div>
        <div className="div-wrapper-2">
          <div className="text-wrapper-19">استمع</div>
        </div>
      </div>
      <img className="img-2" alt="Vector" />
      <div className="div-2">
        <div className="div-3">
          <div className="overlap-group-wrapper-2">
            <div className="overlap-group-9">
              <div className="text-wrapper-26">9</div>
            </div>
          </div>
          <div className="nickname-wrapper-2">
            <div className="nickname-7">
              <div className="text-wrapper-27">القارئ عادل الكلباني</div>
            </div>
          </div>
        </div>
        <div className="div-wrapper-2">
          <div className="text-wrapper-19">استمع</div>
        </div>
      </div>
      <img className="img-2" alt="Vector" />
      <div className="div-2">
        <div className="div-3">
          <div className="overlap-group-wrapper-2">
            <div className="overlap-group-10">
              <div className="text-wrapper-26">10</div>
            </div>
          </div>
          <div className="frame-9">
            <div className="nickname-5">
              <div className="text-wrapper-28">القارئ صالح الطالب</div>
            </div>
          </div>
        </div>
        <div className="div-wrapper-2">
          <div className="text-wrapper-19">استمع</div>
        </div>
      </div>
      <img className="components-4" alt="Components" />
    </div>
  );
};
