export { VuesaxOutlineFrameWrapper } from "./VuesaxOutlineFrameWrapper";
