import { VuesaxOutlineFrameWrapper } from ".";

export default {
  title: "Components/VuesaxOutlineFrameWrapper",
  component: VuesaxOutlineFrameWrapper,
};

export const Default = {
  args: {},
};
