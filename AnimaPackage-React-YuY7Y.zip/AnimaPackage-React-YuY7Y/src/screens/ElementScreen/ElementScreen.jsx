import React from "react";
import { Link } from "react-router-dom";
import { StatusBar } from "../../components/StatusBar";
import { Icon1 } from "../../icons/Icon1";
import { VuesaxOutlineFrame3 } from "../../icons/VuesaxOutlineFrame3";
import "./style.css";

export const ElementScreen = () => {
  return (
    <div className="element-screen">
      <div className="element-9">
        <div className="overlap-3">
          <StatusBar className="status-bar-4" darkMode="off" divClassName="status-bar-5" wifi="/img/wifi.svg" />
          <img className="texture-2" alt="Texture" src="/img/texture-1.svg" />
          <div className="navbar-2">
            <div className="overlap-4">
              <div className="frame-11">
                <div className="overlap-group-13">
                  <VuesaxOutlineFrame3 className="vuesax-outline-frame-1" />
                  <img className="union-2" alt="Union" src="/img/union-1.svg" />
                </div>
                <div className="text-wrapper-42">الإعدادات</div>
              </div>
              <img className="iconsax-linear-2" alt="Iconsax linear" src="/img/iconsax-linear-menuboard-1.svg" />
              <div className="text-wrapper-43">حلقات ثمار</div>
              <div className="icons-othersizes-2">
                <img className="star-3" alt="Star" src="/img/star-3-2.svg" />
                <img className="rectangle-6" alt="Rectangle" src="/img/rectangle-65-1.png" />
              </div>
              <div className="text-wrapper-44">قائمة المتصدرين</div>
              <Link to="/5th">
                <img className="iconsax-linear-3" alt="Iconsax linear" src="/img/iconsax-linear-edit2-1.svg" />
              </Link>
              <div className="text-wrapper-45">مصحح ثمار</div>
              <div className="text-wrapper-46">الرئيسية</div>
              <img className="iconsax-outline-2" alt="Iconsax outline" src="/img/iconsax-outline-home3-1.svg" />
            </div>
          </div>
          <img className="iconsax-outline-3" alt="Iconsax outline" src="/img/iconsax-outline-heart.svg" />
          <p className="q-mind">
            <span className="text-wrapper-47">صنع بـ</span>
            <span className="text-wrapper-48">&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span className="text-wrapper-47">
              لتحدي التطبيقات القرآنية بواسطة فريق Q mind <br />
              2024©
            </span>
          </p>
          <div className="text-wrapper-49">تعديل معلوماتي</div>
          <div className="group-4">
            <div className="overlap-5">
              <img className="group-5" alt="Group" src="/img/group-8026.png" />
              <div className="group-6">
                <div className="group-7">
                  <div className="overlap-group-14">
                    <div className="ellipse-14" />
                    <img className="path" alt="Path" src="/img/path-44116.svg" />
                    <img className="path-2" alt="Path" src="/img/path-44117.svg" />
                    <img className="path-3" alt="Path" src="/img/path-44118.svg" />
                    <img className="path-4" alt="Path" src="/img/path-44119.svg" />
                  </div>
                </div>
                <div className="group-8">
                  <div className="overlap-group-14">
                    <div className="ellipse-14" />
                    <img className="path" alt="Path" src="/img/path-44120.svg" />
                    <img className="path-2" alt="Path" src="/img/path-44121.svg" />
                    <img className="path-3" alt="Path" src="/img/path-44122.svg" />
                    <img className="path-4" alt="Path" src="/img/path-44123.svg" />
                  </div>
                </div>
              </div>
              <img className="group-9" alt="Group" src="/img/group-8035.png" />
            </div>
          </div>
          <div className="group-10">
            <div className="overlap-6">
              <div className="components-tabs" />
              <div className="right-group">
                <div className="eamil-ID">
                  <div className="overlap-group-15">
                    <div className="rectangle-7" />
                    <div className="text-wrapper-50">ليان عبدالله المقرن</div>
                  </div>
                </div>
                <div className="password">
                  <div className="overlap-7">
                    <div className="rectangle-7" />
                    <img className="ph-arrows-down-up" alt="Ph arrows down up" src="/img/ph-arrows-down-up.svg" />
                    <div className="text-wrapper-51">منطقة الرياض</div>
                  </div>
                </div>
                <div className="or">
                  <img className="line" alt="Line" src="/img/line-1.svg" />
                  <img className="line-2" alt="Line" src="/img/line-2.svg" />
                  <div className="text-wrapper-52">أو</div>
                </div>
                <div className="password-2">
                  <div className="overlap-8">
                    <div className="rectangle-7" />
                    <div className="text-wrapper-53">A1234567a</div>
                  </div>
                  <div className="text-wrapper-54">منطقة الرياض</div>
                </div>
                <div className="text-wrapper-55">المنطقة الإدارية:</div>
                <div className="text-wrapper-56">كلمة المرور:</div>
                <div className="carb-10">
                  <div className="text-wrapper-57">حفظ التغييرات</div>
                </div>
              </div>
              <div className="text-wrapper-58">الاسم:</div>
            </div>
          </div>
          <div className="sign-up-3">
            <div className="overlap-9">
              <div className="text-wrapper-59">تسجيل خروج</div>
            </div>
          </div>
          <Icon1 className="icon-5" />
        </div>
      </div>
    </div>
  );
};
