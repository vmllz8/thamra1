import React from "react";
import { Link } from "react-router-dom";
import { Frame } from "../../components/Frame";
import { StatusBar } from "../../components/StatusBar";
import { Icon2 } from "../../icons/Icon2";
import { VuesaxOutlineFrame3 } from "../../icons/VuesaxOutlineFrame3";
import "./style.css";

export const Screen6 = () => {
  return (
    <div className="screen-6">
      <div className="element-14">
        <div className="overlap-18">
          <StatusBar className="status-bar-12" darkMode="off" divClassName="status-bar-13" wifi="/img/wifi.svg" />
          <Frame className="frame-18" icon={<Icon2 className="property-1-back-instance" />} />
          <div className="rectangle-14" />
          <div className="text-wrapper-86">قائمة المتصدرين</div>
          <div className="text-wrapper-87">50/800</div>
          <div className="rectangle-15" />
          <img className="line-3" alt="Line" src="/img/line-3.svg" />
          <div className="group-36">
            <div className="overlap-group-25">
              <div className="rectangle-16" />
              <div className="text-wrapper-88">ثمارك</div>
            </div>
          </div>
          <div className="group-37">
            <div className="overlap-19">
              <div className="overlap-group-26">
                <div className="rectangle-17" />
                <img className="rectangle-18" alt="Rectangle" src="/img/rectangle-77.svg" />
                <div className="text-wrapper-89">650/800</div>
              </div>
              <div className="text-wrapper-90">سارة محمد</div>
            </div>
          </div>
          <div className="group-38">
            <div className="overlap-19">
              <div className="overlap-group-27">
                <div className="rectangle-17" />
                <div className="rectangle-19" />
                <div className="text-wrapper-91">450/800</div>
              </div>
              <div className="text-wrapper-92">أحمد ناصر</div>
            </div>
          </div>
          <div className="group-39">
            <div className="overlap-19">
              <div className="overlap-group-28">
                <div className="rectangle-17" />
                <img className="rectangle-20" alt="Rectangle" src="/img/rectangle-81.png" />
                <div className="text-wrapper-93">250/800</div>
              </div>
              <div className="text-wrapper-94">عبدالله يوسف</div>
            </div>
          </div>
          <div className="group-40">
            <div className="overlap-20">
              <div className="overlap-group-29">
                <img className="rectangle-21" alt="Rectangle" src="/img/rectangle-82.svg" />
                <div className="rectangle-22" />
                <div className="text-wrapper-95">25/800</div>
              </div>
              <div className="text-wrapper-96">تالا عبدالرحمن</div>
            </div>
            <img className="rectangle-23" alt="Rectangle" src="/img/rectangle-69.png" />
          </div>
          <div className="text-wrapper-97">@user</div>
          <img className="texture-6" alt="Texture" src="/img/texture-5.svg" />
          <div className="navbar-6">
            <div className="overlap-21">
              <div className="rectangle-24" />
              <div className="frame-19">
                <VuesaxOutlineFrame3 className="vuesax-outline-frame-2-instance" />
                <div className="text-wrapper-98">الإعدادات</div>
              </div>
              <img className="iconsax-linear-10" alt="Iconsax linear" src="/img/iconsax-linear-menuboard-3.svg" />
              <div className="text-wrapper-99">حلقات ثمار</div>
              <div className="icons-othersizes-6">
                <img className="star-7" alt="Star" src="/img/star-3-2.svg" />
                <img className="rectangle-25" alt="Rectangle" src="/img/rectangle-65-1.png" />
              </div>
              <div className="text-wrapper-100">قائمة المتصدرين</div>
              <Link to="/5th">
                <img className="iconsax-linear-11" alt="Iconsax linear" src="/img/iconsax-linear-edit2.svg" />
              </Link>
              <div className="text-wrapper-101">مصحح ثمار</div>
              <img className="union-6" alt="Union" src="/img/union-5.svg" />
              <div className="text-wrapper-102">الرئيسية</div>
              <img className="iconsax-outline-10" alt="Iconsax outline" src="/img/iconsax-outline-home3-1.svg" />
            </div>
          </div>
          <div className="rectangle-26" />
          <div className="group-41">
            <div className="group-wrapper">
              <div className="group-42">
                <div className="star-wrapper">
                  <img className="star-8" alt="Star" src="/img/star-3-7.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="icons-othersizes-7">
            <div className="overlap-22">
              <img className="star-9" alt="Star" src="/img/star-3-8.svg" />
              <img className="rectangle-27" alt="Rectangle" src="/img/rectangle-65-8.svg" />
            </div>
          </div>
          <div className="group-43">
            <div className="overlap-23">
              <img className="star-9" alt="Star" src="/img/star-4.svg" />
              <img className="rectangle-27" alt="Rectangle" src="/img/rectangle-66.svg" />
            </div>
          </div>
          <div className="icons-othersizes-8">
            <div className="overlap-24">
              <img className="star-9" alt="Star" src="/img/star-3-8.svg" />
              <img className="rectangle-27" alt="Rectangle" src="/img/rectangle-65-9.svg" />
            </div>
          </div>
          <div className="icons-othersizes-9">
            <div className="overlap-24">
              <img className="star-9" alt="Star" src="/img/star-3-8.svg" />
              <img className="rectangle-27" alt="Rectangle" src="/img/rectangle-65-10.svg" />
            </div>
          </div>
        </div>
        <img className="ellipse-18" alt="Ellipse" src="/img/ellipse-709.png" />
      </div>
    </div>
  );
};
