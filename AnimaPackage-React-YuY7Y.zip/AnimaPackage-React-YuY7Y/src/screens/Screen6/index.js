export { Screen6 } from "./Screen6";
