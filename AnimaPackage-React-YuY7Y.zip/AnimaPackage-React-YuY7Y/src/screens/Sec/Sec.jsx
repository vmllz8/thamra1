import React from "react";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Sec = () => {
  return (
    <div className="sec">
      <div className="div-5">
        <div className="overlap">
          <div className="group">
            <div className="ellipse-10" />
            <div className="ellipse-11" />
            <div className="ellipse-12" />
            <div className="text-wrapper-29">من نحن؟</div>
            <img className="logo-thmar" alt="Logo thmar" src="/img/logo-thmar-2.png" />
            <p className="text-wrapper-30">من فضلك اختر طريقة تسجيل الدخول</p>
          </div>
          <div className="ellipse-13" />
          <div className="group-2">
            <div className="overlap-group-11">
              <img className="vector-2" alt="Vector" src="/img/vector-7.svg" />
              <div className="rectangle" />
              <div className="rectangle-2" />
              <img className="sign-up" alt="Sign up" src="/img/sign-up.png" />
              <img className="sign-up-2" alt="Sign up" src="/img/sign-up-1.png" />
            </div>
          </div>
          <p className="text-wrapper-31">
            تطبيق يساعدك في تصحيح قراءتك للقرآن الكريم&nbsp;&nbsp;
            <br />
            ويوفر ميزة الحلقات القرآنية الإلكترونية لتستطيع تسميع ما حفظت أينما كنت وتتنافس مع المسلمين بين جميع أنحاء
            العالم
          </p>
        </div>
        <StatusBar
          className="status-bar-instance"
          darkMode="off"
          divClassName="design-component-instance-node"
          wifi="/img/wifi.svg"
        />
      </div>
    </div>
  );
};
