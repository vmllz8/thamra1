import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const Ranking = () => {
  return (
    <div className="ranking">
      <div className="ranking-wrapper">
        <div className="overlap-wrapper-2">
          <div className="overlap-25">
            <div className="element-15">
              <img className="img-3" alt="Vector" src="/img/vector-1.svg" />
              <p className="element-16">
                <span className="text-wrapper-103">
                  المستوى الذهبي:
                  <br />
                </span>
                <span className="text-wrapper-104">
                  {" "}
                  عندما تتألق بأكثر من 650 نقطة، تصبح نجمًا ذهبيًا في عالم قراءتك للقرآن. ذلك اللمعان الذهبي يعكس العناء
                  والتفاني الذي وضعته في فهم كلمات الله عز وجل. استمتع بلحظات التألق واستعد لمزيد من التحديات التي تعزز
                  من إشراقتك.
                  <br />
                </span>
              </p>
              <img className="img-3" alt="Element" src="/img/2.svg" />
              <p className="element-17">
                <span className="text-wrapper-103">المستوى الفضي:</span>
                <span className="text-wrapper-104">
                  {" "}
                  بتحقيقك 450 نقطة، أنت الآن جزء من تلك الفرقة المتألقة بالفضة. استمتع بلحظات الفخر والإنجاز، وتذوق
                  حلاوة تقدمك. لا تنسى أن تُلهم الآخرين من حولك، حيث تكون قصتك نبراسًا يستنير به الطلاب الطامحون.
                </span>
              </p>
              <img className="img-3" alt="Element" src="/img/2.svg" />
              <p className="element-18">
                <span className="text-wrapper-103">المستوى البرونزي:</span>
                <span className="text-wrapper-104">
                  {" "}
                  بتحقيقك 250 نقطة، أنت الآن في بداية رحلتك القرآنية. استمر في السعي للتحسين واستفد من كل توجيه يقدمه
                  المعلم. تلك الخطوات الأولى تعد نقطة انطلاق قوية لتحقيق التقدم واستمرار التطور.
                </span>
              </p>
              <img className="img-3" alt="Element" src="/img/2.svg" />
              <p className="div-6">
                <span className="text-wrapper-103">المستوى الأخضر:</span>
                <span className="text-wrapper-104">
                  {" "}
                  عندما تكون في مستوى الأخضر، تكون في مرحلة محمسة من التحدي والتعلم. استمتع بكل لحظة من تطورك، وابحث عن
                  فرص التحسين المستمر. تفاعل مع المعلم وزملائك، واستمتع برحلة اكتشاف إمكانياتك في عالم القراءة والتلاوة.
                </span>
              </p>
              <div className="group-44">
                <div className="img-wrapper">
                  <img className="star-10" alt="Star" src="/img/star-3-11.svg" />
                </div>
              </div>
              <div className="icons-othersizes-10">
                <div className="overlap-group-30">
                  <img className="star-11" alt="Star" src="/img/star-3-8.svg" />
                  <img className="rectangle-28" alt="Rectangle" src="/img/rectangle-65-12.svg" />
                </div>
              </div>
              <div className="group-45">
                <div className="overlap-26">
                  <img className="star-10" alt="Star" src="/img/star-4-1.svg" />
                  <img className="rectangle-29" alt="Rectangle" src="/img/rectangle-66-1.svg" />
                </div>
              </div>
              <div className="icons-othersizes-11">
                <div className="overlap-group-30">
                  <img className="star-11" alt="Star" src="/img/star-3-8.svg" />
                  <img className="rectangle-28" alt="Rectangle" src="/img/rectangle-65-13.svg" />
                </div>
              </div>
            </div>
            <Link className="home-work-wrapper" to="/10th">
              <div className="home-work">
                <div className="text-wrapper-105">استعراض قائمة المتصدرين</div>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
