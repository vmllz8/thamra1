import React from "react";
import { Link } from "react-router-dom";
import "./style.css";

export const First = () => {
  return (
    <div className="first">
      <div className="overlap-group-wrapper-3">
        <div className="overlap-group-32">
          <img className="group-46" alt="Group" src="/img/group-13.png" />
          <Link to="/sec">
            <img className="frame-21" alt="Frame" src="/img/frame-27.png" />
          </Link>
        </div>
      </div>
    </div>
  );
};
