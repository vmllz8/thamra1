import React from "react";
import { Link } from "react-router-dom";
import { StatusBar } from "../../components/StatusBar";
import { Icon } from "../../icons/Icon";
import { Icon1 } from "../../icons/Icon1";
import "./style.css";

export const Third = () => {
  return (
    <div className="third">
      <div className="overlap-wrapper-3">
        <div className="overlap-27">
          <img className="right-background" alt="Right background" src="/img/right-background.svg" />
          <div className="right-group-2">
            <div className="eamil-ID-2">
              <div className="overlap-group-31">
                <div className="rectangle-30" />
                <div className="text-wrapper-106">11223344556</div>
              </div>
            </div>
            <div className="overlap-28">
              <div className="password-3">
                <div className="overlap-29">
                  <div className="rectangle-30" />
                  <div className="text-wrapper-107">ادخل كلمة المرور</div>
                </div>
              </div>
              <div className="rectangle-31" />
              <img className="frame-20" alt="Frame" src="/img/frame.svg" />
            </div>
            <div className="text-wrapper-108">نسيت كلمة المرور</div>
            <Link to="/4th">
              <img className="login-now" alt="Login now" src="/img/login-now.png" />
            </Link>
            <div className="or-2">
              <img className="line-4" alt="Line" src="/img/line-1-1.svg" />
              <img className="line-5" alt="Line" src="/img/line-2-1.svg" />
              <div className="text-wrapper-109">أو</div>
            </div>
            <div className="sign-up-4">
              <div className="overlap-30">
                <div className="text-wrapper-110">تسجيل جديد</div>
              </div>
            </div>
            <div className="text-wrapper-111">كلمة المرور:</div>
          </div>
          <StatusBar className="status-bar-14" darkMode="off" divClassName="status-bar-15" wifi="/img/wifi.svg" />
          <img className="logo-thmar-3" alt="Logo thmar" src="/img/logo-thmar-2.png" />
          <div className="text-wrapper-112">تسجيل الدخول كـــ طالب</div>
          <div className="text-wrapper-113">رقم الهوية:</div>
          <div className="rectangle-32" />
          <img className="mail-icon" alt="Mail icon" src="/img/mail-icon.png" />
          <img className="texture-7" alt="Texture" src="/img/texture-6.svg" />
          <Icon1 className="icon-3" />
          <Icon className="icon-instance-node" />
        </div>
      </div>
    </div>
  );
};
