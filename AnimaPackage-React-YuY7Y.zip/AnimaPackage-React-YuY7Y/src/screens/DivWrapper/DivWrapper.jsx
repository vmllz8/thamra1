import React from "react";
import { Link } from "react-router-dom";
import { Frame } from "../../components/Frame";
import { GrFromTo } from "../../components/GrFromTo";
import { StatusBar } from "../../components/StatusBar";
import { Icon2 } from "../../icons/Icon2";
import { VuesaxOutlineFrame3 } from "../../icons/VuesaxOutlineFrame3";
import "./style.css";

export const DivWrapper = () => {
  return (
    <div className="div-wrapper">
      <div className="element-11">
        <div className="overlap-14">
          <Frame className="frame-instance" icon={<Icon2 className="property-1-back" />} />
          <StatusBar className="status-bar-8" darkMode="off" divClassName="status-bar-9" wifi="/img/wifi.svg" />
          <img className="texture-4" alt="Texture" src="/img/texture-3.svg" />
          <div className="navbar-4">
            <div className="overlap-group-18">
              <div className="rectangle-10" />
              <div className="frame-13">
                <VuesaxOutlineFrame3 className="vuesax-outline-frame-3-instance" />
                <div className="text-wrapper-68">الإعدادات</div>
              </div>
              <img className="iconsax-linear-6" alt="Iconsax linear" src="/img/iconsax-linear-menuboard-3.svg" />
              <div className="text-wrapper-69">حلقات ثمار</div>
              <div className="icons-othersizes-4">
                <img className="star-5" alt="Star" src="/img/star-3-4.svg" />
                <img className="rectangle-11" alt="Rectangle" src="/img/rectangle-65-1.png" />
              </div>
              <div className="text-wrapper-70">قائمة المتصدرين</div>
              <Link to="/5th">
                <img className="iconsax-linear-7" alt="Iconsax linear" src="/img/iconsax-linear-edit2.svg" />
              </Link>
              <div className="text-wrapper-71">مصحح ثمار</div>
              <img className="union-4" alt="Union" src="/img/union-3.svg" />
              <div className="text-wrapper-72">الرئيسية</div>
              <img className="iconsax-outline-5" alt="Iconsax outline" src="/img/iconsax-outline-home3-1.svg" />
            </div>
          </div>
          <div className="choose">
            <Link className="carb-15" to="/6th">
              <div className="text-wrapper-73">حلقة عامة</div>
            </Link>
            <div className="element-12">
              <div className="text-wrapper-74">حلقة خاصة</div>
            </div>
          </div>
          <Link className="carb-16" to="/6th">
            <Link className="carb-17" to="/9th">
              <div className="text-wrapper-75">استعراض الواجبات</div>
            </Link>
          </Link>
          <div className="inside-wrapper">
            <div className="inside-2" />
          </div>
          <img className="group-19" alt="Group" src="/img/group-48095476-1.png" />
          <GrFromTo
            className="gr-from-1-to-10-instance"
            imgClassName="gr-from-to-instance"
            text="سارة محمد"
            text1="حمد خالد"
            text2="نورة أحمد"
            text3="ثامر يوسف"
            text4="فيصل علي"
            text5="لمياء ثابت"
            text6="خالد عبدالرحمن"
            text7="سناء عثمان"
            text8="رنا محمد"
            text9="سلطان عبدالله"
            vectorClassName="gr-from-to-instance"
            vectorClassNameOverride="gr-from-to-instance"
          />
          <div className="group-20">
            <div className="overlap-15">
              <img className="group-21" alt="Group" src="/img/group-8026-2.png" />
              <div className="group-22">
                <div className="group-23">
                  <div className="overlap-group-19">
                    <div className="ellipse-16" />
                    <img className="path-9" alt="Path" src="/img/path-44116-1.svg" />
                    <img className="path-10" alt="Path" src="/img/path-44117-2.svg" />
                    <img className="path-11" alt="Path" src="/img/path-44118-2.svg" />
                    <img className="path-12" alt="Path" src="/img/path-44119-1.svg" />
                  </div>
                </div>
                <div className="group-24">
                  <div className="overlap-group-19">
                    <div className="ellipse-16" />
                    <img className="path-9" alt="Path" src="/img/path-44120-2.svg" />
                    <img className="path-10" alt="Path" src="/img/path-44121-1.svg" />
                    <img className="path-11" alt="Path" src="/img/path-44122-2.svg" />
                    <img className="path-12" alt="Path" src="/img/path-44123.svg" />
                  </div>
                </div>
              </div>
              <img className="group-25" alt="Group" src="/img/group-8035.png" />
            </div>
            <img className="group-26" alt="Group" src="/img/group-8028-1.png" />
          </div>
        </div>
      </div>
    </div>
  );
};
