import React from "react";
import { Link } from "react-router-dom";
import { Frame } from "../../components/Frame";
import { StatusBar } from "../../components/StatusBar";
import { VuesaxOutlineFrameWrapper } from "../../components/VuesaxOutlineFrameWrapper";
import { Icon2 } from "../../icons/Icon2";
import "./style.css";

export const Screen11 = () => {
  return (
    <div className="screen-11">
      <div className="element-19">
        <div className="overlap-31">
          <div className="rectangle-33" />
          <StatusBar className="status-bar-16" darkMode="off" divClassName="status-bar-17" wifi="/img/wifi.svg" />
          <Frame className="frame-22" icon={<Icon2 className="icon-4" />} />
          <div className="rectangle-34" />
          <div className="text-wrapper-114">مصحح التلاوة</div>
          <img className="group-47" alt="Group" src="/img/group-48095487.png" />
          <div className="icons-7">
            <div className="stop-svgrepo-com-wrapper">
              <img className="stop-svgrepo-com" alt="Stop svgrepo com" src="/img/stop-svgrepo-com-1.svg" />
            </div>
          </div>
          <img className="icons-8" alt="Icons" src="/img/icons-56x56-background-13.svg" />
          <img className="texture-8" alt="Texture" src="/img/texture-7.svg" />
          <div className="components-button-6">
            <div className="components-6" />
            <img className="icons-9" alt="Icons" src="/img/icons-56x56-background-14.svg" />
            <img className="texture-9" alt="Texture" src="/img/texture-8.svg" />
          </div>
          <div className="text">{""}</div>
          <div className="navbar-7">
            <div className="overlap-32">
              <div className="rectangle-35" />
              <div className="frame-23">
                <VuesaxOutlineFrameWrapper />
                <div className="text-wrapper-115">الإعدادات</div>
              </div>
              <Link to="/6th">
                <img className="iconsax-linear-12" alt="Iconsax linear" src="/img/iconsax-linear-menuboard.svg" />
              </Link>
              <div className="text-wrapper-116">حلقات ثمار</div>
              <Link className="icons-othersizes-12" to="/10th">
                <img className="star-12" alt="Star" src="/img/star-3-14.svg" />
                <img className="rectangle-36" alt="Rectangle" src="/img/rectangle-65-1.png" />
              </Link>
              <div className="text-wrapper-117">قائمة المتصدرين</div>
              <Link to="/5th">
                <img className="iconsax-linear-13" alt="Iconsax linear" src="/img/iconsax-linear-edit2-6.svg" />
              </Link>
              <div className="text-wrapper-118">مصحح ثمار</div>
              <img className="union-7" alt="Union" src="/img/union-6.svg" />
              <div className="text-wrapper-119">الرئيسية</div>
              <img className="iconsax-outline-11" alt="Iconsax outline" src="/img/iconsax-outline-home3.svg" />
            </div>
          </div>
          <div className="text-wrapper-120">استمع للآيات بشكل صحيح:</div>
        </div>
      </div>
    </div>
  );
};
