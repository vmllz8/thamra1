import React from "react";
import { Link } from "react-router-dom";
import { Frame } from "../../components/Frame";
import { StatusBar } from "../../components/StatusBar";
import { Icon2 } from "../../icons/Icon2";
import { VuesaxOutlineFrame3 } from "../../icons/VuesaxOutlineFrame3";
import "./style.css";

export const Screen5 = () => {
  return (
    <div className="screen-5">
      <div className="element-13">
        <div className="overlap-16">
          <StatusBar className="status-bar-10" darkMode="off" divClassName="status-bar-11" wifi="/img/wifi.svg" />
          <Frame className="frame-28-instance" icon={<Icon2 className="icon-2-instance" />} />
          <img className="texture-5" alt="Texture" src="/img/texture-4.svg" />
          <div className="navbar-5">
            <div className="overlap-group-20">
              <div className="rectangle-12" />
              <div className="frame-14">
                <VuesaxOutlineFrame3 className="vuesax-outline-frame-1-instance" />
                <div className="text-wrapper-76">الإعدادات</div>
              </div>
              <img className="iconsax-linear-8" alt="Iconsax linear" src="/img/iconsax-linear-menuboard-3.svg" />
              <div className="text-wrapper-77">حلقات ثمار</div>
              <div className="icons-othersizes-5">
                <img className="star-6" alt="Star" src="/img/star-3-4.svg" />
                <img className="rectangle-13" alt="Rectangle" src="/img/rectangle-65-1.png" />
              </div>
              <div className="text-wrapper-78">قائمة المتصدرين</div>
              <Link to="/5th">
                <img className="iconsax-linear-9" alt="Iconsax linear" src="/img/iconsax-linear-edit2.svg" />
              </Link>
              <div className="text-wrapper-79">مصحح ثمار</div>
              <img className="union-5" alt="Union" src="/img/union-4.svg" />
              <div className="text-wrapper-80">الرئيسية</div>
              <img className="iconsax-outline-6" alt="Iconsax outline" src="/img/iconsax-outline-home3-1.svg" />
            </div>
          </div>
          <div className="home-wrapper">
            <div className="home">
              <div className="text-wrapper-81">الواجبات</div>
            </div>
          </div>
          <img className="group-27" alt="Group" src="/img/group-48095476-2.png" />
          <div className="cards">
            <div className="components-wrapper">
              <div className="components-5">
                <div className="internal">
                  <div className="iconsax-outline-7">
                    <div className="overlap-group-21">
                      <img className="vector-3" alt="Vector" src="/img/vector.svg" />
                      <Link to="/name">
                        <img className="vector-4" alt="Vector" src="/img/vector-2.svg" />
                      </Link>
                      <img className="vector-5" alt="Vector" src="/img/vector-3.svg" />
                    </div>
                  </div>
                  <div className="text-wrapper-82">مراجعة سورة العلق كاملة</div>
                  <div className="frame-15">
                    <div className="frame-16" />
                  </div>
                  <img className="icons" alt="Icons" src="/img/rectangle-65-1.png" />
                </div>
              </div>
            </div>
            <div className="components-button-3">
              <div className="components-5">
                <div className="frame-wrapper">
                  <div className="frame-15">
                    <div className="frame-16">
                      <div className="text-wrapper-83">مراجعة سورة المدثر كاملة</div>
                    </div>
                  </div>
                </div>
                <div className="iconsax-outline-8">
                  <div className="overlap-group-22">
                    <img className="vector-3" alt="Vector" src="/img/vector-4.svg" />
                    <Link to="/name">
                      <img className="vector-4" alt="Vector" src="/img/vector-8.svg" />
                    </Link>
                    <img className="vector-5" alt="Vector" src="/img/vector-9.svg" />
                  </div>
                </div>
                <img className="icons-x" alt="Icons" src="/img/icons-56x56-background-2.svg" />
              </div>
            </div>
            <div className="components-button-4">
              <div className="components-5">
                <div className="internal-2">
                  <div className="iconsax-outline-7">
                    <div className="overlap-group-21">
                      <img className="vector-3" alt="Vector" src="/img/vector-10.svg" />
                      <Link to="/name">
                        <img className="vector-4" alt="Vector" src="/img/vector-11.svg" />
                      </Link>
                      <img className="vector-5" alt="Vector" src="/img/vector-12.svg" />
                    </div>
                  </div>
                  <div className="frame-17">
                    <div className="frame-16">
                      <div className="text-wrapper-84">مراجعة سورة الفاتحة كاملة</div>
                    </div>
                  </div>
                </div>
                <img className="icons-2" alt="Icons" src="/img/icons-56x56-background-3.svg" />
              </div>
            </div>
            <div className="components-button-5">
              <div className="components-5">
                <div className="internal-3">
                  <div className="frame-15">
                    <div className="frame-16" />
                    <img className="icons-3" alt="Icons" src="/img/icons-56x56-background-4.svg" />
                  </div>
                  <div className="text-wrapper-85">مراجعة سورة القارعة كاملة</div>
                </div>
                <div className="iconsax-outline-9">
                  <div className="overlap-group-23">
                    <img className="vector-3" alt="Vector" src="/img/vector-13.svg" />
                    <Link to="/name">
                      <img className="vector-4" alt="Vector" src="/img/vector-14.svg" />
                    </Link>
                    <img className="vector-5" alt="Vector" src="/img/vector-15.svg" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="icons-4">
            <div className="ph-arrows-down-up-wrapper">
              <img className="ph-arrows-down-up-2" alt="Ph arrows down up" src="/img/ph-arrows-down-up-1.svg" />
            </div>
          </div>
          <img className="icons-5" alt="Icons" src="/img/icons-56x56-background-5.svg" />
          <div className="group-28">
            <div className="overlap-17">
              <img className="group-29" alt="Group" src="/img/group-8026-3.png" />
              <div className="group-30">
                <div className="group-31">
                  <div className="overlap-group-24">
                    <div className="ellipse-17" />
                    <img className="path-13" alt="Path" src="/img/path-44116-3.svg" />
                    <img className="path-14" alt="Path" src="/img/path-44117-3.svg" />
                    <img className="path-15" alt="Path" src="/img/path-44118-3.svg" />
                    <img className="path-16" alt="Path" src="/img/path-44119-3.svg" />
                  </div>
                </div>
                <div className="group-32">
                  <div className="overlap-group-24">
                    <div className="ellipse-17" />
                    <img className="path-13" alt="Path" src="/img/path-44120-3.svg" />
                    <img className="path-14" alt="Path" src="/img/path-44121-3.svg" />
                    <img className="path-15" alt="Path" src="/img/path-44122-3.svg" />
                    <img className="path-16" alt="Path" src="/img/path-44123-3.svg" />
                  </div>
                </div>
              </div>
              <img className="group-33" alt="Group" src="/img/group-8035-3.png" />
            </div>
            <img className="group-34" alt="Group" src="/img/group-8028-2.png" />
          </div>
          <img className="group-35" alt="Group" src="/img/group-48095495.png" />
          <img className="icons-6" alt="Icons" src="/img/icons-56x56-background.svg" />
        </div>
      </div>
    </div>
  );
};
