import React from "react";
import { Link } from "react-router-dom";
import { Frame } from "../../components/Frame";
import { GrFromTo } from "../../components/GrFromTo";
import { StatusBar } from "../../components/StatusBar";
import { Icon2 } from "../../icons/Icon2";
import { VuesaxOutlineFrame3 } from "../../icons/VuesaxOutlineFrame3";
import "./style.css";

export const ElementTh = () => {
  return (
    <div className="element-th">
      <div className="element-10">
        <div className="overlap-10">
          <StatusBar className="status-bar-6" darkMode="off" divClassName="status-bar-7" wifi="/img/wifi.svg" />
          <Frame className="header" icon={<Icon2 className="icon-2" />} />
          <img className="texture-3" alt="Texture" src="/img/texture-2.svg" />
          <div className="navbar-3">
            <div className="overlap-group-16">
              <div className="rectangle-8" />
              <div className="frame-12">
                <VuesaxOutlineFrame3 className="vuesax-outline-frame-2" />
                <div className="text-wrapper-60">الإعدادات</div>
              </div>
              <img className="iconsax-linear-4" alt="Iconsax linear" src="/img/iconsax-linear-menuboard-2.svg" />
              <div className="text-wrapper-61">حلقات ثمار</div>
              <div className="icons-othersizes-3">
                <img className="star-4" alt="Star" src="/img/star-3-1.svg" />
                <img className="rectangle-9" alt="Rectangle" src="/img/rectangle-65-1.png" />
              </div>
              <div className="text-wrapper-62">قائمة المتصدرين</div>
              <Link to="/5th">
                <img className="iconsax-linear-5" alt="Iconsax linear" src="/img/iconsax-linear-edit2.svg" />
              </Link>
              <div className="text-wrapper-63">مصحح ثمار</div>
              <img className="union-3" alt="Union" src="/img/union-2.svg" />
              <div className="text-wrapper-64">الرئيسية</div>
              <img className="iconsax-outline-4" alt="Iconsax outline" src="/img/iconsax-outline-home3-1.svg" />
            </div>
          </div>
          <img className="group-11" alt="Group" src="/img/group-48095476.png" />
          <div className="components-tabs-2">
            <div className="carb-11">
              <div className="text-wrapper-65">حلقة عامة</div>
            </div>
            <Link className="carb-12" to="/7th">
              <div className="text-wrapper-66">حلقة خاصة</div>
            </Link>
          </div>
          <div className="inside">
            <div className="overlap-11">
              <div className="inside-th" />
              <GrFromTo className="gr-from-1-to-10" />
            </div>
          </div>
          <div className="carb-13">
            <Link className="carb-14" to="/9th">
              <div className="text-wrapper-67">استعراض الواجبات</div>
            </Link>
          </div>
          <div className="group-12">
            <div className="overlap-12">
              <div className="overlap-13">
                <img className="group-13" alt="Group" src="/img/group-8026-1.png" />
                <div className="group-14">
                  <div className="group-15">
                    <div className="overlap-group-17">
                      <div className="ellipse-15" />
                      <img className="path-5" alt="Path" src="/img/path-44116-1.svg" />
                      <img className="path-6" alt="Path" src="/img/path-44117-1.svg" />
                      <img className="path-7" alt="Path" src="/img/path-44118-1.svg" />
                      <img className="path-8" alt="Path" src="/img/path-44119-1.svg" />
                    </div>
                  </div>
                  <div className="group-16">
                    <div className="overlap-group-17">
                      <div className="ellipse-15" />
                      <img className="path-5" alt="Path" src="/img/path-44120-1.svg" />
                      <img className="path-6" alt="Path" src="/img/path-44121-1.svg" />
                      <img className="path-7" alt="Path" src="/img/path-44122-1.svg" />
                      <img className="path-8" alt="Path" src="/img/path-44123-1.svg" />
                    </div>
                  </div>
                </div>
                <img className="group-17" alt="Group" src="/img/group-8035.png" />
              </div>
              <img className="group-18" alt="Group" src="/img/group-8028.png" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
