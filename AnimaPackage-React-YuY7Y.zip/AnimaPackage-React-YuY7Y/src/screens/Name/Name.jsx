import React from "react";
import { GrFromToT } from "../../components/GrFromToT";
import "./style.css";

export const Name = () => {
  return (
    <div className="name">
      <div className="name-wrapper-2">
        <div className="gr-from-to-t-wrapper">
          <GrFromToT className="gr-from-1-to-10-t" />
        </div>
      </div>
    </div>
  );
};
