export { Name } from "./Name";
