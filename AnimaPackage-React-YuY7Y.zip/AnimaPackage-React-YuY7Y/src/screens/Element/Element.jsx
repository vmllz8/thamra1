import React from "react";
import { Link } from "react-router-dom";
import { Frame } from "../../components/Frame";
import { StatusBar } from "../../components/StatusBar";
import { VuesaxOutlineFrame3 } from "../../icons/VuesaxOutlineFrame3";
import "./style.css";

export const Element = () => {
  return (
    <div className="element">
      <div className="overlap-wrapper">
        <div className="overlap-2">
          <div className="carb" />
          <Link className="carb-2" to="/10th">
            <div className="text-wrapper-32">50</div>
          </Link>
          <StatusBar className="status-bar-2" darkMode="off" divClassName="status-bar-3" wifi="/img/wifi.svg" />
          <Frame className="frame-28" visible={false} />
          <img className="texture" alt="Texture" src="/img/texture.svg" />
          <div className="carb-3" />
          <img className="logo-thmar-2" alt="Logo thmar" src="/img/logo-thmar-2.png" />
          <div className="text-wrapper-33">أهلا! user@</div>
          <div className="carb-4">
            <div className="carb-5">
              <div className="carb-6">
                <p className="text-wrapper-34">
                  حلقات ثمار هي حلقات قرآنية تمكن الطالب من الدخول الى حلقات عامة وخاصة&nbsp;&nbsp;تهدف الى تحسين
                  قراءتهم وتعزيز مستواهم&nbsp;&nbsp;، حيث توفر&nbsp;&nbsp;الاداة فرصة للمعلم لتوجيه الطلاب وإدارة واجبات
                  إضافية لتعزيز تقدمهم خلال حلقات ثمار.
                </p>
              </div>
              <div className="carb-wrapper">
                <Link className="carb-7" to="/6th">
                  <div className="text-wrapper-35">حلقات ثمار</div>
                </Link>
              </div>
            </div>
            <p className="text-wrapper-36">
              أداة مصحح التلاوة صممت لتساعدك فهي تقوم بكتابة الأخطاء المتواجدة في تلاوتك لتصحهها.
            </p>
            <div className="carb-8">
              <Link className="carb-9" to="/5th">
                <div className="text-wrapper-35">مصحح ثمار</div>
              </Link>
            </div>
          </div>
          <img className="group-3" alt="Group" src="/img/group-48095477.png" />
          <Link to="/ranking">
            <img className="star" alt="Star" src="/img/star-3.svg" />
          </Link>
          <img className="rectangle-3" alt="Rectangle" src="/img/rectangle-65.svg" />
          <div className="navbar">
            <div className="overlap-group-12">
              <div className="rectangle-4" />
              <div className="frame-10">
                <VuesaxOutlineFrame3 className="vuesax-outline-frame-3" />
                <div className="text-wrapper-37">الإعدادات</div>
              </div>
              <Link to="/6th">
                <img className="iconsax-linear" alt="Iconsax linear" src="/img/iconsax-linear-menuboard.svg" />
              </Link>
              <div className="text-wrapper-38">حلقات ثمار</div>
              <Link className="icons-othersizes" to="/10th">
                <img className="star-2" alt="Star" src="/img/star-3-1.svg" />
                <img className="rectangle-5" alt="Rectangle" src="/img/rectangle-65-1.png" />
              </Link>
              <div className="text-wrapper-39">قائمة المتصدرين</div>
              <Link to="/5th">
                <img className="iconsax-linear-edit" alt="Iconsax linear" src="/img/iconsax-linear-edit2.svg" />
              </Link>
              <div className="text-wrapper-40">مصحح ثمار</div>
              <img className="union" alt="Union" src="/img/union.svg" />
              <div className="text-wrapper-41">الرئيسية</div>
              <img className="iconsax-outline" alt="Iconsax outline" src="/img/iconsax-outline-home3.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
