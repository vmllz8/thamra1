import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { First } from "./screens/First";
import { Sec } from "./screens/Sec";
import { Element } from "./screens/Element";
import { ElementScreen } from "./screens/ElementScreen";
import { ElementTh } from "./screens/ElementTh";
import { DivWrapper } from "./screens/DivWrapper";
import { Screen5 } from "./screens/Screen5";
import { Screen6 } from "./screens/Screen6";
import { Ranking } from "./screens/Ranking";
import { Name } from "./screens/Name";
import { Third } from "./screens/Third";
import { Screen11 } from "./screens/Screen11";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <First />,
  },
  {
    path: "/first",
    element: <First />,
  },
  {
    path: "/sec",
    element: <Sec />,
  },
  {
    path: "/4th",
    element: <Element />,
  },
  {
    path: "/11th",
    element: <ElementScreen />,
  },
  {
    path: "/6th",
    element: <ElementTh />,
  },
  {
    path: "/7th",
    element: <DivWrapper />,
  },
  {
    path: "/9th",
    element: <Screen5 />,
  },
  {
    path: "/10th",
    element: <Screen6 />,
  },
  {
    path: "/ranking",
    element: <Ranking />,
  },
  {
    path: "/name",
    element: <Name />,
  },
  {
    path: "/third",
    element: <Third />,
  },
  {
    path: "/5th",
    element: <Screen11 />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
